<?php
session_start();
$flow="1";
$code=200;
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$set_added_by=$_SESSION["recruiter_id"];
$set_name=$_POST['setname'];
$set_sub_name=$_POST['subname'];
$set_aubible=$_POST['audible'];
$set_complexity=$_POST['complexity'];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
    $sql8 = "INSERT INTO vj_question_set(set_name,set_sub_name,set_audible,set_complexity,set_added_by) VALUES('$set_name','$set_sub_name','$set_aubible','$set_complexity','$set_added_by')";
    if ($conn->query($sql8)==TRUE){
        echo json_encode(['code'=>400, 'msg'=>'success']);
        $conn->close(); 
        exit;
    }  
    else{
        echo json_encode(['code'=>200, 'msg'=>"f"]);
        $conn->close(); 
        exit;
    }


?>