<?php
session_start();
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$interview_user_id=$_POST['applicant_user_id'];
$interview_job=$_POST['job_name'];
$interview_company=$_POST['company_name'];
$interview_appid=$_POST['application_id'];
$interview_type='virtual';
$interview_ref=$_POST['set_num'];
$interview_subject=$_POST['meeting_sub'];
$interview_schedule_start_date=$_POST['start_date1'];
$interview_schedule_end_date=$_POST['end_date1'];
$interview_created_by=$_POST['admin_user_id'];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }

$sql8="INSERT INTO vj_interviews(interview_user_id,interview_job,interview_company,interview_appid,interview_type,interview_ref,interview_subject,interview_schedule_start_date,interview_schedule_end_date,interview_created_by) values('$interview_user_id','$interview_job','$interview_company','$interview_appid','$interview_type','$interview_ref','$interview_subject','$interview_schedule_start_date','$interview_schedule_end_date','$interview_created_by')";
if ($conn->query($sql8)==TRUE){
    echo json_encode(['code'=>400, 'msg'=>'success']);
    $conn->close(); 
    exit;
} 
echo json_encode(['code'=>200, 'msg'=>'a']);
$conn->close();
exit;
?>