<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$r_id=$_SESSION['recruiter_id'];
$c_id=$_SESSION['c_id'];
$a_id=$_SESSION['a_id'];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
$sql="SELECT * from vj_candidate where candidate_id='$c_id'";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $title=$row['candidate_title'];
        $candidate_fname=$row['candidate_fname'];
        $candidate_lname=$row['candidate_lname'];
        $candidate_email=$row['candidate_email'];
        $candidate_availability=$row['candidate_availability'];
        $candidate_phone=$row['candidate_phone'];
        $candidate_about=$row['candidate_about'];
        $candidate_skillsets=$row['candidate_skillsets'];
        $candidate_industry=$row['candidate_industry'];
        $candidate_current_package=$row['candidate_current_package'];
        $candidate_expected_package=$row['candidate_expected_package'];
        $candidate_current_location	=$row['candidate_current_location'];
        $candidate_expected_location=$row['candidate_expected_location'];
        $candidate_10_name=$row['candidate_10_name'];
        $candidate_10_start=$row['candidate_10_start'];
        $candidate_10_end=$row['candidate_10_end'];
        $candidate_10_score=$row['candidate_10_score'];
        $candidate_12_name=$row['candidate_12_name'];
        $candidate_12_start=$row['candidate_12_start'];
        $candidate_12_end=$row['candidate_12_end'];
        $candidate_12_score=$row['candidate_12_score'];
        $candidate_clg1_name=$row['candidate_clg1_name'];
        $candidate_clg1_course=$row['candidate_clg1_course'];
        $candidate_clg1_start=$row['candidate_clg1_start'];
        $candidate_clg1_end=$row['candidate_clg1_end'];
        $candidate_clg1_score=$row['candidate_clg1_score'];
        $candidate_clg2_name=$row['candidate_clg2_name'];
        $candidate_clg2_course=$row['candidate_clg2_course'];
        $candidate_clg2_start=$row['candidate_clg2_start'];
        $candidate_clg2_end=$row['candidate_clg2_end'];
        $candidate_clg2_score=$row['candidate_clg2_score'];
        $candidate_img_url=$row['candidate_img_url'];
        $candidate_work1=$row['candidate_work1'];
        $candidate_work_company1=$row['candidate_work_company1'];
        $candidate_work_sdate1=$row['candidate_work_sdate1'];
        $candidate_work_edate1=$row['candidate_work_edate1'];
        $candidate_work2=$row['candidate_work2'];
        $candidate_work_company2=$row['candidate_work_company2'];
        $candidate_work_sdate2=$row['candidate_work_sdate2'];
        $candidate_work_edate2=$row['candidate_work_edate2'];
    }
}
$skillsets=[];
$a=0;
$aa=0;
$tmp='';
for($x=0;$x<strlen($candidate_skillsets);$x++){
  if($x==strlen($candidate_skillsets)-1){
    $tmp= substr($candidate_skillsets,$a);
    array_push($skillsets,$tmp);
    $a=$x+1;      
  }
  if($candidate_skillsets[$x]==','){
    if($aa!=0){
      $aa=$x-$a;
    }
    else{
      $aa=$x;
    }
   $tmp= substr($candidate_skillsets,$a,$aa);
   array_push($skillsets,$tmp);
   $aa=1;
   $a=$x+1;
   
  }
} 

$sql1="SELECT * from vj_question_set where set_added_by='$r_id'";
$set_name=[];
$sub_name=[];
$set_id=[];
$set_complexity=[];
$result1 = $conn->query($sql1);
if ($result1->num_rows > 0) {
    while($row1 = $result1->fetch_assoc()) {
        array_push($set_name,$row1['set_name']);
        array_push($sub_name,$row1['set_sub_name']);
        array_push($set_id,$row1['set_id']);
        array_push($set_complexity,$row1['set_complexity']);
    }
}
$j_id=$_SESSION['job_id'];
$sql2="SELECT * from vj_jobs where job_id='$j_id'";

$result2 = $conn->query($sql2);
if ($result2->num_rows > 0) {
    while($row2 = $result2->fetch_assoc()) {
        $job_title=$row2['job_title'];
        $job_company=$row2['job_company'];

    }
}

$conn->close(); 
?>
<!DOCTYPE html>
<!-- saved from url=(0090)https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta property="og:url" content="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455">
<meta property="og:type" content="website">
<meta property="og:title" content="Talent Development Manager at HCL, Bangalore, India ">
<meta property="og:description" content="HCL Software is a division of HCL Technologies (HCL) that operates its primary software business. It develops, markets, sells, and supports over 20 product fami">
<meta property="og:image" content="https://quantumhunts.com/user/assets/images/header/job_openning_300px.png">
<meta property="fb:app_id" content="525323715034631"> 


        <title>VJA | APPLICATION </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="* Understand and appreciate software product engineering, technologies &amp; methodologies at a conceptu " name="description">
        <meta content="VJX" name="author">
<?php
  include($root."/header_employer.php");
?>


        <!-- Start Content-->
        <div class="container-fluid">

            <!-- Begin page -->
            <div class="wrapper">

                <!-- ========== Left Sidebar Start ========== -->


                <!-- Left Sidebar End -->
                       
                
                
                
 <div class="content-page">
                    <div class="content">

                        <div class="row">
                            

                           



                        


<div class="row justify-content-lg-between mb-3 mt-1">
    
    
         



        <div class="col-lg-12 mb-8 mb-lg-0 mt-4">  
        





        <div class="card border shadow1 card-body">
        <div class="">
            



  <!--
    <div class="text-center mb-2 mt-0 pt-0 mt-n2">    
    <span class="text-secondary px-2 p-0 font-12">QH Staff Profile</span>
    </div>
    -->










          <!-- Info -->
          <div class="mb-2 mt-0">
<div class="m-n3 mb-2" role="alert">
<div class="media resume1 card-body">
    <div class="">
<img class="dp mr-2 mt-2 img-thumbnail1 border-secondary" src="<?php $candidate_img_url; ?>" alt="JANARDH" height="64" width="64">
</div>
<div class="media-body ml-1">
    <span class="text-primary float-right font-11" data-toggle="popover" data-trigger="hover" title="" data-content="Verification indicates if the profile has been verified by the platform" data-placement="bottom" data-original-title=""><i class="mdi mdi-shield-star-outline"></i> Verified Resume</span>
<h5 class="text-uppercase text-primary purpletitle mb-0 blogmini font-12">QUANTUMHUNTS 
</h5>    
<h3 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0 byte-title font-15 blogmini" style="line-height:24px;"><?php echo $candidate_fname.' '.$candidate_lname;  ?>
<img src="https://quantumhunts.com/user/assets/images/square1_qh.png" class="mygray" height="18px" width="18px" alt="QH STAFF Recruiter" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="QH Professional">


</h3>    
<p class="text-secondary font-13"><?php echo $title; ?><br> <?php echo $candidate_current_location; ?>
</p>

</div>
</div>
</div>
                    



</div>


</div>






<br>
<br>


<div class="media mb-3">
    <div class="media-body">
<div class="" id="about"><p><?php echo $candidate_about; ?></p>
</div>
 
   <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>

  
</div>
</div>













<div class="media mb-3">
    <div class="media-body">




     
          
            
<div class="row mb-1">
<div class="col-6 col-md-6">
<span class="text-dark font-weight-bold mr-3">Current Location</span>
</div>
<div class="col-6 col-md-6">
<span class="dotted1"><?php echo $candidate_current_location; ?></span>
</div>
</div>


<div class="row mb-1">
<div class="col-6 col-md-6">
<span class="text-dark font-weight-bold mr-3">Preferred Location</span>
</div>
<div class="col-6 col-md-6">
<span class="dotted1"><?php echo $candidate_expected_location; ?></span>
</div>
</div>



<div class="row mb-1">
<div class="col-6 col-md-6">
<span class="text-dark font-weight-bold mr-3">E-Mail</span>
</div>

   
<div class="col-6 col-md-6">
<span class="dotted1"> <?php echo $candidate_email; ?> </span>
</div>
</div>



<div class="row mb-1">
<div class="col-6 col-md-6">
<span class="text-dark font-weight-bold mr-3">Mobile</span>
</div>
<div class="col-6 col-md-6">
  
    <span class="dotted1">India +91<?php echo $candidate_phone; ?> </span>
    </div>
</div>










    






    </div>
</div>



        
<hr>        


<strong class="lead1 mb-2 font-weight-bold text-primary text-uppercase">Skills</strong>

<div class="media mb-3">
    <div class="media-body">
<p class="mt-2"><?php  for($x=0;$x<count($skillsets);$x++){
                                                          ?>
    <span class="btn btn-sm bg-secondary-two text-dark font-weight-bold btn-rounded mb-2 display4">
    <?php echo $skillsets[$x]; ?>  </span>
                                                        <?php  }
                                                        ?>

    </p>
    </div>
</div>


<hr>

<div class="mb-3 mt-3 ">
    
<strong class="lead1 mb-2 font-weight-bold text-primary purpletitle text-uppercase">Work Experience</strong>

<br><br>




<div class="media mb-3">
    <div class="media-body">
        <span class="lead1 mt-0 mb-0"><strong><?php echo $candidate_work1; ?></strong></span>
        <p class="mb-0"><?php echo $candidate_work_company1; ?><br>
        <span class="dotted1"><?php echo $candidate_work_sdate1 ?></span> - <span class="dotted1"><?php echo $candidate_work_edate1; ?></span></p>
    </div>
</div>
   




<div class="media mb-3">
    <div class="media-body">
        <span class="lead1 mt-0 mb-0"><strong><?php echo $candidate_work2; ?></strong></span>
        <p class="mb-0"><?php echo $candidate_work_company2; ?> <br>
        <span class="dotted1"><?php echo $candidate_work_sdate2; ?></span> - <span class="dotted1"><?php echo $candidate_work_edate2; ?></span></p>
    </div>
</div>
   




  


 
 
 
  
 
 
 
 
 
   

</div>
    
    
          
          
 <br>



<div class="mb-3 mt-3 ">
<strong class="font-weight-bold text-primary purpletitle text-uppercase">Education</strong><br><br>



<div class="media mb-3">
    <div class="media-body">
        <span class="lead1 mt-0 mb-0"><strong><?php echo $candidate_10_name; ?></strong></span>
        <p class="mb-0">
            10th Grade or Equivalent<br>
            <span class="dotted1"><?php echo $candidate_10_start; ?></span> - <span class="dotted1"><?php echo $candidate_10_end; ?></span>
                        <span class="ml-2">
                        <?php echo $candidate_10_score; ?>            </span>
               
        </p>
    </div>
</div>
  




<div class="media mb-3">
    <div class="media-body">
        <span class="lead1 mt-0 mb-0"><strong><?php echo $candidate_12_name; ?></strong></span>
        <p class="mb-0">
        12th Grade or Equivalent<br>
        <span class="dotted1"><?php echo $candidate_12_start; ?></span> -<span class="dotted1"><?php echo $candidate_12_end; ?></span>
                <span class="ml-2">
                <?php echo $candidate_12_score; ?>        </span>
           
        </p>
    </div>
</div>
  







<div class="media mb-3">
    <div class="media-body">
        <span class="lead1 mt-0 mb-0"><strong><?php echo $candidate_clg1_name; ?></strong></span>
        <p class="mb-0"><?php echo $candidate_clg1_course; ?><br>
        <span class="dotted1"><?php echo $candidate_clg1_start; ?></span> - <span class="dotted1"><?php echo $candidate_clg1_end; ?></span>
        7.72   
        </p>
    </div>
</div>















       
</div>             





<hr>





<strong class="text-primary font-weight-bold text-uppercase blogmini">Salary Information</strong><br>

<div class="media mb-3">
    <div class="media-body">


<div class="">
<div class="row">
<div class="col-6 col-md-6">
<span class="text-dark font-weight-bold">Current Annual Package</span><br>
INR <?php echo $candidate_current_package; ?></div>
<div class="col-6 col-md-6">
<span class="text-dark font-weight-bold">Expected Annual Package</span><br>
INR <?php echo $candidate_expected_package; ?></div>
</div>

<br>

<div class="row">
<div class="col-6 col-md-6">
<span class="text-dark font-weight-bold">Notice Period &amp; Availability</span><br>
<?php echo $candidate_availability; ?></div>

</div>


</div>



<p>&nbsp;</p>


</div>
</div>

 
    
    

        </div>
        
        
        <div class="card border">
<div class="card-body">
<h5 class="mb-0 font-weight-bold mb-1 text-left text-uppercase text-primary blogmini">Virtual Interview Results</h5>
  
<?php 
include($root."/application/app.php");
//include($root."/application/app.php"); ?>
</div></div>
        
        
        </div>





        <div class="col-lg-4 mb-4 mb-lg-0 text-left d-none d-md-block  mb-lg-0 mt-0">
  
<script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
 // alert("Copied the text " + copyText.value);
  alert("Copied the profile.");
}
</script>













  <!-- include Google hosted jQuery Library -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#btn-subscribe').click(function(e){
        e.preventDefault();

        var subsemail = $("#subsemail").val();
        //alert(subsemail);
        
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/user/set/subscribe/",
            dataType: "json",
            data: {email:subsemail},            
            success : function(data){
                if (data.code == "200")
                {
                    $(".subs-success").show(); 
                    $(".subs-error").hide(); 
                    $("#subsform").hide();
                    $(".subs-success").html(""+data.msg+"");
                    $(".subs-success").css("display","block");
                } 
                else {
                    //alert("Success: " +data.msg);
                    $(".subs-error").html(""+data.msg+"");
                    $(".subs-error").css("display","block");
                }
            }
        });


      });
  });
</script>


















    
<!--
          <div class="mb-3">
            <a class="btn btn-primary btn-rounded btn-wide transition-3d-hover mb-2 mb-sm-0 mr-3" href="https://quantumhunts.com/signup">Create Account</a>
            <a class="btn btn-outline-primary btn-rounded btn-wide transition-3d-hover mb-2 mb-sm-0" href="https://quantumhunts.com/login">Login to Account</a>
          </div>
-->          
        </div>
      </div>


    </div>





                            </div></div>
        
        
        
            <div class="col-xl-4 col-lg-4 mt-4">
            <div class="card border cta-box" style="cursor:pointer;">
                    <div class="card-body">
                    <div class="col-sm-6 m-0 p-2 pt-0 card border" style="margin-top:10px;width=100%;-webkit-box-flex: 0;
                    -ms-flex: 0 0 100%;
                    flex: 0 0 100%;
                    max-width: 100%;">   
                     <h4 class="header-title mb-3">Schedule an Interview/Meeting </h4>                               
                    <ul class="nav nav-tabs tab-grad mt-3">
		<li class="nav-item "> <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" data-toggle="tab" href="#home1">Assessment  </a> </li>
		<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="#profile1">Meeting</a> </li>
		</ul>                                   
                <div class="tab-content" id="asynchronous_interview">
                <div class="tab-pane active" id="home1">
                <p>Schedule a Virtual Interview</p>
                <form>
                <label for="interview_tag">Question set: </label>    
                <select id="interviewvalue" class="form-control">
                <?php for($x=0;$x<count($set_id);$x++){ ?>
                    <option id="<?php echo $set_id[$x]; ?>" value="<?php echo $set_id[$x]; ?>" > <?php echo $set_name[$x].",".$sub_name[$x]."("  ?> <?php echo $set_complexity[$x]." )"; ?> </option>
                    <?php } ?>      
                </select>
                <br>
				<label>Meeting  subject</label>
<input type="text" class="form-control" id="fsub" name="fname" placeholder="Enter the subject for the Meeting">
<br>
    <label>Interview available from:</label>
    
    <div class="input-group date" data-provide="datepicker">
            <input type="text" class="form-control" id="startdate" value="">
            <div class="input-group-addon">
                <span class="glyphicon glyphicon-th"></span>
            </div>
       </div>
    <br>
    <label>Complete Interview By:</label>
    <div class="input-group date" data-provide="datepicker">
            <input type="text" class="form-control" id="enddate">
            <div class="input-group-addon">
                <span class="glyphicon glyphicon-th"></span>
            </div>
        </div>
    
    <button class="btn-primary btn-sm mt-2" type="button" id="interview_submit">Schedule</button> 
    <br><br>
    </form>
    <div class="alert alert-primary" id="interviewsuccessmsg" style="display:none;"></div>
        <div class="alert alert-danger" id="interviewfailuremsg" style="display:none;"></div>  <br>
        </div>
        
        <div class="tab-pane " id="profile1">
        <form>
        <p>Schedule a Virtual meeting</p>
        <label>Mode:</label>
        <select class="form-control " id="interview_meet">
        <option>Google Meet</option>
        <option>Zoom Meeting</option>
        <option>Webex Meeting</option>
        <option>Face to Face </option>
        </select>
        <br>
        <label>Enter the meeting link/Location:</label>
        <input class="form-control" type="text" id="link_meeting" placeholder="Paste the Meeting Link">
        <br>
        <label> Start Date/Time:</label>
        <div class="input-group input-group-merge">
                <div class="input-group-append">
                        <div class="input-group date" data-provide="datepicker">
                            <input type="text" class="form-control " value="07/23/2021" id="meet_start_date">
                            <div class="input-group-addon">
                                <span class="glyphicon glyphicon-th"></span>
                            </div>
                        </div>
                </div>
                <div class="input-group-append">
                        <div class="input-group">
                                <input type="text" class="form-control " data-toggle="timepicker" data-show-meridian="false" id="meet_start_time">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="dripicons-clock"></i></span>
                                </div>
                        </div>
                </div>
            </div>
                   <br>
        <label> End Date/Time: </label>
        <div class="input-group input-group-merge">
            <div class="input-group-append">
                    <div class="input-group date" data-provide="datepicker">
                            <input type="text" class="form-control " value="07/23/2021" id="meet_end_date">
                            <div class="input-group-addon">
                                <span class="glyphicon glyphicon-th"></span>
                            </div>
                        </div>
                               
            </div>
            <div class="input-group-append">
                        <div class="input-group">
                                <input type="text" class=" form-control " data-toggle="timepicker" data-show-meridian="false" id="meet_end_time"> 
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="dripicons-clock"></i></span>
                                </div>
                        </div>
            </div>
        </div>
    <br>
        <button class="btn-primary btn-sm mt-2" type="button" id="meet_submit">Schedule </button> 
    <br><br>
         </form></div>
         
         <div class="alert alert-primary" id="meetingsuccessmsg" style="display:none;"></div>
        <div class="alert alert-danger" id="meetingfailuremsg" style="display:none;"></div>  <br>
        </div>
 </div>




                            </div></div></div>
                        
                        
                        
                        
                        
                        
                        
                        
                        </div>

                           

                        </div>


<?php
include($root."/jobs/footer.php");  ?>

            <script type="text/javascript">
            $(document).ready(function() {  
                $('#interview_submit').click(function(){
                    var set_num= $("#interviewvalue").val();
					 var meeting_sub = $("#fsub").val();
                    var start_date1 = $("#startdate").val(); 
                    var end_date1 = $("#enddate").val();
                    var admin_user_id =  '<?php echo $r_id; ?>';
                    var application_id = '<?php echo $a_id; ?>';
                    var company_name =  '<?php echo $job_company; ?>';
                    var job_name ='<?php echo $job_title; ?>';
                    var applicant_user_id = '<?php echo $c_id; ?>';

               
                $.ajax({
                type: "POST",
                url: "http://localhost/application/application.php",
                dataType: "json",       
                data: {applicant_user_id:applicant_user_id,end_date1:end_date1,start_date1:start_date1,
                    job_name:job_name,company_name:company_name,set_num:set_num,application_id:application_id,admin_user_id:admin_user_id,meeting_sub:meeting_sub},            
                success : function(data){
                    //alert(data.code);
                    if (data.code == "200")
                    {
                        //alert(data.msg);
                        $("#interviewsuccessmsg").show();  
                        $("#interviewsuccessmsg").html(data.msg);
                        $("#interviewsuccessmsg").fadeOut(5000);
                        $("#interviewlist").load("https://quantumhunts.com/dev/video-record/2/interview_list/?id=707");  
                    } 
                    else
                    {
                        //alert(data.msg);
                        $("#interviewfailuremsg").show();  
                        $("#interviewfailuremsg").html(data.msg);   
                        $("#interviewfailuremsg").fadeOut(5000);
                    }                 
                }
            });
            
                });
            });
                </script>
            <script type="text/javascript">
            $(document).ready(function() {  
                $('#meet_submit').click(function(){
                    var meet_platform = $("#interview_meet").val();
                    var meet_link = $("#link_meeting").val();
                    var meet_start_date1 = $("#meet_start_date").val();
                    var meet_start_time = $("#meet_start_time").val();
                    var meet_end_date = $("#meet_end_date").val();
                    var meet_end_time = $("#meet_end_time").val();
                     //var today = Date("j-M-Y, H:i");
                    //starting_date = dateFormat(start_date) +", 00:00";//2021-01-08 00:00 
                    //start_date = start_date +" 00:00";
                    var admin_user_id =  '<?php echo $r_id; ?>';
                    var application_id = '<?php echo $a_id; ?>';
                    var company_name =  '<?php echo $job_company; ?>';
                    var job_name ='<?php echo $job_title; ?>';
                    var applicant_user_id = '<?php echo $c_id; ?>';
                    
                    
                   
              
                    //var time_difference = ending_date_time.gethours() - meet_start_time;
                    //alert(meet_platform);
                    //alert(meet_link);
                    //alert(start_date_time);
                    //alert(end_date_time);
                    //alert(date1);
                    //alert(date2);
                    //alert(starting_date_time);
                    //alert(ending_date_time);
                    //alert(time_difference)
                    
                    $.ajax({
                type: "POST",
                url: "http://localhost/application/application_meet.php",
                dataType: "json",       
                data: {meet_platform:meet_platform,meet_link:meet_link,meet_start_date1:meet_start_date1,applicant_user_id:applicant_user_id,
                    job_name:job_name,company_name:company_name,meet_start_date1:meet_start_date1,meet_start_time:meet_start_time,meet_end_date:meet_end_date,meet_end_time:meet_end_time,application_id:application_id,admin_user_id:admin_user_id},            
                success : function(data){
                    //alert(data.code);
                    if (data.code == "200")
                    {
                        //alert(data.msg);
                        $("#meetingsuccessmsg").show();  
                        $("#meetingsuccessmsg").html(data.msg);
                        $("#meetingsuccessmsg").fadeOut(5000);
                        $("#interviewlist").load(""); 
                    } 
                    else
                    {
                        //alert(data.msg);
                        $("#meetingfailuremsg").show();  
                        $("#meetingfailuremsg").html(data.msg);   
                        $("#meetingfailuremsg").fadeOut(5000);
                    }                 
                }
            });
            
                });
            });
                </script>




