<?php
session_start();
?>
<!DOCTYPE html>
<!-- saved from url=(0032)https://vja.com/signup/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style class="vjs-styles-defaults">
      .video-js {
        width: 300px;
        height: 150px;
      }

      .vjs-fluid {
        padding-top: 56.25%
      }
    </style><style class="vjs-styles-dimensions">
      .my-video-dimensions {
        width: 640px;
        height: 264px;
      }

      .my-video-dimensions.vjs-fluid {
        padding-top: 56.60377358490566%;
      }
    </style>
        
        <title>Sign Up | VJA</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Signup with world&#39;s best &amp; number 1 job portal, recruitment consultancy, agency" name="description">
        <meta content="QUANTUMHUNTS" name="author">
<!-- App favicon -->
<link rel="icon" href="http://localhost/view-job/Jobs%20_%20QUANTUMHUNTS_files/square1_qh.png" type="image/icon type">

<link rel="shortcut icon" href="https://vja.com/user/assets/favicon/favicon.ico">

<!--
<link rel="shortcut icon" sizes="16x16 24x24 32x32 48x48 64x64" href="https://vja.com/user/assets/favicon/favicon.ico">
<link rel="apple-touch-icon" sizes="57x57" href="https://vja.com/user/assets/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="https://vja.com/user/assets/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="72x72" href="https://vja.com/user/assets/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="https://vja.com/user/assets/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="https://vja.com/user/assets/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="https://vja.com/user/assets/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="https://vja.com/user/assets/favicon/apple-icon-152x152.png">
<meta name="application-name" content="QuantumHunts QuantumHunts QuantumHunts">
<meta name="msapplication-TileImage" content="https://vja.com/user/assets/favicon/apple-icon-144x144.png">
<meta name="msapplication-TileColor" content="#2A2A2A">
-->



<!--Test relative CSS -->
        <link href="./Sign Up _ QUANTUMHUNTS_files/icons.min.css" rel="stylesheet" type="text/css">
        <link href="./Sign Up _ QUANTUMHUNTS_files/app-modern.min.css" rel="stylesheet" type="text/css" id="light-style">


        <!-- App css  - full URL
        <link href="https://vja.com/user/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="https://vja.com/user/assets/css/app-modern.min.css" rel="stylesheet" type="text/css" id="light-style" />-->
 
        <!--<link href="https://vja.com/user/assets/css/app-modern-dark.min.css" rel="stylesheet" type="text/css" id="dark-style" />-->

  <!-- Css Files-->
<!--  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
<!--  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css"> -->
  <link rel="stylesheet" type="text/css" href="./Sign Up _ QUANTUMHUNTS_files/bootstrap-tokenfield.min.css">

<!---->

  <script src="./Sign Up _ QUANTUMHUNTS_files/jquery.min.js.download"></script>
  <script src="./Sign Up _ QUANTUMHUNTS_files/jquery-ui.min.js.download"></script>
  <script src="./Sign Up _ QUANTUMHUNTS_files/bootstrap-tokenfield.js.download"></script>

        
    <!-- Summernote css -->
    <link href="./Sign Up _ QUANTUMHUNTS_files/summernote-bs4.css" rel="stylesheet" type="text/css">
        
    <link href="./Sign Up _ QUANTUMHUNTS_files/simplemde.min.css" rel="stylesheet" type="text/css">        



<link rel="stylesheet" href="./Sign Up _ QUANTUMHUNTS_files/dzsparallaxer.css">
<link rel="stylesheet" href="./Sign Up _ QUANTUMHUNTS_files/dzsparallaxer.scss">

<link rel="stylesheet" href="./Sign Up _ QUANTUMHUNTS_files/slick.css">


<link href="./Sign Up _ QUANTUMHUNTS_files/video-js.css" rel="stylesheet">
 
 <!-- City -->
<link href="./Sign Up _ QUANTUMHUNTS_files/index.css" rel="stylesheet">

<link rel="stylesheet" href="./Sign Up _ QUANTUMHUNTS_files/animate.css">

    <link href="./Sign Up _ QUANTUMHUNTS_files/custom.css" rel="stylesheet" type="text/css"> 

  <style>

    
body
{
    //background-color:#eaeaea !important;
    //background-color:whitesmoke !important;
    //background-color:white !important;
   //background-image: radial-gradient( circle 343px at 46.3% 47.5%,  rgba(242,242,242,1) 0%, rgba(241,241,241,1) 72.9% );
}


   
   </style>
   
   
   <!-- Load Facebook SDK for JavaScript 
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v6.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

     
     
      <div class="fb-customerchat"
        attribution=setup_tool
        page_id="616766792169119"
  theme_color="#0073b1">
      </div>
      -->
      


   

        <!-- App favicon
        <link rel="shortcut icon" href="https://vja.com/assets/img/favicon.ico">

       
        <link href="https://vja.com/user/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="https://vja.com/user/assets/css/app-modern.min.css" rel="stylesheet" type="text/css" id="light-style" />
-->
    <style>
    body.authentication-bg {
    background-image: url(https://coderthemes.com/hyper/modern/assets/images/bg-pattern-light.svg1);
    background-size: cover;
    background-position: center;
}
</style></head>


    <body class="authentication-bg mt-3" data-leftbar-theme="dark" cz-shortcut-listen="true">

        <div class="account-pages mt-3 mb-3">
            <div class="container mt-3">
                <div class="row justify-content-center no-gutters1 mt-3 card1 border1 align-self-center" style="flex-direction:row !important;">
                    <div class="col-md-5 ">
                        <div class="card border  shadow1" style="background-color1: #f5f7fa !important;">
                            <!-- Logo -->

<!--                            <div class="card-header pt-2 pb-2 text-center bg-white">
                                <a href="" class="text-dark font-weight-bold">QuantumHunts - Sign up
                                    <span></span>
                                </a>
                            </div>
-->
                            <div class="card-body p-4">
                                
                                <div class="text-center w-75 m-auto">
                                    <img src="./Sign Up _ QUANTUMHUNTS_files/square1_qh.png" alt="" height="40"> <span class="pb-0 mb-0 mt-0 pt-0 font-style-italics" style="line-height:14px;line-spacing:14px;">Job Seeker</span>
                                    <!--<h4 class="text-dark-50 text-center text-dark mt-0 font-weight-bold">Join Us</h4>-->
                                    <p class="text-dark mb-4 pt-2">Don't have an account? Create your account, it takes less than a minute </p>
                                </div>

                        <!-- form -->
                        <form1 autocomplete="none-off">
                            
 
                     
                             
    
    
    <div class="form-group text-center">     
    <label for="fullname text-dark text-center"><span class="text-center">Candidate Connect</span></label>    
    <div class="mt-0 text-center">
    <div class="custom-control custom-radio custom-control-inline" style="display:none;">
    <input type="radio" id="customRadio3" name="customRadio1" class="custom-control-input" vale="1" checked="">
    <label class="custom-control-label" for="customRadio3">Candidate</label>
    </div>
    <div class="custom-control custom-radio custom-control-inline" style="display:none;">
    <input type="radio" id="customRadio4" name="customRadio1" class="custom-control-input" value="2">
    <label class="custom-control-label" for="customRadio4">Employer</label>
    </div>
    </div>
    </div>
                            
             
                            <div class="form-group">
                                <label for="fullname">First Name</label>
                                <input class="form-control  form-control-sm" type="text" id="fename" placeholder="" required="" autocomplete="off-none" onfocus="this.removeAttribute(&#39;readonly&#39;);">
                            </div>
                            <div class="form-group">
                                <label for="fullname">Last Name</label>
                                <input class="form-control  form-control-sm" type="text" id="lename" placeholder="" required="" autocomplete="off-none">
                            </div>                            
                            <div class="form-group">
                                <label for="dob">Date of Birth</label>
                                <input class="form-control  form-control-sm" type="text" id="dob" data-provide="datepicker" data-date-format="d-M-yyyy" data-date-autoclose="true" required="" autocomplete="off-none">
                                <small>E.g. 10-Jun-1999</small>
                            </div>                             

                            <div class="form-group">
                                <label for="gender">Gender</label>
                                <select class="form-control form-control-sm" id="gender">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Unspecified">Unspecified</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="emailaddress">Email address</label>
                                <input class="form-control  form-control-sm" type="email" id="femail" required="" placeholder="Enter your email" autocomplete="off-none">
                                <small>E.g. username@gmail.com</small>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input class="form-control  form-control-sm" type="password" required="" id="password" placeholder="Enter your password" autocomplete="off-none">
                                <small>Use 8 or more characters</small>
                            </div>
<!--                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="checkbox-signup">
                                    <label class="custom-control-label" for="checkbox-signup">I accept <a href="javascript: void(0);" class="text-muted">Terms and Conditions</a></label>
                                </div>
                            </div>
-->
                            <div class="form-group">  
                                <div class="display-error  alert alert-danger" style="display: none">
                                </div>
                            </div>
                            <div class="form-group mb-0 text-left">
                                <button class="btn btn-primary" id="submit" type="1submit">Sign Up </button>
                            </div>
                            <small class="mt-3 pt-2"><br>By clicking “Sign up”, you agree to our Terms of Service and Privacy Statement. </small>
                            
                        </form1>
                        <!-- end form-->








  <!-- include Google hosted jQuery Library -->
<script src="./Sign Up _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

   <script> 
        $("#fename").focus(); 
    </script> 
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#submit').click(function(e){
        e.preventDefault();

    //var usertype = $('input[name=customRadio1]:checked').val();
        //alert(usertype);
       //var usertype='on';

        var email = $("#femail").val();
        var firstname = $("#fename").val();
        var lastname = $("#lename").val();
        //var email_code = $("#email_code").val();
        //var countrycode = $("#countrycode").val();   
        //var countrycode =$('#countrycode option:selected').val();
         var gender = $('#gender').val();
        //var mobile = $("#mobile").val(); 
        var password = $("#password").val(); 
        //var title = $("#title").val();        
        var dob = $("#dob").val();                
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/candidate-sign-up/sign-up.php",
            dataType: "json",
            data: {firstname:firstname,lastname:lastname,dob:dob,email:email,gender:gender,password:password},            
            success : function(data){
                if (data.code == "201")
                {
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    //location.href = "https://vja.com/employer/post/jobs/";
                }                                    
                else {
                    //alert("Success: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    location.href = "http://localhost/edit-profile/";
                }
            }
        });


      });
  });
</script>


                        <div class="row mt-3">
                            <div class="col-12 text-center">
                                <p class="text-muted">Already have account? <a href="http://localhost/login/" class="text-primary ml-1"><b>Log In</b></a></p>
                            </div> <!-- end col-->
                        </div>
                        <!-- end row -->




                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->


                    </div> <!-- end col -->
                    

                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end page -->


        <div class="card-body">
        <footer class="footer footer-alt mb-2 mt-3">
            <p>© VJA</p>
        </footer>
        </div>


<!-- Signup modal-->

<div id="help-modal" class="modal fade" tabindex="1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="background-image1: radial-gradient( circle farthest-corner at 18.7% 37.8%,  rgba(250,250,250,1) 0%, rgba(225,234,238,1) 90% );">

            <div class="modal-body">
                <div class="text-center mt-2 mb-0">
                    
                    <span class="text-success">
                        <span><img src="http://localhost/recruiter-sign-up/Sign%20Up%20_%20QUANTUMHUNTS_files/square1_qh.png" alt="" height="32" width="32"></span>
                    </span>
                </div>
                
                <div class="card-body text-center">

                    <strong class="text-center text-primary blogmini">QUANTUMHUNTS</strong>
                    <span class="d-block text-center mb-2"> Help &amp; Support</span>

                <div class="row auto-mx float-center text-center"> 
                <div class="col-2">
                </div>
                <div class="col-8">
                <p class="text-center mb-2">Use the below form to reach us for any request or enquires. Average response time less than 24 hours.</p>
                </div>
                <div class="col-2">
                </div>
                </div>

                </div>

                <form class="pl-3 pr-3" id="callbackform" action="https://vja.com/signup/#">
                    
                    
                    
<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input class="form-control form-control-sm" type="name" id="name" required="" placeholder="" value=" ">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="company">Company</label>
                        <input class="form-control form-control-sm" type="text" id="companyname" required="" placeholder="">
                    </div>
</div> <!-- end col -->
</div>                    


<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input class="form-control form-control-sm" type="phone" required="" id="phone" value=" ">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">E-Mail</label>
                        <input class="form-control form-control-sm" type="email" required="" id="email" placeholder="" value="">
                    </div>
</div> <!-- end col -->
</div>                    
                    
                    



<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="reason">Subject</label>
                        <select class="form-control form-control-sm" id="reason">
                        <option value="Mentorship">Career development</option>  
                        <option value="Courses">Courses</option>              
                        <option value="Business">Business Enquiry</option>
                        <option value="QH-RECRUITER">Premium Plans</option>                 
                        <option value="Help">Help</option>                
                        <option value="AccountIssues">My QH account</option>                        
                        <option value="Issues">Issues &amp; Complaints</option>                                                
                        </select>                        
                    </div>                    

</div>
</div>          





<div class="row">
<div class="col-md-12">
                    <div class="form-group">
                        <label for="comments">Comments</label>
                        <textarea class="form-control" id="comments" placeholder=""></textarea>
                    </div>                    
</div> <!-- end col -->
</div>          





                    


    
                    <div class="form-group text-left">
                                <div class="display-callback-error  alert alert-danger" style="display: none">
                                </div>

                        <button class="btn btn-primary" type="submit" id="callbacksubmit">Submit </button>
                        <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                    </div>
                    
                    
                    <small>By clicking "Submit" I agree to be contacted at the number provided with more information or offers about <span class="text-uppercase text-primary">QuantumHunts</span>. I understand these calls or texts may use computer-assisted dialing or pre-recorded messages.</small>

                </form>
                
                <div class="form-group">  
                                <div class="display-callback-success  alert alert-info" style="display: none">
                                   
                                </div>
                </div>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->









  <!-- include Google hosted jQuery Library -->
<script src="./Sign Up _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#callbacksubmit').click(function(e){
        e.preventDefault();

    var usertype = $('input[name=customRadio1]:checked').val();
        //alert(usertype);

        var pageurl="https://vja.com/signup/";
        var email = $("#email").val();
        var phone = $("#phone").val();        
        var name = $("#name").val();
        var company = $("#companyname").val();
        var reason =$('#reason option:selected').val();
        var comments = $("#comments").val(); 
        //var comments = "";
        
        //alert(email+name+phone+reason+comments+company);
        
        $.ajax({
            type: "POST",
            url: "https://vja.com/user/set/callbacks/",
            dataType: "json",
            data: {name:name,email:email,phone:phone,company:company,reason:reason,comments:comments,pageurl:pageurl},            
            success : function(data){
                if (data.code == "200")
                {
                    $(".display-callback-success").show(); 
                    $(".display-callback-error").hide(); 
                    $("#callbackform").hide();
                    $(".display-callback-success").html(""+data.msg+"");
                    $(".display-callback-success").css("display","block");
                } 
                else {
                    //alert("Success: " +data.msg);
                    $(".display-callback-error").html(""+data.msg+"");
                    $(".display-callback-error").css("display","block");
                }
            }
        });


      });
  });
</script>






<!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
<script src="./Sign Up _ QUANTUMHUNTS_files/videojs-ie8.min.js.download"></script>

<script src="./Sign Up _ QUANTUMHUNTS_files/video.js.download"></script>

<script src="./Sign Up _ QUANTUMHUNTS_files/custom.js.download"></script>




        <!-- bundle -->
        <script src="./Sign Up _ QUANTUMHUNTS_files/vendor.min.js.download"></script>
        <script src="./Sign Up _ QUANTUMHUNTS_files/app.min.js.download"></script>        
    

</body></html>