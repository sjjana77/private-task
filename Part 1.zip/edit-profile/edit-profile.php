<?php
session_start();
$flow="1";
$code=200;
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$candidate_availability=$_POST['noticecode'];
$candidate_phone=$_POST['mobile'];
$candidate_title=$_POST['title'];
$candidate_about=$_POST['userbio'];
$candidate_skillsets=$_POST['skillset'];
$candidate_industry1=$_POST['industry'];
$candidate_current_package=$_POST['current_ctc'];
$candidate_expected_package=$_POST['expected_ctc'];
$candidate_current_location=$_POST['city'];
$candidate_expected_location=$_POST['preferredcity'];
$candidate_10_name=$_POST['school10'];
$candidate_10_start=$_POST['start10'];
$candidate_10_end=$_POST['end10'];
$candidate_10_score=$_POST['score10'];
$candidate_12_name=$_POST['school12'];
$candidate_12_start=$_POST['start12'];
$candidate_12_end=$_POST['end12'];
$candidate_12_score=$_POST['score12'];
$candidate_clg1_name=$_POST['school1'];
$candidate_clg1_course=$_POST['course1'];
$candidate_clg1_start=$_POST['course1start'];
$candidate_clg1_end=$_POST['course1end'];
$candidate_clg1_score=$_POST['score1'];
$candidate_clg2_name=$_POST['school2'];
$candidate_clg2_course=$_POST['course2'];
$candidate_clg2_start=$_POST['course2start'];
$candidate_clg2_end=$_POST['course2end'];
$candidate_clg2_score=$_POST['score2'];
$candidate_work1=$_POST['role1'];
$candidate_work_company1=$_POST['company1'];
$candidate_work_sdate1=$_POST['start1'];
$candidate_work_edate1=$_POST['end1'];
$candidate_work2=$_POST['role2'];
$candidate_work_company2=$_POST['company2'];
$candidate_work_sdate2=$_POST['start2'];
$candidate_work_edate2=$_POST['end2'];
$candidate_industry='';
$c_id=$_SESSION['candidate_id'];
//$bio=$_POST["userbio"];
foreach($candidate_industry1 as $func)  
   {  
      $candidate_industry .= $func.",";  
   } 
//$candidate_img_url=$_POST[''];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
    $sql="UPDATE vj_candidate set candidate_availability='$candidate_availability',candidate_phone='$candidate_phone',
    candidate_title='$candidate_title',
    candidate_skillsets='$candidate_skillsets',candidate_industry='$candidate_industry',
    candidate_current_package='$candidate_current_package',
    candidate_expected_package='$candidate_expected_package',candidate_10_name='$candidate_10_name',
    candidate_10_start='$candidate_10_start',candidate_10_end='$candidate_10_end',
    candidate_10_score='$candidate_10_score',candidate_12_name='$candidate_12_name',candidate_12_start='$candidate_12_start',
    candidate_12_end='$candidate_12_end',candidate_12_score='$candidate_12_score',candidate_clg1_name='$candidate_clg1_name',
    candidate_clg1_course='$candidate_clg1_course',candidate_clg1_start='$candidate_clg1_start',
    candidate_clg1_end='$candidate_clg1_end',candidate_clg1_score='$candidate_clg1_score',candidate_clg2_name='$candidate_clg2_name',
    candidate_clg2_course='$candidate_clg2_course',candidate_clg2_start='$candidate_clg2_start',candidate_clg2_end='$candidate_clg2_end',
    candidate_clg2_score='$candidate_clg2_score',candidate_work1='$candidate_work1',candidate_work_company1='$candidate_work_company1',
    candidate_work_sdate1='$candidate_work_sdate1',candidate_work_edate1='$candidate_work_edate1',candidate_work2='$candidate_work2',
    candidate_work_company2='$candidate_work_company2',candidate_work_sdate2='$candidate_work_sdate2',
    candidate_work_edate2='$candidate_work_edate2',candidate_current_location='$candidate_current_location',
    candidate_expected_location='$candidate_expected_location',candidate_about='$candidate_about' where candidate_id='$c_id'" ;
    if ($conn->query($sql)==TRUE){
        echo json_encode(['code'=>400, 'msg'=>'success']);
        $conn->close(); 
        exit;
    }  
    else{
        echo json_encode(['code'=>200, 'msg'=>$c_id]);
        $conn->close(); 
        exit;
    }
?>