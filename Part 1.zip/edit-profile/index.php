<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];

?>
<!DOCTYPE html>
<!-- saved from url=(0045)https://quantumhunts.com/user/manage/profile/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Edit Profile | VJA</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Edit your QUANTUMHUNTS resume on the go" name="description">
        <meta content="QUANTUMHUNTS" name="author">
        <?php
      include($root."/jobs/header.php");

        ?>

        <!-- End Preloader-->

        <!--
        <div style="background:#234099;background-image1: radial-gradient( circle farthest-corner at 10% 20%,  rgba(226,240,254,1) 0%, rgba(255,247,228,1) 90% ); background-color1: #E1E7ED  !important;min-height:10px;max-height:30px;height:auto;" class=" m-0 p-0 pl-2 pt-1 pb-1 navbar-custom topnav-navbar text-light bg-primary1 topnav-navbar-primary" style="background1: black1;"><marquee1><Strong><i class="uil uil-shield-exclamation font-weight-bold"></i> Covid-19 Support: </Strong> We are ready to help with your job search. Sign up today.</marquee1></div> 
        -->



        
        <!-- Topbar Start -->
        
        <!-- end Topbar -->
        
        

        <!-- Topbar Start -->
    

    

        
        
        
   
        
<!--
<p>&nbsp;</p>        
    -->    
        
        


        <!-- Start Content-->
        <div class="container-fluid">

            <!-- Begin page -->
            <div class="wrapper">

                <!-- ========== Left Sidebar Start ========== -->

                               
                                
<div class="left-side-menu left-side-menu-detached mm-active shadow1" style="background-color:transparent;background1:#fafbfe;margin-top:0px;">
    
    <div class="leftbar-user1 border1">


	

                        <a href="javascript: void(0);">
                            <!--<img src="assets/images/users/avatar-1.jpg" alt="user-image" height="42" class="rounded-circle shadow-sm">-->
                            <span class="leftbar-user-name"></span>
                        </a>




                    </div>

<!-- <div class="card-header bg-primary text-light">    QuantumHunts   </div>    -->
    
                    <ul class="metismenu side-nav mm-show">

                        <!--<li class="side-nav-title side-nav-item text-info">Navigation</li>-->

<!--
                        <li class="side-nav-item">
                            <a href="https://quantumhunts.com/jobs/home/" class="side-nav-link">
                                <i class="uil-home-alt text-dark"></i>
                                <span> Home </span>
                            </a>
                        </li>
-->                        


    	    
    
                    <!--- Sidemenu -->


            
                                        
                        <li class="side-nav-item mb-0 pb-0">
                            <a href="https://quantumhunts.com/pro/vishnu-varthan-20210725124136" class="side-nav-link  mb-0 pb-0">
                                <img src="./Edit Resume _ QUANTUMHUNTS_files/3459153.svg" height="18" class="mr-2 sidebaricon"> 
                                <span class="font-14">Profile </span>
                            </a>
                        </li>


                        <li class="side-nav-item mb-0 pb-0">
                            <a href="https://quantumhunts.com/jobs/" class="side-nav-link  mb-0 pb-0">
                                <img src="./Edit Resume _ QUANTUMHUNTS_files/2206371.svg" height="18" class="mr-2 sidebaricon"> 
                                <span class="font-14">Find Jobs </span>
                            </a>
                        </li>
                        
                        

                            <li class="side-nav-item mb-0 pb-0">
                            <a href="https://quantumhunts.com/user/view/jobs/" class="side-nav-link  mb-0 pb-0">
                                <img src="./Edit Resume _ QUANTUMHUNTS_files/2673032.svg" height="18" class="mr-2 sidebaricon"> 
                                <span class="font-14"> Applied </span>
                            </a>
                        </li>


                            <li class="side-nav-item mb-0 pb-0">
                            <a href="https://quantumhunts.com/create/post/" class="side-nav-link  mb-0 pb-0">
                                <img src="./Edit Resume _ QUANTUMHUNTS_files/1830934.svg" height="18" class="mr-2 sidebaricon"> 
                                <span class="font-14"> Publish blog </span>
                            </a>
                        </li>
                        
                        <hr>
                                               

                                            <!--

                            <li class="side-nav-item">
                            <a href="https://quantumhunts.com/user/post/company/" class="side-nav-link  mb-0 pb-0">
                                <i class="uil uil-bag-alt"></i> 
                                <span> Create a Company </span> 
                            </a>
                        </li>
                        -->

                                    

                       
                        
    	 
    	    
    

<p>&nbsp;</p>

                            
                        

                       

        
                    </ul>

                    <!-- Help Box 
                    <div class="help-box text-center">
                        <a href="javascript: void(0);" class="float-right close-btn text-body">
                            <i class="mdi mdi-close"></i>
                        </a>
                        <img src="https://coderthemes.com/hyper/modern/assets/images/help-icon.svg" height="90" alt="Helper Icon Image">
                        <h5 class="mt-3">Unlimited Access</h5>
                        <p class="mb-3">Upgrade to plan to get access to unlimited reports</p>
                        <a href="javascript: void(0);" class="btn btn-outline-primary btn-sm">Upgrade</a>
                    </div>
                    end Help Box -->
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>
                    <!-- Sidebar -left -->

                </div>
                <!-- Left Sidebar End -->

                <div class="content-page">
                    <div class="content">

                        <!-- start page title 
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Hyper</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Pages</a></li>
                                            <li class="breadcrumb-item active">Profile 2</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title"></h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 






<!-- Right modal -->

<div id="right-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" style="z-index:10000;">
    <div class="modal-dialog modal-sm modal-right">
        <div class="modal-content">
            <div class="modal-header border-0">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <div class="text-center">

                    <div data-setup="{}" fluid="false" preload="auto" class="video-js vjs-tech vjs-theme-city vjs-big-play-centered bg-light vjs-paused my-video-1-dimensions vjs-fluid vjs-controls-enabled vjs-workinghover vjs-v7 vjs-user-active" id="my-video-1" tabindex="-1" role="region" lang="en" aria-label="Video Player"><video id="my-video-1_html5_api" class="vjs-tech" preload="auto" fluid="false" data-setup="{}" tabindex="-1" role="application" src="/user/assets/videos/job-seeker/job-seekers-promotional.mp4">
                        <source src="/user/assets/videos/job-seeker/job-seekers-promotional.mp4" type="video/mp4">
                      </video><div class="vjs-poster vjs-hidden" aria-disabled="false"></div><div class="vjs-text-track-display" aria-live="off" aria-atomic="true"></div><div class="vjs-loading-spinner" dir="ltr"><span class="vjs-control-text">Video Player is loading.</span></div><button class="vjs-big-play-button" type="button" title="Play Video" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Play Video</span></button><div class="vjs-control-bar" dir="ltr"><button class="vjs-play-control vjs-control vjs-button" type="button" title="Play" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Play</span></button><div class="vjs-volume-panel vjs-control vjs-volume-panel-horizontal"><button class="vjs-mute-control vjs-control vjs-button vjs-vol-3" type="button" title="Mute" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Mute</span></button><div class="vjs-volume-control vjs-control vjs-volume-horizontal"><div tabindex="0" class="vjs-volume-bar vjs-slider-bar vjs-slider vjs-slider-horizontal" role="slider" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" aria-label="Volume Level" aria-live="polite" aria-valuetext="100%"><div class="vjs-volume-level"><span class="vjs-control-text"></span></div></div></div></div><div class="vjs-current-time vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Current Time&nbsp;</span><span class="vjs-current-time-display" aria-live="off" role="presentation">0:00</span></div><div class="vjs-time-control vjs-time-divider" aria-hidden="true"><div><span>/</span></div></div><div class="vjs-duration vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Duration&nbsp;</span><span class="vjs-duration-display" aria-live="off" role="presentation">0:32</span></div><div class="vjs-progress-control vjs-control"><div tabindex="0" class="vjs-progress-holder vjs-slider vjs-slider-horizontal" role="slider" aria-valuenow="0.00" aria-valuemin="0" aria-valuemax="100" aria-label="Progress Bar" aria-valuetext="0:00 of 0:32"><div class="vjs-load-progress" style="width: 41.16%;"><span class="vjs-control-text"><span>Loaded</span>: <span class="vjs-control-text-loaded-percentage">41.16%</span></span><div data-start="0" data-end="13.268" style="left: 0%; width: 100%;"></div></div><div class="vjs-mouse-display"><div class="vjs-time-tooltip" aria-hidden="true"></div></div><div class="vjs-play-progress vjs-slider-bar" aria-hidden="true" style="width: 0%;"><div class="vjs-time-tooltip" aria-hidden="true" style="right: 0px;">0:00</div></div></div></div><div class="vjs-live-control vjs-control vjs-hidden"><div class="vjs-live-display" aria-live="off"><span class="vjs-control-text">Stream Type&nbsp;</span>LIVE</div></div><button class="vjs-seek-to-live-control vjs-control" type="button" title="Seek to live, currently behind live" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Seek to live, currently behind live</span><span class="vjs-seek-to-live-text" aria-hidden="true">LIVE</span></button><div class="vjs-remaining-time vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Remaining Time&nbsp;</span><span aria-hidden="true">-</span><span class="vjs-remaining-time-display" aria-live="off" role="presentation">0:32</span></div><div class="vjs-custom-control-spacer vjs-spacer ">&nbsp;</div><div class="vjs-playback-rate vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><div class="vjs-playback-rate-value">1x</div><button class="vjs-playback-rate vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Playback Rate" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Playback Rate</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"></ul></div></div><div class="vjs-chapters-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-chapters-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Chapters" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Chapters</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-title">Chapters</li></ul></div></div><div class="vjs-descriptions-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-descriptions-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Descriptions" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Descriptions</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-item vjs-selected" role="menuitemradio" aria-disabled="false" tabindex="-1" aria-checked="true"><span class="vjs-menu-item-text">descriptions off</span><span class="vjs-control-text" aria-live="polite">, selected</span></li></ul></div></div><div class="vjs-subs-caps-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-subs-caps-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Captions" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Captions</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-item vjs-texttrack-settings" role="menuitem" aria-disabled="false" tabindex="-1"><span class="vjs-menu-item-text">captions settings</span><span class="vjs-control-text" aria-live="polite">, opens captions settings dialog</span></li><li class="vjs-menu-item vjs-selected" role="menuitemradio" aria-disabled="false" tabindex="-1" aria-checked="true"><span class="vjs-menu-item-text">captions off</span><span class="vjs-control-text" aria-live="polite">, selected</span></li></ul></div></div><div class="vjs-audio-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-audio-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Audio Track" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Audio Track</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"></ul></div></div><button class="vjs-picture-in-picture-control vjs-control vjs-button" type="button" title="Picture-in-Picture" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Picture-in-Picture</span></button><button class="vjs-fullscreen-control vjs-control vjs-button" type="button" title="Fullscreen" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Fullscreen</span></button></div><div class="vjs-error-display vjs-modal-dialog vjs-hidden " aria-describedby="my-video-1_component_368_description" aria-hidden="true" aria-label="Modal Window" role="dialog"><p class="vjs-modal-dialog-description vjs-control-text" id="my-video-1_component_368_description">This is a modal window.</p><div class="vjs-modal-dialog-content" role="document"></div></div><div class="vjs-modal-dialog vjs-hidden  vjs-text-track-settings" aria-describedby="my-video-1_component_373_description" aria-hidden="true" aria-label="Caption Settings Dialog" role="dialog"><p class="vjs-modal-dialog-description vjs-control-text" id="my-video-1_component_373_description">Beginning of dialog window. Escape will cancel and close the window.</p><div class="vjs-modal-dialog-content" role="document"><div class="vjs-track-settings-colors"><fieldset class="vjs-fg-color vjs-track-setting"><legend id="captions-text-legend-my-video-1_component_373">Text</legend><label id="captions-foreground-color-my-video-1_component_373" class="vjs-label">Color</label><select aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-color-my-video-1_component_373"><option id="captions-foreground-color-my-video-1_component_373-White" value="#FFF" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-color-my-video-1_component_373 captions-foreground-color-my-video-1_component_373-White">White</option><option id="captions-foreground-color-my-video-1_component_373-Black" value="#000" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-color-my-video-1_component_373 captions-foreground-color-my-video-1_component_373-Black">Black</option><option id="captions-foreground-color-my-video-1_component_373-Red" value="#F00" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-color-my-video-1_component_373 captions-foreground-color-my-video-1_component_373-Red">Red</option><option id="captions-foreground-color-my-video-1_component_373-Green" value="#0F0" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-color-my-video-1_component_373 captions-foreground-color-my-video-1_component_373-Green">Green</option><option id="captions-foreground-color-my-video-1_component_373-Blue" value="#00F" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-color-my-video-1_component_373 captions-foreground-color-my-video-1_component_373-Blue">Blue</option><option id="captions-foreground-color-my-video-1_component_373-Yellow" value="#FF0" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-color-my-video-1_component_373 captions-foreground-color-my-video-1_component_373-Yellow">Yellow</option><option id="captions-foreground-color-my-video-1_component_373-Magenta" value="#F0F" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-color-my-video-1_component_373 captions-foreground-color-my-video-1_component_373-Magenta">Magenta</option><option id="captions-foreground-color-my-video-1_component_373-Cyan" value="#0FF" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-color-my-video-1_component_373 captions-foreground-color-my-video-1_component_373-Cyan">Cyan</option></select><span class="vjs-text-opacity vjs-opacity"><label id="captions-foreground-opacity-my-video-1_component_373" class="vjs-label">Transparency</label><select aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-opacity-my-video-1_component_373"><option id="captions-foreground-opacity-my-video-1_component_373-Opaque" value="1" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-opacity-my-video-1_component_373 captions-foreground-opacity-my-video-1_component_373-Opaque">Opaque</option><option id="captions-foreground-opacity-my-video-1_component_373-SemiTransparent" value="0.5" aria-labelledby="captions-text-legend-my-video-1_component_373 captions-foreground-opacity-my-video-1_component_373 captions-foreground-opacity-my-video-1_component_373-SemiTransparent">Semi-Transparent</option></select></span></fieldset><fieldset class="vjs-bg-color vjs-track-setting"><legend id="captions-background-my-video-1_component_373">Background</legend><label id="captions-background-color-my-video-1_component_373" class="vjs-label">Color</label><select aria-labelledby="captions-background-my-video-1_component_373 captions-background-color-my-video-1_component_373"><option id="captions-background-color-my-video-1_component_373-Black" value="#000" aria-labelledby="captions-background-my-video-1_component_373 captions-background-color-my-video-1_component_373 captions-background-color-my-video-1_component_373-Black">Black</option><option id="captions-background-color-my-video-1_component_373-White" value="#FFF" aria-labelledby="captions-background-my-video-1_component_373 captions-background-color-my-video-1_component_373 captions-background-color-my-video-1_component_373-White">White</option><option id="captions-background-color-my-video-1_component_373-Red" value="#F00" aria-labelledby="captions-background-my-video-1_component_373 captions-background-color-my-video-1_component_373 captions-background-color-my-video-1_component_373-Red">Red</option><option id="captions-background-color-my-video-1_component_373-Green" value="#0F0" aria-labelledby="captions-background-my-video-1_component_373 captions-background-color-my-video-1_component_373 captions-background-color-my-video-1_component_373-Green">Green</option><option id="captions-background-color-my-video-1_component_373-Blue" value="#00F" aria-labelledby="captions-background-my-video-1_component_373 captions-background-color-my-video-1_component_373 captions-background-color-my-video-1_component_373-Blue">Blue</option><option id="captions-background-color-my-video-1_component_373-Yellow" value="#FF0" aria-labelledby="captions-background-my-video-1_component_373 captions-background-color-my-video-1_component_373 captions-background-color-my-video-1_component_373-Yellow">Yellow</option><option id="captions-background-color-my-video-1_component_373-Magenta" value="#F0F" aria-labelledby="captions-background-my-video-1_component_373 captions-background-color-my-video-1_component_373 captions-background-color-my-video-1_component_373-Magenta">Magenta</option><option id="captions-background-color-my-video-1_component_373-Cyan" value="#0FF" aria-labelledby="captions-background-my-video-1_component_373 captions-background-color-my-video-1_component_373 captions-background-color-my-video-1_component_373-Cyan">Cyan</option></select><span class="vjs-bg-opacity vjs-opacity"><label id="captions-background-opacity-my-video-1_component_373" class="vjs-label">Transparency</label><select aria-labelledby="captions-background-my-video-1_component_373 captions-background-opacity-my-video-1_component_373"><option id="captions-background-opacity-my-video-1_component_373-Opaque" value="1" aria-labelledby="captions-background-my-video-1_component_373 captions-background-opacity-my-video-1_component_373 captions-background-opacity-my-video-1_component_373-Opaque">Opaque</option><option id="captions-background-opacity-my-video-1_component_373-SemiTransparent" value="0.5" aria-labelledby="captions-background-my-video-1_component_373 captions-background-opacity-my-video-1_component_373 captions-background-opacity-my-video-1_component_373-SemiTransparent">Semi-Transparent</option><option id="captions-background-opacity-my-video-1_component_373-Transparent" value="0" aria-labelledby="captions-background-my-video-1_component_373 captions-background-opacity-my-video-1_component_373 captions-background-opacity-my-video-1_component_373-Transparent">Transparent</option></select></span></fieldset><fieldset class="vjs-window-color vjs-track-setting"><legend id="captions-window-my-video-1_component_373">Window</legend><label id="captions-window-color-my-video-1_component_373" class="vjs-label">Color</label><select aria-labelledby="captions-window-my-video-1_component_373 captions-window-color-my-video-1_component_373"><option id="captions-window-color-my-video-1_component_373-Black" value="#000" aria-labelledby="captions-window-my-video-1_component_373 captions-window-color-my-video-1_component_373 captions-window-color-my-video-1_component_373-Black">Black</option><option id="captions-window-color-my-video-1_component_373-White" value="#FFF" aria-labelledby="captions-window-my-video-1_component_373 captions-window-color-my-video-1_component_373 captions-window-color-my-video-1_component_373-White">White</option><option id="captions-window-color-my-video-1_component_373-Red" value="#F00" aria-labelledby="captions-window-my-video-1_component_373 captions-window-color-my-video-1_component_373 captions-window-color-my-video-1_component_373-Red">Red</option><option id="captions-window-color-my-video-1_component_373-Green" value="#0F0" aria-labelledby="captions-window-my-video-1_component_373 captions-window-color-my-video-1_component_373 captions-window-color-my-video-1_component_373-Green">Green</option><option id="captions-window-color-my-video-1_component_373-Blue" value="#00F" aria-labelledby="captions-window-my-video-1_component_373 captions-window-color-my-video-1_component_373 captions-window-color-my-video-1_component_373-Blue">Blue</option><option id="captions-window-color-my-video-1_component_373-Yellow" value="#FF0" aria-labelledby="captions-window-my-video-1_component_373 captions-window-color-my-video-1_component_373 captions-window-color-my-video-1_component_373-Yellow">Yellow</option><option id="captions-window-color-my-video-1_component_373-Magenta" value="#F0F" aria-labelledby="captions-window-my-video-1_component_373 captions-window-color-my-video-1_component_373 captions-window-color-my-video-1_component_373-Magenta">Magenta</option><option id="captions-window-color-my-video-1_component_373-Cyan" value="#0FF" aria-labelledby="captions-window-my-video-1_component_373 captions-window-color-my-video-1_component_373 captions-window-color-my-video-1_component_373-Cyan">Cyan</option></select><span class="vjs-window-opacity vjs-opacity"><label id="captions-window-opacity-my-video-1_component_373" class="vjs-label">Transparency</label><select aria-labelledby="captions-window-my-video-1_component_373 captions-window-opacity-my-video-1_component_373"><option id="captions-window-opacity-my-video-1_component_373-Transparent" value="0" aria-labelledby="captions-window-my-video-1_component_373 captions-window-opacity-my-video-1_component_373 captions-window-opacity-my-video-1_component_373-Transparent">Transparent</option><option id="captions-window-opacity-my-video-1_component_373-SemiTransparent" value="0.5" aria-labelledby="captions-window-my-video-1_component_373 captions-window-opacity-my-video-1_component_373 captions-window-opacity-my-video-1_component_373-SemiTransparent">Semi-Transparent</option><option id="captions-window-opacity-my-video-1_component_373-Opaque" value="1" aria-labelledby="captions-window-my-video-1_component_373 captions-window-opacity-my-video-1_component_373 captions-window-opacity-my-video-1_component_373-Opaque">Opaque</option></select></span></fieldset></div><div class="vjs-track-settings-font"><fieldset class="vjs-font-percent vjs-track-setting"><legend id="captions-font-size-my-video-1_component_373" class="">Font Size</legend><select aria-labelledby="captions-font-size-my-video-1_component_373"><option id="captions-font-size-my-video-1_component_373-50" value="0.50" aria-labelledby="captions-font-size-my-video-1_component_373 captions-font-size-my-video-1_component_373-50">50%</option><option id="captions-font-size-my-video-1_component_373-75" value="0.75" aria-labelledby="captions-font-size-my-video-1_component_373 captions-font-size-my-video-1_component_373-75">75%</option><option id="captions-font-size-my-video-1_component_373-100" value="1.00" aria-labelledby="captions-font-size-my-video-1_component_373 captions-font-size-my-video-1_component_373-100">100%</option><option id="captions-font-size-my-video-1_component_373-125" value="1.25" aria-labelledby="captions-font-size-my-video-1_component_373 captions-font-size-my-video-1_component_373-125">125%</option><option id="captions-font-size-my-video-1_component_373-150" value="1.50" aria-labelledby="captions-font-size-my-video-1_component_373 captions-font-size-my-video-1_component_373-150">150%</option><option id="captions-font-size-my-video-1_component_373-175" value="1.75" aria-labelledby="captions-font-size-my-video-1_component_373 captions-font-size-my-video-1_component_373-175">175%</option><option id="captions-font-size-my-video-1_component_373-200" value="2.00" aria-labelledby="captions-font-size-my-video-1_component_373 captions-font-size-my-video-1_component_373-200">200%</option><option id="captions-font-size-my-video-1_component_373-300" value="3.00" aria-labelledby="captions-font-size-my-video-1_component_373 captions-font-size-my-video-1_component_373-300">300%</option><option id="captions-font-size-my-video-1_component_373-400" value="4.00" aria-labelledby="captions-font-size-my-video-1_component_373 captions-font-size-my-video-1_component_373-400">400%</option></select></fieldset><fieldset class="vjs-edge-style vjs-track-setting"><legend id="my-video-1_component_373" class="">Text Edge Style</legend><select aria-labelledby="my-video-1_component_373"><option id="my-video-1_component_373-None" value="none" aria-labelledby="my-video-1_component_373 my-video-1_component_373-None">None</option><option id="my-video-1_component_373-Raised" value="raised" aria-labelledby="my-video-1_component_373 my-video-1_component_373-Raised">Raised</option><option id="my-video-1_component_373-Depressed" value="depressed" aria-labelledby="my-video-1_component_373 my-video-1_component_373-Depressed">Depressed</option><option id="my-video-1_component_373-Uniform" value="uniform" aria-labelledby="my-video-1_component_373 my-video-1_component_373-Uniform">Uniform</option><option id="my-video-1_component_373-Dropshadow" value="dropshadow" aria-labelledby="my-video-1_component_373 my-video-1_component_373-Dropshadow">Dropshadow</option></select></fieldset><fieldset class="vjs-font-family vjs-track-setting"><legend id="captions-font-family-my-video-1_component_373" class="">Font Family</legend><select aria-labelledby="captions-font-family-my-video-1_component_373"><option id="captions-font-family-my-video-1_component_373-ProportionalSansSerif" value="proportionalSansSerif" aria-labelledby="captions-font-family-my-video-1_component_373 captions-font-family-my-video-1_component_373-ProportionalSansSerif">Proportional Sans-Serif</option><option id="captions-font-family-my-video-1_component_373-MonospaceSansSerif" value="monospaceSansSerif" aria-labelledby="captions-font-family-my-video-1_component_373 captions-font-family-my-video-1_component_373-MonospaceSansSerif">Monospace Sans-Serif</option><option id="captions-font-family-my-video-1_component_373-ProportionalSerif" value="proportionalSerif" aria-labelledby="captions-font-family-my-video-1_component_373 captions-font-family-my-video-1_component_373-ProportionalSerif">Proportional Serif</option><option id="captions-font-family-my-video-1_component_373-MonospaceSerif" value="monospaceSerif" aria-labelledby="captions-font-family-my-video-1_component_373 captions-font-family-my-video-1_component_373-MonospaceSerif">Monospace Serif</option><option id="captions-font-family-my-video-1_component_373-Casual" value="casual" aria-labelledby="captions-font-family-my-video-1_component_373 captions-font-family-my-video-1_component_373-Casual">Casual</option><option id="captions-font-family-my-video-1_component_373-Script" value="script" aria-labelledby="captions-font-family-my-video-1_component_373 captions-font-family-my-video-1_component_373-Script">Script</option><option id="captions-font-family-my-video-1_component_373-SmallCaps" value="small-caps" aria-labelledby="captions-font-family-my-video-1_component_373 captions-font-family-my-video-1_component_373-SmallCaps">Small Caps</option></select></fieldset></div><div class="vjs-track-settings-controls"><button type="button" class="vjs-default-button" title="restore all settings to the default values">Reset<span class="vjs-control-text"> restore all settings to the default values</span></button><button type="button" class="vjs-done-button">Done</button></div></div><button class="vjs-close-button vjs-control vjs-button" type="button" aria-disabled="false" title="Close Modal Dialog"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Close Modal Dialog</span></button><p class="vjs-control-text">End of dialog window.</p></div></div>
                    
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->





<div class="right-bar shadow d-none d-md-block" style="z-index:10000;">


            
            <div class="rightbar-title" style="background:slateblue;background1:black">
                <a href="javascript:void(0);" class="right-bar-toggle float-right">
                    <i class="dripicons-cross noti-icon text-light"></i>
                </a>
                
                                
                
            </div>
            
            

            <div class="rightbar-content h-100" data-simplebar="init"><div class="simplebar-wrapper" style="margin: 0px;"><div class="simplebar-height-auto-observer-wrapper"><div class="simplebar-height-auto-observer"></div></div><div class="simplebar-mask"><div class="simplebar-offset" style="right: 0px; bottom: 0px;"><div class="simplebar-content-wrapper" style="height: 100%; overflow: hidden;"><div class="simplebar-content" style="padding: 0px;">

                <div class="p-1">
                    



<div data-setup="{}" fluid="false" preload="auto" class="video-js vjs-tech vjs-theme-city vjs-big-play-centered bg-light vjs-paused my-video-1-dimensions vjs-fluid vjs-controls-enabled vjs-workinghover vjs-v7 vjs-user-active" id="my-video-1" tabindex="-1" role="region" lang="en" aria-label="Video Player"><video id="my-video-1_html5_api" class="vjs-tech" preload="auto" fluid="false" data-setup="{}" tabindex="-1" role="application">
    <source src="https://quantumhunts.com/user/assets/videos/job-seeker/job-seekers-promotional.mp4" type="video/mp4">
  </video><div class="vjs-poster vjs-hidden" aria-disabled="false"></div><div class="vjs-text-track-display" aria-live="off" aria-atomic="true"><div style="position: absolute; inset: 0px; margin: 1.5%;"></div></div><div class="vjs-loading-spinner" dir="ltr"><span class="vjs-control-text">Video Player is loading.</span></div><button class="vjs-big-play-button" type="button" title="Play Video" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Play Video</span></button><div class="vjs-control-bar" dir="ltr"><button class="vjs-play-control vjs-control vjs-button" type="button" title="Play" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Play</span></button><div class="vjs-volume-panel vjs-control vjs-volume-panel-horizontal"><button class="vjs-mute-control vjs-control vjs-button vjs-vol-3" type="button" title="Mute" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Mute</span></button><div class="vjs-volume-control vjs-control vjs-volume-horizontal"><div tabindex="0" class="vjs-volume-bar vjs-slider-bar vjs-slider vjs-slider-horizontal" role="slider" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" aria-label="Volume Level" aria-live="polite" aria-valuetext="100%"><div class="vjs-volume-level"><span class="vjs-control-text"></span></div></div></div></div><div class="vjs-current-time vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Current Time&nbsp;</span><span class="vjs-current-time-display" aria-live="off" role="presentation">0:00</span></div><div class="vjs-time-control vjs-time-divider" aria-hidden="true"><div><span>/</span></div></div><div class="vjs-duration vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Duration&nbsp;</span><span class="vjs-duration-display" aria-live="off" role="presentation">0:32</span></div><div class="vjs-progress-control vjs-control"><div tabindex="0" class="vjs-progress-holder vjs-slider vjs-slider-horizontal" role="slider" aria-valuenow="0.00" aria-valuemin="0" aria-valuemax="100" aria-label="Progress Bar" aria-valuetext="0:00 of 0:32"><div class="vjs-load-progress" style="width: 41.16%;"><span class="vjs-control-text"><span>Loaded</span>: <span class="vjs-control-text-loaded-percentage">41.16%</span></span><div data-start="0" data-end="13.268" style="left: 0%; width: 100%;"></div></div><div class="vjs-mouse-display"><div class="vjs-time-tooltip" aria-hidden="true"></div></div><div class="vjs-play-progress vjs-slider-bar" aria-hidden="true" style="width: 0%;"><div class="vjs-time-tooltip" aria-hidden="true" style="right: 0px;">0:00</div></div></div></div><div class="vjs-live-control vjs-control vjs-hidden"><div class="vjs-live-display" aria-live="off"><span class="vjs-control-text">Stream Type&nbsp;</span>LIVE</div></div><button class="vjs-seek-to-live-control vjs-control" type="button" title="Seek to live, currently behind live" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Seek to live, currently behind live</span><span class="vjs-seek-to-live-text" aria-hidden="true">LIVE</span></button><div class="vjs-remaining-time vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Remaining Time&nbsp;</span><span aria-hidden="true">-</span><span class="vjs-remaining-time-display" aria-live="off" role="presentation">0:32</span></div><div class="vjs-custom-control-spacer vjs-spacer ">&nbsp;</div><div class="vjs-playback-rate vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><div class="vjs-playback-rate-value">1x</div><button class="vjs-playback-rate vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Playback Rate" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Playback Rate</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"></ul></div></div><div class="vjs-chapters-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-chapters-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Chapters" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Chapters</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-title">Chapters</li></ul></div></div><div class="vjs-descriptions-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-descriptions-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Descriptions" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Descriptions</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-item vjs-selected" role="menuitemradio" aria-disabled="false" tabindex="-1" aria-checked="true"><span class="vjs-menu-item-text">descriptions off</span><span class="vjs-control-text" aria-live="polite">, selected</span></li></ul></div></div><div class="vjs-subs-caps-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-subs-caps-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Captions" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Captions</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-item vjs-texttrack-settings" role="menuitem" aria-disabled="false" tabindex="-1"><span class="vjs-menu-item-text">captions settings</span><span class="vjs-control-text" aria-live="polite">, opens captions settings dialog</span></li><li class="vjs-menu-item vjs-selected" role="menuitemradio" aria-disabled="false" tabindex="-1" aria-checked="true"><span class="vjs-menu-item-text">captions off</span><span class="vjs-control-text" aria-live="polite">, selected</span></li></ul></div></div><div class="vjs-audio-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-audio-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Audio Track" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Audio Track</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"></ul></div></div><button class="vjs-picture-in-picture-control vjs-control vjs-button" type="button" title="Picture-in-Picture" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Picture-in-Picture</span></button><button class="vjs-fullscreen-control vjs-control vjs-button" type="button" title="Fullscreen" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Fullscreen</span></button></div><div class="vjs-error-display vjs-modal-dialog vjs-hidden " aria-describedby="my-video-1_component_680_description" aria-hidden="true" aria-label="Modal Window" role="dialog"><p class="vjs-modal-dialog-description vjs-control-text" id="my-video-1_component_680_description">This is a modal window.</p><div class="vjs-modal-dialog-content" role="document"></div></div><div class="vjs-modal-dialog vjs-hidden  vjs-text-track-settings" aria-describedby="my-video-1_component_684_description" aria-hidden="true" aria-label="Caption Settings Dialog" role="dialog"><p class="vjs-modal-dialog-description vjs-control-text" id="my-video-1_component_684_description">Beginning of dialog window. Escape will cancel and close the window.</p><div class="vjs-modal-dialog-content" role="document"><div class="vjs-track-settings-colors"><fieldset class="vjs-fg-color vjs-track-setting"><legend id="captions-text-legend-my-video-1_component_684">Text</legend><label id="captions-foreground-color-my-video-1_component_684" class="vjs-label">Color</label><select aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-color-my-video-1_component_684"><option id="captions-foreground-color-my-video-1_component_684-White" value="#FFF" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-color-my-video-1_component_684 captions-foreground-color-my-video-1_component_684-White">White</option><option id="captions-foreground-color-my-video-1_component_684-Black" value="#000" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-color-my-video-1_component_684 captions-foreground-color-my-video-1_component_684-Black">Black</option><option id="captions-foreground-color-my-video-1_component_684-Red" value="#F00" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-color-my-video-1_component_684 captions-foreground-color-my-video-1_component_684-Red">Red</option><option id="captions-foreground-color-my-video-1_component_684-Green" value="#0F0" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-color-my-video-1_component_684 captions-foreground-color-my-video-1_component_684-Green">Green</option><option id="captions-foreground-color-my-video-1_component_684-Blue" value="#00F" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-color-my-video-1_component_684 captions-foreground-color-my-video-1_component_684-Blue">Blue</option><option id="captions-foreground-color-my-video-1_component_684-Yellow" value="#FF0" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-color-my-video-1_component_684 captions-foreground-color-my-video-1_component_684-Yellow">Yellow</option><option id="captions-foreground-color-my-video-1_component_684-Magenta" value="#F0F" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-color-my-video-1_component_684 captions-foreground-color-my-video-1_component_684-Magenta">Magenta</option><option id="captions-foreground-color-my-video-1_component_684-Cyan" value="#0FF" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-color-my-video-1_component_684 captions-foreground-color-my-video-1_component_684-Cyan">Cyan</option></select><span class="vjs-text-opacity vjs-opacity"><label id="captions-foreground-opacity-my-video-1_component_684" class="vjs-label">Transparency</label><select aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-opacity-my-video-1_component_684"><option id="captions-foreground-opacity-my-video-1_component_684-Opaque" value="1" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-opacity-my-video-1_component_684 captions-foreground-opacity-my-video-1_component_684-Opaque">Opaque</option><option id="captions-foreground-opacity-my-video-1_component_684-SemiTransparent" value="0.5" aria-labelledby="captions-text-legend-my-video-1_component_684 captions-foreground-opacity-my-video-1_component_684 captions-foreground-opacity-my-video-1_component_684-SemiTransparent">Semi-Transparent</option></select></span></fieldset><fieldset class="vjs-bg-color vjs-track-setting"><legend id="captions-background-my-video-1_component_684">Background</legend><label id="captions-background-color-my-video-1_component_684" class="vjs-label">Color</label><select aria-labelledby="captions-background-my-video-1_component_684 captions-background-color-my-video-1_component_684"><option id="captions-background-color-my-video-1_component_684-Black" value="#000" aria-labelledby="captions-background-my-video-1_component_684 captions-background-color-my-video-1_component_684 captions-background-color-my-video-1_component_684-Black">Black</option><option id="captions-background-color-my-video-1_component_684-White" value="#FFF" aria-labelledby="captions-background-my-video-1_component_684 captions-background-color-my-video-1_component_684 captions-background-color-my-video-1_component_684-White">White</option><option id="captions-background-color-my-video-1_component_684-Red" value="#F00" aria-labelledby="captions-background-my-video-1_component_684 captions-background-color-my-video-1_component_684 captions-background-color-my-video-1_component_684-Red">Red</option><option id="captions-background-color-my-video-1_component_684-Green" value="#0F0" aria-labelledby="captions-background-my-video-1_component_684 captions-background-color-my-video-1_component_684 captions-background-color-my-video-1_component_684-Green">Green</option><option id="captions-background-color-my-video-1_component_684-Blue" value="#00F" aria-labelledby="captions-background-my-video-1_component_684 captions-background-color-my-video-1_component_684 captions-background-color-my-video-1_component_684-Blue">Blue</option><option id="captions-background-color-my-video-1_component_684-Yellow" value="#FF0" aria-labelledby="captions-background-my-video-1_component_684 captions-background-color-my-video-1_component_684 captions-background-color-my-video-1_component_684-Yellow">Yellow</option><option id="captions-background-color-my-video-1_component_684-Magenta" value="#F0F" aria-labelledby="captions-background-my-video-1_component_684 captions-background-color-my-video-1_component_684 captions-background-color-my-video-1_component_684-Magenta">Magenta</option><option id="captions-background-color-my-video-1_component_684-Cyan" value="#0FF" aria-labelledby="captions-background-my-video-1_component_684 captions-background-color-my-video-1_component_684 captions-background-color-my-video-1_component_684-Cyan">Cyan</option></select><span class="vjs-bg-opacity vjs-opacity"><label id="captions-background-opacity-my-video-1_component_684" class="vjs-label">Transparency</label><select aria-labelledby="captions-background-my-video-1_component_684 captions-background-opacity-my-video-1_component_684"><option id="captions-background-opacity-my-video-1_component_684-Opaque" value="1" aria-labelledby="captions-background-my-video-1_component_684 captions-background-opacity-my-video-1_component_684 captions-background-opacity-my-video-1_component_684-Opaque">Opaque</option><option id="captions-background-opacity-my-video-1_component_684-SemiTransparent" value="0.5" aria-labelledby="captions-background-my-video-1_component_684 captions-background-opacity-my-video-1_component_684 captions-background-opacity-my-video-1_component_684-SemiTransparent">Semi-Transparent</option><option id="captions-background-opacity-my-video-1_component_684-Transparent" value="0" aria-labelledby="captions-background-my-video-1_component_684 captions-background-opacity-my-video-1_component_684 captions-background-opacity-my-video-1_component_684-Transparent">Transparent</option></select></span></fieldset><fieldset class="vjs-window-color vjs-track-setting"><legend id="captions-window-my-video-1_component_684">Window</legend><label id="captions-window-color-my-video-1_component_684" class="vjs-label">Color</label><select aria-labelledby="captions-window-my-video-1_component_684 captions-window-color-my-video-1_component_684"><option id="captions-window-color-my-video-1_component_684-Black" value="#000" aria-labelledby="captions-window-my-video-1_component_684 captions-window-color-my-video-1_component_684 captions-window-color-my-video-1_component_684-Black">Black</option><option id="captions-window-color-my-video-1_component_684-White" value="#FFF" aria-labelledby="captions-window-my-video-1_component_684 captions-window-color-my-video-1_component_684 captions-window-color-my-video-1_component_684-White">White</option><option id="captions-window-color-my-video-1_component_684-Red" value="#F00" aria-labelledby="captions-window-my-video-1_component_684 captions-window-color-my-video-1_component_684 captions-window-color-my-video-1_component_684-Red">Red</option><option id="captions-window-color-my-video-1_component_684-Green" value="#0F0" aria-labelledby="captions-window-my-video-1_component_684 captions-window-color-my-video-1_component_684 captions-window-color-my-video-1_component_684-Green">Green</option><option id="captions-window-color-my-video-1_component_684-Blue" value="#00F" aria-labelledby="captions-window-my-video-1_component_684 captions-window-color-my-video-1_component_684 captions-window-color-my-video-1_component_684-Blue">Blue</option><option id="captions-window-color-my-video-1_component_684-Yellow" value="#FF0" aria-labelledby="captions-window-my-video-1_component_684 captions-window-color-my-video-1_component_684 captions-window-color-my-video-1_component_684-Yellow">Yellow</option><option id="captions-window-color-my-video-1_component_684-Magenta" value="#F0F" aria-labelledby="captions-window-my-video-1_component_684 captions-window-color-my-video-1_component_684 captions-window-color-my-video-1_component_684-Magenta">Magenta</option><option id="captions-window-color-my-video-1_component_684-Cyan" value="#0FF" aria-labelledby="captions-window-my-video-1_component_684 captions-window-color-my-video-1_component_684 captions-window-color-my-video-1_component_684-Cyan">Cyan</option></select><span class="vjs-window-opacity vjs-opacity"><label id="captions-window-opacity-my-video-1_component_684" class="vjs-label">Transparency</label><select aria-labelledby="captions-window-my-video-1_component_684 captions-window-opacity-my-video-1_component_684"><option id="captions-window-opacity-my-video-1_component_684-Transparent" value="0" aria-labelledby="captions-window-my-video-1_component_684 captions-window-opacity-my-video-1_component_684 captions-window-opacity-my-video-1_component_684-Transparent">Transparent</option><option id="captions-window-opacity-my-video-1_component_684-SemiTransparent" value="0.5" aria-labelledby="captions-window-my-video-1_component_684 captions-window-opacity-my-video-1_component_684 captions-window-opacity-my-video-1_component_684-SemiTransparent">Semi-Transparent</option><option id="captions-window-opacity-my-video-1_component_684-Opaque" value="1" aria-labelledby="captions-window-my-video-1_component_684 captions-window-opacity-my-video-1_component_684 captions-window-opacity-my-video-1_component_684-Opaque">Opaque</option></select></span></fieldset></div><div class="vjs-track-settings-font"><fieldset class="vjs-font-percent vjs-track-setting"><legend id="captions-font-size-my-video-1_component_684" class="">Font Size</legend><select aria-labelledby="captions-font-size-my-video-1_component_684"><option id="captions-font-size-my-video-1_component_684-50" value="0.50" aria-labelledby="captions-font-size-my-video-1_component_684 captions-font-size-my-video-1_component_684-50">50%</option><option id="captions-font-size-my-video-1_component_684-75" value="0.75" aria-labelledby="captions-font-size-my-video-1_component_684 captions-font-size-my-video-1_component_684-75">75%</option><option id="captions-font-size-my-video-1_component_684-100" value="1.00" aria-labelledby="captions-font-size-my-video-1_component_684 captions-font-size-my-video-1_component_684-100">100%</option><option id="captions-font-size-my-video-1_component_684-125" value="1.25" aria-labelledby="captions-font-size-my-video-1_component_684 captions-font-size-my-video-1_component_684-125">125%</option><option id="captions-font-size-my-video-1_component_684-150" value="1.50" aria-labelledby="captions-font-size-my-video-1_component_684 captions-font-size-my-video-1_component_684-150">150%</option><option id="captions-font-size-my-video-1_component_684-175" value="1.75" aria-labelledby="captions-font-size-my-video-1_component_684 captions-font-size-my-video-1_component_684-175">175%</option><option id="captions-font-size-my-video-1_component_684-200" value="2.00" aria-labelledby="captions-font-size-my-video-1_component_684 captions-font-size-my-video-1_component_684-200">200%</option><option id="captions-font-size-my-video-1_component_684-300" value="3.00" aria-labelledby="captions-font-size-my-video-1_component_684 captions-font-size-my-video-1_component_684-300">300%</option><option id="captions-font-size-my-video-1_component_684-400" value="4.00" aria-labelledby="captions-font-size-my-video-1_component_684 captions-font-size-my-video-1_component_684-400">400%</option></select></fieldset><fieldset class="vjs-edge-style vjs-track-setting"><legend id="my-video-1_component_684" class="">Text Edge Style</legend><select aria-labelledby="my-video-1_component_684"><option id="my-video-1_component_684-None" value="none" aria-labelledby="my-video-1_component_684 my-video-1_component_684-None">None</option><option id="my-video-1_component_684-Raised" value="raised" aria-labelledby="my-video-1_component_684 my-video-1_component_684-Raised">Raised</option><option id="my-video-1_component_684-Depressed" value="depressed" aria-labelledby="my-video-1_component_684 my-video-1_component_684-Depressed">Depressed</option><option id="my-video-1_component_684-Uniform" value="uniform" aria-labelledby="my-video-1_component_684 my-video-1_component_684-Uniform">Uniform</option><option id="my-video-1_component_684-Dropshadow" value="dropshadow" aria-labelledby="my-video-1_component_684 my-video-1_component_684-Dropshadow">Dropshadow</option></select></fieldset><fieldset class="vjs-font-family vjs-track-setting"><legend id="captions-font-family-my-video-1_component_684" class="">Font Family</legend><select aria-labelledby="captions-font-family-my-video-1_component_684"><option id="captions-font-family-my-video-1_component_684-ProportionalSansSerif" value="proportionalSansSerif" aria-labelledby="captions-font-family-my-video-1_component_684 captions-font-family-my-video-1_component_684-ProportionalSansSerif">Proportional Sans-Serif</option><option id="captions-font-family-my-video-1_component_684-MonospaceSansSerif" value="monospaceSansSerif" aria-labelledby="captions-font-family-my-video-1_component_684 captions-font-family-my-video-1_component_684-MonospaceSansSerif">Monospace Sans-Serif</option><option id="captions-font-family-my-video-1_component_684-ProportionalSerif" value="proportionalSerif" aria-labelledby="captions-font-family-my-video-1_component_684 captions-font-family-my-video-1_component_684-ProportionalSerif">Proportional Serif</option><option id="captions-font-family-my-video-1_component_684-MonospaceSerif" value="monospaceSerif" aria-labelledby="captions-font-family-my-video-1_component_684 captions-font-family-my-video-1_component_684-MonospaceSerif">Monospace Serif</option><option id="captions-font-family-my-video-1_component_684-Casual" value="casual" aria-labelledby="captions-font-family-my-video-1_component_684 captions-font-family-my-video-1_component_684-Casual">Casual</option><option id="captions-font-family-my-video-1_component_684-Script" value="script" aria-labelledby="captions-font-family-my-video-1_component_684 captions-font-family-my-video-1_component_684-Script">Script</option><option id="captions-font-family-my-video-1_component_684-SmallCaps" value="small-caps" aria-labelledby="captions-font-family-my-video-1_component_684 captions-font-family-my-video-1_component_684-SmallCaps">Small Caps</option></select></fieldset></div><div class="vjs-track-settings-controls"><button type="button" class="vjs-default-button" title="restore all settings to the default values">Reset<span class="vjs-control-text"> restore all settings to the default values</span></button><button type="button" class="vjs-done-button">Done</button></div></div><button class="vjs-close-button vjs-control vjs-button" type="button" aria-disabled="false" title="Close Modal Dialog"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Close Modal Dialog</span></button><p class="vjs-control-text">End of dialog window.</p></div></div>






                </div> <!-- end padding-->

            </div></div></div></div><div class="simplebar-placeholder" style="width: 280px; height: 498px;"></div></div><div class="simplebar-track simplebar-horizontal" style="visibility: hidden;"><div class="simplebar-scrollbar" style="width: 0px; display: none;"></div></div><div class="simplebar-track simplebar-vertical" style="visibility: hidden;"><div class="simplebar-scrollbar" style="height: 0px; display: none;"></div></div></div>
        </div>



                        <div class="row">
                            

                            <div class="col-xl-8 col-lg-8">
                                


                                    
                                
 
 
 

<div class="card">
<div class="card-body shadow1 border">

<div class="row">
<div class="col-4 col-sm-5 col-md-5 col-lg-4">
    
    


 <div id="dppreview"><img class="img-thumbnail" src="./Edit Resume _ QUANTUMHUNTS_files/default.png"></div>
    
 <form id="form" method="post" enctype="multipart/form-data" style="overflow:hidden;">
  
  <input id="uploadImage" type="file" accept="image/*" name="image" class="inputfile">
  <input class="btn btn-xs btn-primary" id="button1" type="submit" value="Upload">
 </form>
<div id="err"></div>


                       
                       
                                                    

</div>
<div class="col-8 col-sm-7 col-md-7 col-lg-8">
    
<div class="jumbotron1 p-0 m-0">
  <h5 class="text-primary text-uppercase purpletitle blogmini">Hello <?php  echo $_SESSION['candidate_fname']; ?></h5>
  <p>    Welcome to QuantumHunts, the premium portal to connect with prospective employers, recruiters and leaders. 
    Please setup your job profile by furnishing the details as below.
      </p>
  
  
  <p>
<!--    <a class="btn btn-primary btn-sm" href="#" role="button">Learn more</a>-->
  </p>
</div>    


</div>
</div>
</div>
</div>


<script>
    $(document).ready(function (e) {
 $("#form").on('submit',(function(e) {
  e.preventDefault();
  
  var fd = new FormData();    
  fd.append( 'file', input.files[0] );
  
  $.ajax({
    url: "http://localhost/edit-profile/upload.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   //dataType: 'json',
   beforeSend : function()
   {
    //$("#dppreview").fadeOut();
    $("#err").fadeOut();
   },
   success: function(bata)
      {
        //alert(bata);
        //alert(bata.code);
        //alert(bata.msg);
    if(bata=='invalid file')
    {
        //alert("1");
     // invalid file format.
     //$("#dppreview").html(data.msg).fadeIn();
     //$("#dppreview").html(bata).fadeIn();
     $("#err").html("Invalid File !").fadeIn();
    }
    else
    {
     //alert("2");
     // view uploaded file.
     $("#dppreview").html(bata).fadeIn();
     $("#form")[0].reset(); 
    }
      },
     error: function(e) 
      {
    $("#err").html(e).fadeIn();
      }          
    });
 }));
});
</script>
  
 
 
 
 
 
 
                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                <div class="card text-muted mb-2">
                                <!--<div class="card-header bg-secondary text-light">    Update Profile   </div>-->


                                    <div class="card-body shadow1 border  ">

         
                          
                
<script>
    $(document).ready(function () {
        $('#city').typeahead({
            source: function (query, result) {
                $.ajax({
                    url: "https://quantumhunts.com/user/get/locations/",
					data: 'query=' + query,            
                    dataType: "json",
                    type: "POST",
                    success: function (data) {
						result($.map(data, function (item) {
							return item;
                        }));
                    }
                });
            }
        });
    });
</script>

        
<script>
    $(document).ready(function () {
        $('#preferredcity').typeahead({
            source: function (query, result) {
                $.ajax({
                    url: "https://quantumhunts.com/user/get/locations/",
					data: 'query=' + query,            
                    dataType: "json",
                    type: "POST",
                    success: function (data) {
						result($.map(data, function (item) {
							return item;
                        }));
                    }
                });
            }
        });
    });
</script>
                            
                                        
                                        
                                        
                                        
                                            
                                                <form autocomplete="off-no">
                                                    <!--<h5 class="text-uppercase font-8 mb-3 text-info">&nbsp; Personal</h5>-->
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="firstname">First Name</label>
                                                                <input type="text" class="form-control form-control-sm" id="firstname" disabled="" placeholder="Enter first name" value="<?php echo $_SESSION['candidate_fname']; ?>" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="lastname">Last Name</label>
                                                                <input type="text" class="form-control form-control-sm" id="lastname" disabled="" placeholder="Enter last name" value="<?php echo $_SESSION['candidate_lname']; ?>" autocomplete="off-no">
                                                            </div>
                                                        </div> <!-- end col -->
                                                    </div> <!-- end row -->
                                                    


                                                    
                                                    
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="useremail">Email Address</label>
                                                                <input type="email" class="form-control form-control-sm" disabled="" id="useremail" placeholder="Enter email" value="<?php echo $_SESSION['candidate_email']; ?>" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                        
                                                        <div class="col-md-6">
                                                             <div class="form-group">
                                                                <label for="lastname">Date of Birth</label>
                                                                   <div class="input-group">
                                                                    <input type="text" class="form-control form-control-sm" id="dateofbirth" disabled="" data-provide="datepicker" value="<?php echo $_SESSION['candidate_dob']; ?>" autocomplete="off-no">
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text"><i class="dripicons-calendar"></i></span>
                                                                     </div>
                                                                </div>
                                                            </div>
                                                        </div> <!-- end col -->
                                                    </div> <!-- end row -->                                                    


                                                   <div class="row">
                                                        <div class="col-md-6">
                                                            
                                                            <div class="form-group">
                                                                <label for="firstname">Availability *</label>
                                                                <select class="form-control form-control-sm" id="noticecode">
                                                                    <option value="no">Not looking for job change</option>
                                                                    <option value="im">Immediately Available</option>
                                                                    <option value="1w">Available in 1 Week</option>    
                                                                    <option value="2w">Available in 2 Weeks</option>        
                                                                    <option value="1m">Available in 1 Month</option>        
                                                                    <option value="2m">Available in 2 Months</option>            
                                                                    <option value="3m">Available in 3 Months</option>        
                                                                </select>                                                                
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            
                                                            
                                                        <div class="form-group">
                                                            <label>Phone *</label>
                                                            <div class="input-group">
                                                                <select id="countrycode" class="form-control form-control-sm">
<option value="India +91">India +91</option>                         
<option value="Afghanistan +93">Afghanistan +93</option>
<option value="Albania +355">Albania +355</option>
<option value="Algeria +213">Algeria +213</option>
<option value="American Samoa +1-684">American Samoa +1-684</option>
<option value="Andorra +376">Andorra +376</option>
<option value="Angola +244">Angola +244</option>
<option value="Anguilla +1-264">Anguilla +1-264</option>
<option value="Antarctica +672">Antarctica +672</option>
<option value="Antigua and Barbuda +1-268">Antigua and Barbuda +1-268</option>
<option value="Argentina +54">Argentina +54</option>
<option value="Armenia +374">Armenia +374</option>
<option value="Aruba +297">Aruba +297</option>
<option value="Australia +61">Australia +61</option>
<option value="Austria +43">Austria +43</option>
<option value="Azerbaijan +994">Azerbaijan +994</option>
<option value="Bahamas +1-242">Bahamas +1-242</option>
<option value="Bahrain +973">Bahrain +973</option>
<option value="Bangladesh +880">Bangladesh +880</option>
<option value="Barbados +1-246">Barbados +1-246</option>
<option value="Belarus +375">Belarus +375</option>
<option value="Belgium +32">Belgium +32</option>
<option value="Belize +501">Belize +501</option>
<option value="Benin +229">Benin +229</option>
<option value="Bermuda +1-441">Bermuda +1-441</option>
<option value="Bhutan +975">Bhutan +975</option>
<option value="Bolivia +591">Bolivia +591</option>
<option value="Bosnia and Herzegovina +387">Bosnia and Herzegovina +387</option>
<option value="Botswana +267">Botswana +267</option>
<option value="Brazil +55">Brazil +55</option>
<option value="British Indian Ocean Territory +246">British Indian Ocean Territory +246</option>
<option value="British Virgin Islands +1-284">British Virgin Islands +1-284</option>
<option value="Brunei +673">Brunei +673</option>
<option value="Bulgaria +359">Bulgaria +359</option>
<option value="Burkina Faso +226">Burkina Faso +226</option>
<option value="Burundi +257">Burundi +257</option>
<option value="Cambodia +855">Cambodia +855</option>
<option value="Cameroon +237">Cameroon +237</option>
<option value="Canada +1">Canada +1</option>
<option value="Cape Verde +238">Cape Verde +238</option>
<option value="Cayman Islands +1-345">Cayman Islands +1-345</option>
<option value="Central African Republic +236">Central African Republic +236</option>
<option value="Chad +235">Chad +235</option>
<option value="Chile +56">Chile +56</option>
<option value="China +86">China +86</option>
<option value="Christmas Island +61">Christmas Island +61</option>
<option value="Cocos Islands +61">Cocos Islands +61</option>
<option value="Colombia +57">Colombia +57</option>
<option value="Comoros +269">Comoros +269</option>
<option value="Cook Islands +682">Cook Islands +682</option>
<option value="Costa Rica +506">Costa Rica +506</option>
<option value="Croatia +385">Croatia +385</option>
<option value="Cuba +53">Cuba +53</option>
<option value="Curacao +599">Curacao +599</option>
<option value="Cyprus +357">Cyprus +357</option>
<option value="Czech Republic +420">Czech Republic +420</option>
<option value="Democratic Republic of the Congo +243">Democratic Republic of the Congo +243</option>
<option value="Denmark +45">Denmark +45</option>
<option value="Djibouti +253">Djibouti +253</option>
<option value="Dominica +1-767">Dominica +1-767</option>
<option value="Dominican Republic +1-809">Dominican Republic +1-809</option>
<option value="East Timor +670">East Timor +670</option>
<option value="Ecuador +593">Ecuador +593</option>
<option value="Egypt +20">Egypt +20</option>
<option value="El Salvador +503">El Salvador +503</option>
<option value="Equatorial Guinea +240">Equatorial Guinea +240</option>
<option value="Eritrea +291">Eritrea +291</option>
<option value="Estonia +372">Estonia +372</option>
<option value="Ethiopia +251">Ethiopia +251</option>
<option value="Falkland Islands +500">Falkland Islands +500</option>
<option value="Faroe Islands +298">Faroe Islands +298</option>
<option value="Fiji +679">Fiji +679</option>
<option value="Finland +358">Finland +358</option>
<option value="France +33">France +33</option>
<option value="French Polynesia +689">French Polynesia +689</option>
<option value="Gabon +241">Gabon +241</option>
<option value="Gambia +220">Gambia +220</option>
<option value="Georgia +995">Georgia +995</option>
<option value="Germany +49">Germany +49</option>
<option value="Ghana +233">Ghana +233</option>
<option value="Gibraltar +350">Gibraltar +350</option>
<option value="Greece +30">Greece +30</option>
<option value="Greenland +299">Greenland +299</option>
<option value="Grenada +1-473">Grenada +1-473</option>
<option value="Guam +1-671">Guam +1-671</option>
<option value="Guatemala +502">Guatemala +502</option>
<option value="Guernsey +44-1481">Guernsey +44-1481</option>
<option value="Guinea +224">Guinea +224</option>
<option value="Guinea-Bissau +245">Guinea-Bissau +245</option>
<option value="Guyana +592">Guyana +592</option>
<option value="Haiti +509">Haiti +509</option>
<option value="Honduras +504">Honduras +504</option>
<option value="Hong Kong +852">Hong Kong +852</option>
<option value="Hungary +36">Hungary +36</option>
<option value="Iceland +354">Iceland +354</option>
<option value="Indonesia +62">Indonesia +62</option>
<option value="Iran +98">Iran +98</option>
<option value="Iraq +964">Iraq +964</option>
<option value="Ireland +353">Ireland +353</option>
<option value="Isle of Man +44-1624">Isle of Man +44-1624</option>
<option value="Israel +972">Israel +972</option>
<option value="Italy +39">Italy +39</option>
<option value="Ivory Coast +225">Ivory Coast +225</option>
<option value="Jamaica +1-876">Jamaica +1-876</option>
<option value="Japan +81">Japan +81</option>
<option value="Jersey +44-1534">Jersey +44-1534</option>
<option value="Jordan +962">Jordan +962</option>
<option value="Kazakhstan +7">Kazakhstan +7</option>
<option value="Kenya +254">Kenya +254</option>
<option value="Kiribati +686">Kiribati +686</option>
<option value="Kosovo +383">Kosovo +383</option>
<option value="Kuwait +965">Kuwait +965</option>
<option value="Kyrgyzstan +996">Kyrgyzstan +996</option>
<option value="Laos +856">Laos +856</option>
<option value="Latvia +371">Latvia +371</option>
<option value="Lebanon +961">Lebanon +961</option>
<option value="Lesotho +266">Lesotho +266</option>
<option value="Liberia +231">Liberia +231</option>
<option value="Libya +218">Libya +218</option>
<option value="Liechtenstein +423">Liechtenstein +423</option>
<option value="Lithuania +370">Lithuania +370</option>
<option value="Luxembourg +352">Luxembourg +352</option>
<option value="Macau +853">Macau +853</option>
<option value="Macedonia +389">Macedonia +389</option>
<option value="Madagascar +261">Madagascar +261</option>
<option value="Malawi +265">Malawi +265</option>
<option value="Malaysia +60">Malaysia +60</option>
<option value="Maldives +960">Maldives +960</option>
<option value="Mali +223">Mali +223</option>
<option value="Malta +356">Malta +356</option>
<option value="Marshall Islands +692">Marshall Islands +692</option>
<option value="Mauritania +222">Mauritania +222</option>
<option value="Mauritius +230">Mauritius +230</option>
<option value="Mayotte +262">Mayotte +262</option>
<option value="Mexico +52">Mexico +52</option>
<option value="Micronesia +691">Micronesia +691</option>
<option value="Moldova +373">Moldova +373</option>
<option value="Monaco +377">Monaco +377</option>
<option value="Mongolia +976">Mongolia +976</option>
<option value="Montenegro +382">Montenegro +382</option>
<option value="Montserrat +1-664">Montserrat +1-664</option>
<option value="Morocco +212">Morocco +212</option>
<option value="Mozambique +258">Mozambique +258</option>
<option value="Myanmar +95">Myanmar +95</option>
<option value="Namibia +264">Namibia +264</option>
<option value="Nauru +674">Nauru +674</option>
<option value="Nepal +977">Nepal +977</option>
<option value="Netherlands +31">Netherlands +31</option>
<option value="Netherlands Antilles +599">Netherlands Antilles +599</option>
<option value="New Caledonia +687">New Caledonia +687</option>
<option value="New Zealand +64">New Zealand +64</option>
<option value="Nicaragua +505">Nicaragua +505</option>
<option value="Niger +227">Niger +227</option>
<option value="Nigeria +234">Nigeria +234</option>
<option value="Niue +683">Niue +683</option>
<option value="North Korea +850">North Korea +850</option>
<option value="Northern Mariana Islands +1-670">Northern Mariana Islands +1-670</option>
<option value="Norway +47">Norway +47</option>
<option value="Oman +968">Oman +968</option>
<option value="Pakistan +92">Pakistan +92</option>
<option value="Palau +680">Palau +680</option>
<option value="Palestine +970">Palestine +970</option>
<option value="Panama +507">Panama +507</option>
<option value="Papua New Guinea +675">Papua New Guinea +675</option>
<option value="Paraguay +595">Paraguay +595</option>
<option value="Peru +51">Peru +51</option>
<option value="Philippines +63">Philippines +63</option>
<option value="Pitcairn +64">Pitcairn +64</option>
<option value="Poland +48">Poland +48</option>
<option value="Portugal +351">Portugal +351</option>
<option value="Puerto Rico +1-787">Puerto Rico +1-787</option>
<option value="Qatar +974">Qatar +974</option>
<option value="Republic of the Congo +242">Republic of the Congo +242</option>
<option value="Reunion +262">Reunion +262</option>
<option value="Romania +40">Romania +40</option>
<option value="Russia +7">Russia +7</option>
<option value="Rwanda +250">Rwanda +250</option>
<option value="Saint Barthelemy +590">Saint Barthelemy +590</option>
<option value="Saint Helena +290">Saint Helena +290</option>
<option value="Saint Kitts and Nevis +1-869">Saint Kitts and Nevis +1-869</option>
<option value="Saint Lucia +1-758">Saint Lucia +1-758</option>
<option value="Saint Martin +590">Saint Martin +590</option>
<option value="Saint Pierre and Miquelon +508">Saint Pierre and Miquelon +508</option>
<option value="Saint Vincent and the Grenadines +1-784">Saint Vincent and the Grenadines +1-784</option>
<option value="Samoa +685">Samoa +685</option>
<option value="San Marino +378">San Marino +378</option>
<option value="Sao Tome and Principe +239">Sao Tome and Principe +239</option>
<option value="Saudi Arabia +966">Saudi Arabia +966</option>
<option value="Senegal +221">Senegal +221</option>
<option value="Serbia +381">Serbia +381</option>
<option value="Seychelles +248">Seychelles +248</option>
<option value="Sierra Leone +232">Sierra Leone +232</option>
<option value="Singapore +65">Singapore +65</option>
<option value="Sint Maarten +1-721">Sint Maarten +1-721</option>
<option value="Slovakia +421">Slovakia +421</option>
<option value="Slovenia +386">Slovenia +386</option>
<option value="Solomon Islands +677">Solomon Islands +677</option>
<option value="Somalia +252">Somalia +252</option>
<option value="South Africa +27">South Africa +27</option>
<option value="South Korea +82">South Korea +82</option>
<option value="South Sudan +211">South Sudan +211</option>
<option value="Spain +34">Spain +34</option>
<option value="Sri Lanka +94">Sri Lanka +94</option>
<option value="Sudan +249">Sudan +249</option>
<option value="Suriname +597">Suriname +597</option>
<option value="Svalbard and Jan Mayen +47">Svalbard and Jan Mayen +47</option>
<option value="Swaziland +268">Swaziland +268</option>
<option value="Sweden +46">Sweden +46</option>
<option value="Switzerland +41">Switzerland +41</option>
<option value="Syria +963">Syria +963</option>
<option value="Taiwan +886">Taiwan +886</option>
<option value="Tajikistan +992">Tajikistan +992</option>
<option value="Tanzania +255">Tanzania +255</option>
<option value="Thailand +66">Thailand +66</option>
<option value="Togo +228">Togo +228</option>
<option value="Tokelau +690">Tokelau +690</option>
<option value="Tonga +676">Tonga +676</option>
<option value="Trinidad and Tobago +1-868">Trinidad and Tobago +1-868</option>
<option value="Tunisia +216">Tunisia +216</option>
<option value="Turkey +90">Turkey +90</option>
<option value="Turkmenistan +993">Turkmenistan +993</option>
<option value="Turks and Caicos Islands +1-649">Turks and Caicos Islands +1-649</option>
<option value="Tuvalu +688">Tuvalu +688</option>
<option value="U.S. Virgin Islands +1-340">U.S. Virgin Islands +1-340</option>
<option value="Uganda +256">Uganda +256</option>
<option value="Ukraine +380">Ukraine +380</option>
<option value="United Arab Emirates +971">United Arab Emirates +971</option>
<option value="United Kingdom +44">United Kingdom +44</option>
<option value="United States +1">United States +1</option>
<option value="Uruguay +598">Uruguay +598</option>
<option value="Uzbekistan +998">Uzbekistan +998</option>
<option value="Vanuatu +678">Vanuatu +678</option>
<option value="Vatican +379">Vatican +379</option>
<option value="Venezuela +58">Venezuela +58</option>
<option value="Vietnam +84">Vietnam +84</option>
<option value="Wallis and Futuna +681">Wallis and Futuna +681</option>
<option value="Western Sahara +212">Western Sahara +212</option>
<option value="Yemen +967">Yemen +967</option>
<option value="Zambia +260">Zambia +260</option>
<option value="Zimbabwe +263">Zimbabwe +263</option>

                                                                </select>     
                                                                
                                                                    
                                                                <div class="input-group-prepend">
                                                                <input type="text" class="form-control form-control-sm" id="mobile" placeholder="Mobile" value="" autocomplete="off-no">    
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        </div> <!-- end col -->
                                                    </div> <!-- end row -->
                                                 
                                                    
                                                    </form></div>
                                                    </div>
                                                    
                                                    
                                                    






                                                    
                                    
                                
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    <div class="card mb-2">
                                                        <!--<div class="card-header bg-dark text-light">    Summary   </div>-->
                                                    <div class="card-body shadow1 border ">

                                                    <!--<h5 class="text-uppercase font-8 text-info mb-3">Summary</h5>-->

                                                    <div class="row">
                                                        <!--
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="firstname">Current Location</label>
                                                                <input type="text" class="form-control form-control-sm" id="firstname" placeholder="Location" value="">
                                                            </div>
                                                        </div>
                                                        -->
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="lastname">Title *</label>
                                                                <input type="text" class="form-control form-control-sm" id="title" placeholder="Title.E.g Senior Software Developer" value="" autocomplete="off-no">
                                                            </div>
                                                        </div> <!-- end col -->
                                                    </div> <!-- end row -->
                                                    
                                                        

                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label for="userbio">About</label>
                                                                <textarea class="form-control form-control-sm" id="userbio" rows="4" placeholder="Write something..." style="height: 112.96px;"></textarea>
                                                            </div>
                                                        </div> <!-- end col -->
                                                    </div> <!-- end row -->
                                                    

  <link rel="stylesheet" type="text/css" href="./Edit Resume _ QUANTUMHUNTS_files/jquery-ui.min.css"> 
  <link rel="stylesheet" type="text/css" href="./Edit Resume _ QUANTUMHUNTS_files/bootstrap-tokenfield.min.css">


  <script src="./Edit Resume _ QUANTUMHUNTS_files/jquery-ui.min.js.download"></script>
  <script src="./Edit Resume _ QUANTUMHUNTS_files/bootstrap-tokenfield.js.download"></script>
                                                    



 
                                                    

                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="firstname">Skillset *</label>
                                                                <!--<input type="text" class="form-control form-control-sm" id="skillset" placeholder="" value="" autocomplete="off-no">-->

 <div class="form-group">
   <div class="tokenfield form-control"><input type="text" class="form-control form-control-sm" id="tokenfield" value="" tabindex="-1" style="position: absolute; left: -10000px;"><input type="text" tabindex="-1" style="position: absolute; left: -10000px;"><input type="text" class="token-input ui-autocomplete-input" autocomplete="off" placeholder="" id="tokenfield-tokenfield" tabindex="0" style="min-width: 60px; width: 559.6px;"></div>
  </div>
  
   <script type="text/javascript">
  $('#tokenfield').tokenfield({
    autocomplete: {
      source: function (request, response) {
          jQuery.get("https://quantumhunts.com/user/manage/profile/skills/", {
              query: request.term
          }, function (data) {
              data = $.parseJSON(data);
              response(data);
          });
      },
      delay: 100
    },
    showAutocompleteOnFocus: true
  });
</script>

                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="lastname">Industry *</label>
                                                                <!--<input type="text" class="form-control form-control-sm" id="industry" placeholder="" value="" autocomplete="off-no"> -->




<select class="select2 form-control form-control-sm select2-multiple select2-hidden-accessible" name="industry[]" id="industry" data-toggle="select2" multiple="" data-placeholder="" data-select2-id="industry" tabindex="-1" aria-hidden="true">
<optgroup>
<option value="Accounting">Accounting</option>
<option value="Airlines/Aviation">Airlines/Aviation</option>
<option value="Alternative Dispute Resolution">Alternative Dispute Resolution</option>
<option value="Alternative Medicine">Alternative Medicine</option>
<option value="Animation">Animation</option>
<option value="Apparel &amp; Fashion">Apparel &amp; Fashion</option>
<option value="Architecture &amp; Planning">Architecture &amp; Planning</option>
<option value="Arts and Crafts">Arts and Crafts</option>
<option value="Automotive">Automotive</option>
<option value="Aviation &amp; Aerospace">Aviation &amp; Aerospace</option>
<option value="Banking">Banking</option>
<option value="Biotechnology">Biotechnology</option>
<option value="Broadcast Media">Broadcast Media</option>
<option value="Building Materials">Building Materials</option>
<option value="Business Supplies and Equipment">Business Supplies and Equipment</option>
<option value="Capital Markets">Capital Markets</option>
<option value="Chemicals">Chemicals</option>
<option value="Civic &amp; Social Organization">Civic &amp; Social Organization</option>
<option value="Civil Engineering">Civil Engineering</option>
<option value="Commercial Real Estate">Commercial Real Estate</option>
<option value="Computer &amp; Network Security">Computer &amp; Network Security</option>
<option value="Computer Games">Computer Games</option>
<option value="Computer Hardware">Computer Hardware</option>
<option value="Computer Networking">Computer Networking</option>
<option value="Computer Software">Computer Software</option>
<option value="Construction">Construction</option>
<option value="Consumer Electronics">Consumer Electronics</option>
<option value="Consumer Goods">Consumer Goods</option>
<option value="Consumer Services">Consumer Services</option>
<option value="Cosmetics">Cosmetics</option>
<option value="Dairy">Dairy</option>
<option value="Defense &amp; Space">Defense &amp; Space</option>
<option value="Design">Design</option>
<option value="Education Management">Education Management</option>
<option value="E-Learning">E-Learning</option>
<option value="Electrical/Electronic Manufacturing">Electrical/Electronic Manufacturing</option>
<option value="Entertainment">Entertainment</option>
<option value="Environmental Services">Environmental Services</option>
<option value="Events Services">Events Services</option>
<option value="Executive Office">Executive Office</option>
<option value="Facilities Services">Facilities Services</option>
<option value="Farming">Farming</option>
<option value="Financial Services">Financial Services</option>
<option value="Fine Art">Fine Art</option>
<option value="Fishery">Fishery</option>
<option value="Food &amp; Beverages">Food &amp; Beverages</option>
<option value="Food Production">Food Production</option>
<option value="Fund-Raising">Fund-Raising</option>
<option value="Furniture">Furniture</option>
<option value="Gambling &amp; Casinos">Gambling &amp; Casinos</option>
<option value="Glass, Ceramics &amp; Concrete">Glass, Ceramics &amp; Concrete</option>
<option value="Government Administration">Government Administration</option>
<option value="Government Relations">Government Relations</option>
<option value="Graphic Design">Graphic Design</option>
<option value="Health, Wellness and Fitness">Health, Wellness and Fitness</option>
<option value="Higher Education">Higher Education</option>
<option value="Hospital &amp; Health Care">Hospital &amp; Health Care</option>
<option value="Hospitality">Hospitality</option>
<option value="Human Resources">Human Resources</option>
<option value="Import and Export">Import and Export</option>
<option value="Individual &amp; Family Services">Individual &amp; Family Services</option>
<option value="Industrial Automation">Industrial Automation</option>
<option value="Information Services">Information Services</option>
<option value="Information Technology and Services">Information Technology and Services</option>
<option value="Insurance">Insurance</option>
<option value="International Affairs">International Affairs</option>
<option value="International Trade and Development">International Trade and Development</option>
<option value="Internet">Internet</option>
<option value="Investment Banking">Investment Banking</option>
<option value="Investment Management">Investment Management</option>
<option value="Judiciary">Judiciary</option>
<option value="Law Enforcement">Law Enforcement</option>
<option value="Law Practice">Law Practice</option>
<option value="Legal Services">Legal Services</option>
<option value="Legislative Office">Legislative Office</option>
<option value="Leisure, Travel &amp; Tourism">Leisure, Travel &amp; Tourism</option>
<option value="Libraries">Libraries</option>
<option value="Logistics and Supply Chain">Logistics and Supply Chain</option>
<option value="Luxury Goods &amp; Jewelry">Luxury Goods &amp; Jewelry</option>
<option value="Machinery">Machinery</option>
<option value="Management Consulting">Management Consulting</option>
<option value="Maritime">Maritime</option>
<option value="Market Research">Market Research</option>
<option value="Marketing and Advertising">Marketing and Advertising</option>
<option value="Mechanical or Industrial Engineering">Mechanical or Industrial Engineering</option>
<option value="Media Production">Media Production</option>
<option value="Medical Devices">Medical Devices</option>
<option value="Medical Practice">Medical Practice</option>
<option value="Mental Health Care">Mental Health Care</option>
<option value="Military">Military</option>
<option value="Mining &amp; Metals">Mining &amp; Metals</option>
<option value="Motion Pictures and Film">Motion Pictures and Film</option>
<option value="Museums and Institutions">Museums and Institutions</option>
<option value="Music">Music</option>
<option value="Nanotechnology">Nanotechnology</option>
<option value="Newspapers">Newspapers</option>
<option value="Non-Profit Organization Management">Non-Profit Organization Management</option>
<option value="Oil &amp; Energy">Oil &amp; Energy</option>
<option value="Online Media">Online Media</option>
<option value="Outsourcing/Offshoring">Outsourcing/Offshoring</option>
<option value="Package/Freight Delivery">Package/Freight Delivery</option>
<option value="Packaging and Containers">Packaging and Containers</option>
<option value="Paper &amp; Forest Products">Paper &amp; Forest Products</option>
<option value="Performing Arts">Performing Arts</option>
<option value="Pharmaceuticals">Pharmaceuticals</option>
<option value="Philanthropy">Philanthropy</option>
<option value="Photography">Photography</option>
<option value="Plastics">Plastics</option>
<option value="Political Organization">Political Organization</option>
<option value="Primary/Secondary Education">Primary/Secondary Education</option>
<option value="Printing">Printing</option>
<option value="Professional Training &amp; Coaching">Professional Training &amp; Coaching</option>
<option value="Program Development">Program Development</option>
<option value="Public Policy">Public Policy</option>
<option value="Public Relations and Communications">Public Relations and Communications</option>
<option value="Public Safety">Public Safety</option>
<option value="Publishing">Publishing</option>
<option value="Railroad Manufacture">Railroad Manufacture</option>
<option value="Ranching">Ranching</option>
<option value="Real Estate">Real Estate</option>
<option value="Recreational Facilities and Services">Recreational Facilities and Services</option>
<option value="Religious Institutions">Religious Institutions</option>
<option value="Renewables &amp; Environment">Renewables &amp; Environment</option>
<option value="Research">Research</option>
<option value="Restaurants">Restaurants</option>
<option value="Retail">Retail</option>
<option value="Security and Investigations">Security and Investigations</option>
<option value="Semiconductors">Semiconductors</option>
<option value="Shipbuilding">Shipbuilding</option>
<option value="Sporting Goods">Sporting Goods</option>
<option value="Sports">Sports</option>
<option value="Staffing and Recruiting">Staffing and Recruiting</option>
<option value="Supermarkets">Supermarkets</option>
<option value="Telecommunications">Telecommunications</option>
<option value="Textiles">Textiles</option>
<option value="Think Tanks">Think Tanks</option>
<option value="Tobacco">Tobacco</option>
<option value="Translation and Localization">Translation and Localization</option>
<option value="Transportation/Trucking/Railroad">Transportation/Trucking/Railroad</option>
<option value="Utilities">Utilities</option>
<option value="Venture Capital &amp; Private Equity">Venture Capital &amp; Private Equity</option>
<option value="Veterinary">Veterinary</option>
<option value="Warehousing">Warehousing</option>
<option value="Wholesale">Wholesale</option>
<option value="Wine and Spirits">Wine and Spirits</option>
<option value="Wireless">Wireless</option>
<option value="Writing and Editing">Writing and Editing</option>
</optgroup>
</select>
                                                            </div>
                                                        </div> <!-- end col -->
                                                    </div> <!-- end row -->
                                                    
                                                        
                                         

                                                    <div class="row">
                                                        <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Current Annual Package *</label>
                                                            <div class="input-group">
                                                                <input type="text" class="form-control form-control-sm" id="current_ctc" placeholder="" value="" autocomplete="off-no">
                                                                <div class="input-group-append">
                                                                <select class="form-control form-control-sm" id="current_ctc_cur">
                                                                <option value="INR">INR</option>  <option value="AED">AED</option> <option value="AFN">AFN</option> <option value="ALL">ALL</option> <option value="AMD">AMD</option> <option value="ANG">ANG</option> <option value="AOA">AOA</option> <option value="ARS">ARS</option> <option value="EURO">EURO</option> <option value="AUD">AUD</option> <option value="AWG">AWG</option> <option value="AZN">AZN</option> <option value="BAM">BAM</option> <option value="BBD">BBD</option> <option value="BDT">BDT</option> <option value="BGN">BGN</option> <option value="BHD">BHD</option> <option value="BIF">BIF</option> <option value="BMD">BMD</option> <option value="BND">BND</option> <option value="BOB">BOB</option> <option value="BRL">BRL</option> <option value="BSD">BSD</option> <option value="BTN">BTN</option> <option value="BWP">BWP</option> <option value="BYR">BYR</option> <option value="BZD">BZD</option> <option value="CAD">CAD</option> <option value="GBP">GBP</option> <option value="CDF">CDF</option> <option value="CHF">CHF</option> <option value="CLP">CLP</option> <option value="CNY">CNY</option> <option value="COP">COP</option> <option value="CRC">CRC</option> <option value="CUC">CUC</option> <option value="CUP">CUP</option> <option value="CVE">CVE</option> <option value="CZK">CZK</option> <option value="DJF">DJF</option> <option value="DKK">DKK</option> <option value="DOP">DOP</option> <option value="DZD">DZD</option> <option value="EGP">EGP</option> <option value="ETB">ETB</option> <option value="EUR">EUR</option> <option value="FJD">FJD</option> <option value="FKP">FKP</option> <option value="GEL">GEL</option> <option value="GHS">GHS</option> <option value="GIP">GIP</option> <option value="GMD">GMD</option> <option value="GNF">GNF</option> <option value="GTQ">GTQ</option> <option value="GYD">GYD</option> <option value="HKD">HKD</option> <option value="HNL">HNL</option> <option value="HRK">HRK</option> <option value="HTG">HTG</option> <option value="HUF">HUF</option> <option value="IDR">IDR</option> <option value="ILS">ILS</option> <option value="IQD">IQD</option> <option value="IRR">IRR</option> <option value="ISK">ISK</option> <option value="JMD">JMD</option> <option value="JOD">JOD</option> <option value="JPY">JPY</option> <option value="KES">KES</option> <option value="KGS">KGS</option> <option value="KHR">KHR</option> <option value="KMF">KMF</option> <option value="KPW">KPW</option> <option value="KRW">KRW</option> <option value="KWD">KWD</option> <option value="KYD">KYD</option> <option value="KZT">KZT</option> <option value="LAK">LAK</option> <option value="LBP">LBP</option> <option value="LKR">LKR</option> <option value="LRD">LRD</option> <option value="LSL">LSL</option> <option value="LYD">LYD</option> <option value="MAD">MAD</option> <option value="MDL">MDL</option> <option value="MGA">MGA</option> <option value="MKD">MKD</option> <option value="MMK">MMK</option> <option value="MNT">MNT</option> <option value="MOP">MOP</option> <option value="MRO">MRO</option> <option value="MUR">MUR</option> <option value="MVR">MVR</option> <option value="MWK">MWK</option> <option value="MXN">MXN</option> <option value="MYR">MYR</option> <option value="MZN">MZN</option> <option value="NAD">NAD</option> <option value="NGN">NGN</option> <option value="NIO">NIO</option> <option value="NOK">NOK</option> <option value="NPR">NPR</option> <option value="NZD">NZD</option> <option value="OMR">OMR</option> <option value="PAB">PAB</option> <option value="PEN">PEN</option> <option value="PGK">PGK</option> <option value="PHP">PHP</option> <option value="PKR">PKR</option> <option value="PLN">PLN</option> <option value="PYG">PYG</option> <option value="QAR">QAR</option> <option value="RON">RON</option> <option value="RSD">RSD</option> <option value="RUB">RUB</option> <option value="RWF">RWF</option> <option value="SAR">SAR</option> <option value="SBD">SBD</option> <option value="SCR">SCR</option> <option value="SDG">SDG</option> <option value="SEK">SEK</option> <option value="SGD">SGD</option> <option value="SHP">SHP</option> <option value="SLL">SLL</option> <option value="SOS">SOS</option> <option value="SRD">SRD</option> <option value="STD">STD</option> <option value="SVC">SVC</option> <option value="SYP">SYP</option> <option value="SZL">SZL</option> <option value="THB">THB</option> <option value="TMM">TMM</option> <option value="TND">TND</option> <option value="TOP">TOP</option> <option value="TRY">TRY</option> <option value="TTD">TTD</option> <option value="TWD">TWD</option> <option value="TZS">TZS</option> <option value="UAH">UAH</option> <option value="UGX">UGX</option> <option value="USD">USD</option> <option value="UYU">UYU</option> <option value="VEB">VEB</option> <option value="VND">VND</option> <option value="VUV">VUV</option> <option value="WST">WST</option> <option value="XAF">XAF</option> <option value="XCD">XCD</option> <option value="XOF">XOF</option> <option value="XPF">XPF</option> <option value="YER">YER</option> <option value="ZAR">ZAR</option> <option value="ZMK">ZMK</option> <option value="ZWD">ZWD</option>                                                  
                                                                </select>    
                                                                </div>
                                                            </div>
                                                        </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Expected Annual Package *</label>
                                                            <div class="input-group">
                                                                <input type="text" class="form-control form-control-sm" id="expected_ctc" placeholder="" value="" autocomplete="off-no">
                                                                <div class="input-group-append">
                                                                <select class="form-control form-control-sm" id="expected_ctc_cur">
                                                                <option value="INR">INR</option> <option value="AED">AED</option> <option value="AFN">AFN</option> <option value="ALL">ALL</option> <option value="AMD">AMD</option> <option value="ANG">ANG</option> <option value="AOA">AOA</option> <option value="ARS">ARS</option> <option value="EURO">EURO</option> <option value="AUD">AUD</option> <option value="AWG">AWG</option> <option value="AZN">AZN</option> <option value="BAM">BAM</option> <option value="BBD">BBD</option> <option value="BDT">BDT</option> <option value="BGN">BGN</option> <option value="BHD">BHD</option> <option value="BIF">BIF</option> <option value="BMD">BMD</option> <option value="BND">BND</option> <option value="BOB">BOB</option> <option value="BRL">BRL</option> <option value="BSD">BSD</option> <option value="BTN">BTN</option> <option value="BWP">BWP</option> <option value="BYR">BYR</option> <option value="BZD">BZD</option> <option value="CAD">CAD</option> <option value="GBP">GBP</option> <option value="CDF">CDF</option> <option value="CHF">CHF</option> <option value="CLP">CLP</option> <option value="CNY">CNY</option> <option value="COP">COP</option> <option value="CRC">CRC</option> <option value="CUC">CUC</option> <option value="CUP">CUP</option> <option value="CVE">CVE</option> <option value="CZK">CZK</option> <option value="DJF">DJF</option> <option value="DKK">DKK</option> <option value="DOP">DOP</option> <option value="DZD">DZD</option> <option value="EGP">EGP</option> <option value="ETB">ETB</option> <option value="EUR">EUR</option> <option value="FJD">FJD</option> <option value="FKP">FKP</option> <option value="GEL">GEL</option> <option value="GHS">GHS</option> <option value="GIP">GIP</option> <option value="GMD">GMD</option> <option value="GNF">GNF</option> <option value="GTQ">GTQ</option> <option value="GYD">GYD</option> <option value="HKD">HKD</option> <option value="HNL">HNL</option> <option value="HRK">HRK</option> <option value="HTG">HTG</option> <option value="HUF">HUF</option> <option value="IDR">IDR</option> <option value="ILS">ILS</option>  <option value="IQD">IQD</option> <option value="IRR">IRR</option> <option value="ISK">ISK</option> <option value="JMD">JMD</option> <option value="JOD">JOD</option> <option value="JPY">JPY</option> <option value="KES">KES</option> <option value="KGS">KGS</option> <option value="KHR">KHR</option> <option value="KMF">KMF</option> <option value="KPW">KPW</option> <option value="KRW">KRW</option> <option value="KWD">KWD</option> <option value="KYD">KYD</option> <option value="KZT">KZT</option> <option value="LAK">LAK</option> <option value="LBP">LBP</option> <option value="LKR">LKR</option> <option value="LRD">LRD</option> <option value="LSL">LSL</option> <option value="LYD">LYD</option> <option value="MAD">MAD</option> <option value="MDL">MDL</option> <option value="MGA">MGA</option> <option value="MKD">MKD</option> <option value="MMK">MMK</option> <option value="MNT">MNT</option> <option value="MOP">MOP</option> <option value="MRO">MRO</option> <option value="MUR">MUR</option> <option value="MVR">MVR</option> <option value="MWK">MWK</option> <option value="MXN">MXN</option> <option value="MYR">MYR</option> <option value="MZN">MZN</option> <option value="NAD">NAD</option> <option value="NGN">NGN</option> <option value="NIO">NIO</option> <option value="NOK">NOK</option> <option value="NPR">NPR</option> <option value="NZD">NZD</option> <option value="OMR">OMR</option> <option value="PAB">PAB</option> <option value="PEN">PEN</option> <option value="PGK">PGK</option> <option value="PHP">PHP</option> <option value="PKR">PKR</option> <option value="PLN">PLN</option> <option value="PYG">PYG</option> <option value="QAR">QAR</option> <option value="RON">RON</option> <option value="RSD">RSD</option> <option value="RUB">RUB</option> <option value="RWF">RWF</option> <option value="SAR">SAR</option> <option value="SBD">SBD</option> <option value="SCR">SCR</option> <option value="SDG">SDG</option> <option value="SEK">SEK</option> <option value="SGD">SGD</option> <option value="SHP">SHP</option> <option value="SLL">SLL</option> <option value="SOS">SOS</option> <option value="SRD">SRD</option> <option value="STD">STD</option> <option value="SVC">SVC</option> <option value="SYP">SYP</option> <option value="SZL">SZL</option> <option value="THB">THB</option> <option value="TMM">TMM</option> <option value="TND">TND</option> <option value="TOP">TOP</option> <option value="TRY">TRY</option> <option value="TTD">TTD</option> <option value="TWD">TWD</option> <option value="TZS">TZS</option> <option value="UAH">UAH</option> <option value="UGX">UGX</option> <option value="USD">USD</option> <option value="UYU">UYU</option> <option value="VEB">VEB</option> <option value="VND">VND</option> <option value="VUV">VUV</option> <option value="WST">WST</option> <option value="XAF">XAF</option> <option value="XCD">XCD</option> <option value="XOF">XOF</option> <option value="XPF">XPF</option> <option value="YER">YER</option> <option value="ZAR">ZAR</option> <option value="ZMK">ZMK</option> <option value="ZWD">ZWD</option>                                                      
                                                                </select>    
                                                                </div>
                                                            </div>
                                                        </div>
                                                        </div>
                                                        
                                                    </div> <!-- end row -->                                                    

 
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="city">Current Location (City)*</label>
                                                                <input type="text" class="form-control form-control-sm" id="city" placeholder="" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="preferredcity">Preferred Location (City)*</label>
                                                                <input type="text" class="form-control form-control-sm" id="preferredcity" placeholder="" value="" autocomplete="off-no">
                                                            </div>
                                                        </div> <!-- end col -->
                                                    </div> <!-- end row -->
                                                    
                                                        
                                                        


                                                    </div>
                                                    </div>

    
 
                                                        

                                                    <div class="card mb-2">
                                                    
                                                    <!--<div class="card-header bg-dark text-light"> Company Info   </div>-->
                                                        
                                                    <div class="card-body shadow1 border ">

                                                    <!--<h5 class="text-uppercase font-8 text-info mb-3">Company Info</h5>-->
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="companyname">Company Name</label>
                                                                <input type="text" class="form-control form-control-sm" id="company1" placeholder="Company" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label for="companyname">Role</label>
                                                                <input type="text" class="form-control form-control-sm" id="role1" placeholder="Role" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="cwebsite">Start</label>
                                                                <input type="text" class="form-control form-control-sm" id="start1" placeholder="Start date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="cwebsite">End</label>
                                                                <input type="text" class="form-control form-control-sm" id="end1" placeholder="End date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                         
                                                        <div class="col-md-1">
                                                            <div class="form-group">
                                                            </div>
                                                        </div> <!-- end col -->
                                                    </div> <!-- end row -->



                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="company2" placeholder="Company" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="role2" placeholder="Role" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="start2" placeholder="Start date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="end2" placeholder="End date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                         
                                                        <div class="col-md-1">
                                                            <div class="form-group">
                                                            
                                                            </div>
                                                        </div> <!-- end col -->
                                                    </div> <!-- end row -->
                                                    
                                                    
    
    
                                                   <!-- end row -->
                                                    
    
    
                                                   <!-- end row -->
                                                    
     
     
     
                                                    <!-- end row -->
     
   
  
                                                <!--
                                                <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="company6" placeholder="Company" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="role6" placeholder="Role" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="start6" placeholder="Start date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="end6" placeholder="End date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                         
                                                        <div class="col-md-1">
                                                            <div class="form-group">
                                                            
                                                            </div>
                                                        </div>  
                                                        </div>  end row -->
  
  
  



                                                <!--
                                                <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="company7" placeholder="Company" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="role7" placeholder="Role" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="start7" placeholder="Start date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="end7" placeholder="End date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                         
                                                        <div class="col-md-1">
                                                            <div class="form-group">
                                                            
                                                            </div>
                                                        </div> 
                                                    </div> -->
  
  
  
  
                                                <!--
  
                                                <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="company8" placeholder="Company" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="role8" placeholder="Role" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="start8" placeholder="Start date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="end8" placeholder="End date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                         
                                                        <div class="col-md-1">
                                                            <div class="form-group">
                                                            
                                                            </div>
                                                        </div> 
                                                    </div>  -->
  
  
  
  
                                                <!--
                                                <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="company9" placeholder="Company" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="role9" placeholder="Role" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="start9" placeholder="Start date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="end9" placeholder="End date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                         
                                                        <div class="col-md-1">
                                                            <div class="form-group">
                                                            
                                                            </div>
                                                        </div>
                                                    </div> end row -->
  
  
  
  
  
                                                <!--
                                                <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="company10" placeholder="Company" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="role10" placeholder="Role" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="start10" placeholder="Start date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="end10" placeholder="End date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                         
                                                        <div class="col-md-1">
                                                            <div class="form-group">
                                                            
                                                            </div>
                                                        </div> 
                                                    </div> end row -->
  
        
                                            </div>
                                            </div>
                                            
                                            
                                <script>
function ten() {
  // Get the checkbox
  var checkBox = document.getElementById("10th");
  // Get the output text
 // var text = document.getElementById("text");

  // If the checkbox is checked, display the output text
  if (checkBox.checked == true){
    //text.style.display = "block";
  } else {
    //text.style.display = "none";
  }
}                                
                                </script>
  
                                                      <div class="card mb-2">
                                                    <!--<div class="card-header bg-dark text-light"> Education   </div> -->
                                                    <div class="card-body shadow1 border ">

                                                     <!-- <h5 class="text-uppercase font-8 text-info mb-3">Education</h5> -->
                                                    <div class="row">
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label for="companyname">School Name</label>
                                                                <input type="text" class="form-control form-control-sm" id="school10" placeholder="School Name #1" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="companyname">Course</label>
                                                                <input type="text" class="form-control form-control-sm" id="course10" placeholder="" disabled="" value="10th" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="cwebsite">Start</label>
                                                                <input type="text" class="form-control form-control-sm" id="start10" placeholder="Start date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="cwebsite">End</label>
                                                                <input type="text" class="form-control form-control-sm" id="end10" placeholder="End date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                         
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="cwebsite">Score</label>
                                                                <input type="text" class="form-control form-control-sm" id="score10" placeholder="10th Mark" value="" autocomplete="off-no">
                                                            </div>
                                                          
                                                       </div> <!-- end col -->
                                                        <div class="col-md-1">
                                                            <div class="form-group">
                                                            <label for="cwebsite">NA</label>
                                                            <div class="mt-0">
    <div class="custom-control custom-checkbox custom-control-inline">
        <input type="checkbox" class="custom-control-input" id="customCheck3">
        <label class="custom-control-label" for="customCheck3"></label>
    </div>
</div>
                                                            
                                                            <!--<div class="mt-0">
                                                                 <label for="cwebsite">NA</label>
                                                                <div class="custom-control custom-checkbox custom-control-inline">
                                                                    <input type="checkbox" class="form-control form-control-sm custom-control-input form-control form-control-sm" id="10th">
                                                                    <label class="custom-control-label" for="customCheck3"></label>
                                                                </div>
                                                            </div>-->
                                                        </div>     
                                                        </div>    
                                                    </div> <!-- end row -->


                                                <div class="row">
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm form-control form-control-sm-sm" id="school12" placeholder="School Name #2" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm form-control form-control-sm-sm" id="course12" placeholder="" disabled="" value="12th" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm form-control form-control-sm-sm" id="start12" placeholder="Start date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm form-control form-control-sm-sm" id="end12" placeholder="End date" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>             
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm form-control form-control-sm-sm" id="score12" placeholder="12th Mark" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>  
                                                        <div class="col-md-1">
                                                            <div class="form-group">
                                                           <div class="mt-0">
    <div class="custom-control custom-checkbox custom-control-inline">
        <input type="checkbox" class="custom-control-input" id="customCheck4">
        <label class="custom-control-label" for="customCheck4"></label>
    </div>
</div>
</div>
</div>
                                                        
                                                         <!-- end col -->
                                                    </div> <!-- end row -->
                                                    
                                                    <p>&nbsp;</p>
                                                    
                                                <div class="row">
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label for="companyname">Institution Name</label>
                                                                <input type="text" class="form-control form-control-sm form-control form-control-sm-sm" id="school1" placeholder="Instituion Name #1" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="companyname">Course</label>
                                                                <input type="text" class="form-control form-control-sm" id="course1" placeholder="Course #1" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="companyname">Start date</label>
                                                                <input type="text" class="form-control form-control-sm" id="course1start" placeholder="Start date #1" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="companyname">End date</label>
                                                                <input type="text" class="form-control form-control-sm" id="course1end" placeholder="End date #1" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>              
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <label for="cwebsite">Score</label>
                                                                <input type="text" class="form-control form-control-sm" id="score1" placeholder="Score #1" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                                                                                 
                                                         <!-- end col -->
                                                    </div> <!-- end row -->
                                                    

                                                <div class="row">
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="school2" placeholder="Instituion Name #2" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="course2" placeholder="Course  #2" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                        
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="course2start" placeholder="Start date  #2" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>     
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="course2end" placeholder="End date  #2" value="" data-date-format="M-yy" data-provide="datepicker" data-date-autoclose="true" data-date-min-view-mode="1" autocomplete="off-no">
                                                            </div>
                                                        </div>    
                                                        <div class="col-md-2">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-control-sm" id="score2" placeholder="Score #2" value="" autocomplete="off-no">
                                                            </div>
                                                        </div>                                                                                                                 
                                                         <!-- end col -->
                                                    </div> <!-- end row -->                                                    





                                                 <!-- end row -->                                                    




                                                 <!-- end row -->                                                    




                                                 <!-- end row -->                                                    


                                                    
                                                    </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
   
                                                  
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                              <div class="card mb-2">
                                                  <!--<div class="card-header bg-dark text-light"> Others   </div>-->
                                                <div class="card-body shadow1 border ">

                                                    <!--<h5 class="text-uppercase font-8 text-info mb-3">OTHERS</h5>-->
<!--
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="social-fb">Facebook</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text"><i class="mdi mdi-facebook"></i></span>
                                                                    </div>
                                                                    <input type="text" class="form-control form-control-sm" id="social-fb" placeholder="Url">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="social-tw">Twitter</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text"><i class="mdi mdi-twitter"></i></span>
                                                                    </div>
                                                                    <input type="text" class="form-control form-control-sm" id="social-tw" placeholder="Username">
                                                                </div>
                                                            </div>
                                                        </div> 
                                                    </div>  -->
    
                                                    <div class="row">
                                                        <!--
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="social-insta">Instagram</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text"><i class="mdi mdi-instagram"></i></span>
                                                                    </div>
                                                                    <input type="text" class="form-control form-control-sm" id="social-insta" placeholder="Url">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        -->
                                                         <!-- end col -->
                                                    </div> <!-- end row -->
    <!--
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="social-sky">Skype</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text"><i class="mdi mdi-skype"></i></span>
                                                                    </div>
                                                                    <input type="text" class="form-control form-control-sm" id="social-sky" placeholder="@username">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="social-gh">Github</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text"><i class="mdi mdi-github-circle"></i></span>
                                                                    </div>
                                                                    <input type="text" class="form-control form-control-sm" id="social-gh" placeholder="Username">
                                                                </div>
                                                            </div>
                                                        </div> 
                                                    </div>  -->
                                                    
                                                    
                                                    <div class="alert alert-danger display-error" style="display:none;">
                                                        
                                                    </div>
                                                    
                                                    <div class="alert alert-primary display-success" style="display:none;">
                                                        
                                                    </div>
                                                    
                                                    <div class="text-left">
                                                        <button id="submit" class="btn btn-primary mt-2"> Save</button>
                                                    </div>
                                                    
                                                    
                                                
                                            
                                            <!-- end settings content-->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  <!-- include Google hosted jQuery Library -->
<script src="./Edit Resume _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#submit').click(function(e){
        e.preventDefault();


//alert(previewtxt);
//alert(successxt);

var firstname=$("#firstname").val();
var lastname=$("#lastname").val();
var useremail=$("#useremail").val();
var dateofbirth=$("#dateofbirth").val();
var noticecode=$("#noticecode").val();
var countrycode=$("#countrycode option:selected").val();
var mobile=$("#mobile").val();
var title=$("#title").val();
var userbio=$("#userbio").val();
var skillset=$("#tokenfield").val();
//var industry=$("#industry").val();
var industry=$("#industry option:selected").val();
//alert(countrycode);
//alert(mobile);
//var thefile = document.getElementByName('file');
//alert($("#file").val(););



var industries = [];
$.each($("#industry option:selected"), function(){            
            industries.push($(this).val());
        });
//alert("You have selected the country - " + industries.join(", "));
//alert(industries);

var current_ctc=$("#current_ctc").val();
var current_ctc_cur=$("#current_ctc_cur option:selected").val();
var expected_ctc=$("#expected_ctc").val();
var expected_ctc_cur=$("#expected_ctc_cur option:selected").val();
var city=$("#city").val();
var preferredcity=$("#preferredcity").val();

var company1=$("#company1").val();
var role1=$("#role1").val();
var start1=$("#start1").val();
var end1=$("#end1").val();

var company2=$("#company2").val();
var role2=$("#role2").val();
var start2=$("#start2").val();
var end2=$("#end2").val();




var school10=$("#school10").val();
var course10=$("#course10").val();
var start10=$("#start10").val();
var end10=$("#end10").val();
var score10=$("#score10").val();


var school12=$("#school12").val();
var course12=$("#course12").val();
var start12=$("#start12").val();
var end12=$("#end12").val();
var score12=$("#score12").val();


var school1=$("#school1").val();
var course1=$("#course1").val();
var course1start=$("#course1start").val();
var course1end=$("#course1end").val();
var score1=$("#score1").val();

var school2=$("#school2").val();
var course2=$("#course2").val();
var course2start=$("#course2start").val();
var course2end=$("#course2end").val();
var score2=$("#score2").val();



/*      var email = $("#email").val();
        var firstname = $("#firstname").val();
        var lastname = $("#lastname").val();
        var title = $("#title").val();
        //var email_code = $("#email_code").val();
        //var countrycode = $("#countrycode").val();   
        var countrycode =$('#countrycode option:selected').val();
        var mobile = $("#mobile").val(); 
        var password = $("#password").val(); 
        var title = $("#title").val();   
        */
        

/*
alert(firstname+lastname+useremail+dateofbirth+noticecode+countrycode+mobile+title+userbio+skillset+industry+current_ctc+current_ctc_cur+expected_ctc+expected_ctc_cur+city+preferredcity+
company1+role1+start1+end1+
company2+role2+start2+end2+
company3+role3+start3+end3+
company4+role4+start4+end4+
company5+role5+start5+end5+
company6+role6+start6+end6+
company7+role7+start7+end7+
company8+role8+start8+end8+
company9+role9+start9+end9+
company10+role10+start10+end10+
school10+course10+start10+end10+score10+
school12+course12+start12+end12+score12+
school1+course1+course1start+course1end+score1+
school2+course2+course2start+course2end+score2+
school3+course3+course3start+course3end+score3+
school4+course4+course4start+course4end+score4+
school5+course5+course5start+course5end+score5+
linkedIn);
*/

//alert(skillset);
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/edit-profile/edit-profile.php",
            dataType: "json",
            data: {firstname:firstname,lastname:lastname,useremail:useremail,dateofbirth:dateofbirth,noticecode:noticecode,countrycode:countrycode,mobile:mobile,title:title,userbio:userbio,skillset:skillset,industry:industries,current_ctc:current_ctc,current_ctc_cur:current_ctc_cur,expected_ctc:expected_ctc,expected_ctc_cur:expected_ctc_cur,city:city,preferredcity:preferredcity,company1:company1,role1:role1,start1:start1,end1:end1,company2:company2,role2:role2,start2:start2,end2:end2,start10:start10,end10:end10,school10:school10,course10:course10,start10:start10,end10:end10,score10:score10,school12:school12,course12:course12,start12:start12,end12:end12,score12:score12,school1:school1,course1:course1,course1start:course1start,course1end:course1end,score1:score1,school2:school2,course2:course2,course2start:course2start,course2end:course2end,score2:score2},            
            success : function(data){
                if (data.code == "200")
                {
                    $.NotificationApp.send("Profile updated","Resume has been saved successfully","bottom-right","gray","Info");
                    //alert("Success: " +data.msg);
                    $(".display-error").hide();
                    $(".display-success").html("Saved successfully.");
                    $(".display-success").css("display","block");
                } 
                else 
                {
                    //alert("Unable to save " +data.msg);
                    $(".display-success").hide();
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                }   
            }
        });


      });
  });
</script>

    
    <script>
    function expandTextarea(id) {
    document.getElementById(id).addEventListener('keyup', function() {
        this.style.overflow = 'hidden';
        this.style.height = 0;
        this.style.height = this.scrollHeight + 'px';
    }, false);
}

expandTextarea('userbio');
    
  </script>  
  
  <script>
  $("#userbio").height( $("#userbio")[0].scrollHeight );
  $("textarea").height( $("textarea")[0].scrollHeight );
  </script>
    
   <!-- Basic Toast 
<div class="toast fade" role="alert" aria-live="assertive" aria-atomic="true" data-toggle="toast">
    <div class="toast-header">
        <img src="https://s3.amazonaws.com/images.wealthyaffiliate.com/uploads/1266204/sitecontent/118402c1fb313b3497e5ec5cc782fe02_cropped.png?1551802950" alt="brand-logo" height="12" class="mr-1" />
        <strong class="mr-auto">Hyper</strong>
        <small>11 mins ago</small>
        <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="toast-body">
        We've saved your information.
    </div>
</div> end toast--> 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
                                       
                                    </div> <!-- end card body -->
                                </div> <!-- end card -->
                                
                                
                                
                              
                                
                                
                                
                   
                                 




<script>
    $(document).ready(function (e) {
 $("#form_doc").on('submit',(function(e) {
  e.preventDefault();
  
  //alert("hello");
  
  $.ajax({
    url: "https://quantumhunts.com/user/manage/profile/upload_doc/",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   //dataType: 'json',
   beforeSend : function()
   {
    //$("#preview").fadeOut();
    $("#err_doc").fadeOut();
   },
   success: function(data)
      {
        //alert(data);
        //alert(data.code);
        //alert(data.msg);
    if(data=='invalid file')
    {
        //alert("1");
     // invalid file format.
     //$("#preview").html(data.msg).fadeIn();
     //$("#preview").html(bata).fadeIn();
     $("#err_doc").html("Invalid File.").fadeIn();
    }
    else if(data=='Session issue')
    {
     $("#err_doc").html("Login again to upload the resume.").fadeIn();        
    }
    else if(data=='Server issue')
    {
     $("#err_doc").html("Unable to upload. Please retry later.").fadeIn();        
    }    
    else if(data=='Upload issue')
    {
     $("#err_doc").html("Unable to upload to the server. Please retry later.").fadeIn();        
    }        
    else if(data=='Invalid file extension')
    {
     $("#err_doc").html("Invalid file extension. Please retry with correct file format.").fadeIn();        
    }            
    else
    {
        $("#success_doc").html("Upload Successful").fadeIn();
     //alert("2");
     // view uploaded file.
     $.NotificationApp.send("Resume Uploaded","Document uploaded successfully and linked to the resume","bottom-right","gray","Info");
     $("#preview_doc").html(data).fadeIn();
     $("#form_doc")[0].reset(); 
    }
      },
     error: function(e) 
      {
    $("#err_doc").html(e).fadeIn();
      }          
    });
 }));
});
</script>
                          
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                            </div> <!-- end col -->
                            
                            <div class="col-4">



                                                                
                                
<div class="card border cta-box">
                                    <div class="card-body">
                                        
                                    <div class="float-center text-center"><img class="img-fluid" src="./Edit Resume _ QUANTUMHUNTS_files/source.gif" style="width:50%;height:50%;"></div>
                                    <h4 class="text-dark">Jobs</h4>

                                    <p class="mb-3">Explore relevent opportunities using Jobs at <span class="text-dark text-uppercase font-13 font-weight-bold">QuantumHunts</span>. Get the latest jobs and industry news.</p>

                                    <div class="float-center text-center">
                                    
            <a class="btn btn-outline-primary btn-sm btn-wide transition-3d-hover mb-2 mb-sm-0 mr-2" href="https://quantumhunts.com/jobs">Jobs</a>                                    
                        
                                    </div>

                                    </div>
</div>                                        
                                

                                                                
                                <hr>
                                
                                <div class="card border cta-box overflow-hidden">
                                    <div class="card-body ribbon-box">
                                        <!--<span class="badge badge-primary">Top Jobs</span>-->
                                        <h5 class="mb-0 font-weight-bold mb-1 text-left text-uppercase text-primary purpletitle">Top Jobs</h5>
                                        <p>&nbsp;</p>
                                        <!--<div class="ribbon-two ribbon-two-primary"><span>Top Jobs</span></div>-->


                                <!--
<div class="text-center cta-box1">
<img src="https://quantumhunts.com/user/assets/images/hero/mail_qh.png" height="64">
</div>

<h3 class="m-0 mb-3 font-weight-bold cta-box-title text-left">Popular Jobs</h3>
-->




<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/anti-money-laundering-lead-sensiple-india-pvt-ltd-chennai">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/anti-money-laundering-lead-sensiple-india-pvt-ltd-chennai">  
                                                     
                                                        <strong class="text-dark hoverzoom">Anti Money Laundering Lead</strong><br>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span>,
                                                       <span class="text-muted">Chennai, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/anti-money-laundering-lead-sensiple-india-pvt-ltd-chennai">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Anti Money Laundering Lead</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/anti-money-laundering-lead-chennai--india/1">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Anti Money Laundering Lead</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/anti-money-laundering-lead-chennai--india/1">Anti Money Laundering Lead</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Sensiple India Pvt Ltd                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Chennai, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job1').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid1").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job1").html('Saved');
                    $("#job1").removeClass('btn-primary');
                    $("#job1").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 2 Software company <BR/>
                                        Anti Money Laundering Lead <BR/>
                                        Chennai, India <BR/>
                                        Permanent  <BR/>
                                        Finance  <BR/>
                                          <BR/>
                                        We are a New Jersey corporation, established in 1999. Our footprints around the globe help us to ensure that we consistently maintain our delivery standards. We deliver IT products and services in the areas of BFSI, Customer Experience, Digital & Enterprise Transformation, Infrastructure and Independent Testing from ideation to execution, giving our clients an edge to outperform the competition. We do also provide Consulting and Staffing services in these areas. We are an ISO and CMMI 3 certification. <BR/>
                                        B.E/B.Tech <BR/>
                                        5,00,000 <BR/>
                                        7,00,000 <BR/>
                                        INR <BR/>
                                        AML, Finance, Business Analyst <BR/>
                                        5 <BR/>
                                        26/02/2020 <BR/>
                                        26/03/2020 <BR/>
                                        26/02/2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/senior-business-automation-associate-soroco-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/senior-business-automation-associate-soroco-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Senior Business Automation Associate</strong><br>
                                                       <span class="text-muted">Soroco</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/senior-business-automation-associate-soroco-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Senior Business Automation Associate</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/senior-business-automation-associate-bangalore--india/2">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Senior Business Automation Associate</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/senior-business-automation-associate-bangalore--india/2">Senior Business Automation Associate</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Soroco                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job2').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid2").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job2").html('Saved');
                    $("#job2").removeClass('btn-primary');
                    $("#job2").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Leading Artificial Intelligence Startup <BR/>
                                        Senior Business Automation Associate <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        DeepTech  <BR/>
                                          <BR/>
                                        We are a US-based Leading Software company providing AI based solutions to their clients. Their goal is to make work place smarter and provides support to top clients across various industries such as Retail/E-commerce, Banking, Financial, Healthcare and Airlines.
 <BR/>
                                        B.E/B.Tech <BR/>
                                        10,00,000 <BR/>
                                        12,00,000 <BR/>
                                        INR <BR/>
                                        Artificial Intelligence, Machine Learning <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/full-stack-developer-infosys-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/full-stack-developer-infosys-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Full Stack Developer</strong><br>
                                                       <span class="text-muted">Infosys</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/full-stack-developer-infosys-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">Infosys</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/full-stack-developer-bangalore--india/3">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">Infosys</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/full-stack-developer-bangalore--india/3">Full Stack Developer</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Infosys                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job3').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid3").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job3").html('Saved');
                    $("#job3").removeClass('btn-primary');
                    $("#job3").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Full Stack Developer <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        Leading provider of next generation consulting, technology and outsourcing solutions. Ranks as one among the top 100 most innovative companies in Forbes.
 <BR/>
                                        B.E <BR/>
                                        5,00,000 <BR/>
                                        8,00,000 <BR/>
                                        INR <BR/>
                                        Java , Full stack <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/associate-consultant-fresher-tcs-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/associate-consultant-fresher-tcs-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Associate Consultant- Fresher</strong><br>
                                                       <span class="text-muted">TCS</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/associate-consultant-fresher-tcs-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Associate Consultant- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/associate-consultant--fresher-bangalore--india/6">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Associate Consultant- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/associate-consultant--fresher-bangalore--india/6">Associate Consultant- Fresher</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        TCS                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job6').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid6").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job6").html('Saved');
                    $("#job6").removeClass('btn-primary');
                    $("#job6").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Associate Consultant- Fresher <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        (Nasdaq-100 listed) is one of the world’s leading professional services companies, transforming clients’ business, operating and technology models for the digital era.  

 <BR/>
                                        B.E/B.Tech <BR/>
                                        4,00,000 <BR/>
                                        6,00,000 <BR/>
                                        INR <BR/>
                                        Fresher <BR/>
                                        20 <BR/>
                                        26-02-2020 <BR/>
                                        21-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/data-scientist-lead-soroco-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/data-scientist-lead-soroco-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Data Scientist Lead</strong><br>
                                                       <span class="text-muted">Soroco</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/data-scientist-lead-soroco-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Data Scientist Lead</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/data-scientist-lead-bangalore--india/7">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Data Scientist Lead</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/data-scientist-lead-bangalore--india/7">Data Scientist Lead</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Soroco                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job7').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid7").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job7").html('Saved');
                    $("#job7").removeClass('btn-primary');
                    $("#job7").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Leading Artificial Intelligence Startup <BR/>
                                        Data Scientist Lead <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        DeepTech  <BR/>
                                          <BR/>
                                        We are a US-based Leading Software company providing AI based solutions to their clients. Their goal is to make work place smarter and provides support to top clients across various industries such as Retail/E-commerce, Banking, Financial, Healthcare and Airlines.
 <BR/>
                                        B.E/B.tech/M.tech <BR/>
                                        6,00,000 <BR/>
                                        10,00.000 <BR/>
                                        INR <BR/>
                                        Artificial Intelligence, Machine Learning, Data Science <BR/>
                                        5 <BR/>
                                        21/02/2020 <BR/>
                                        21/03/2020 <BR/>
                                        21/02/2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/software-test-analyst-fresher-tcs-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/software-test-analyst-fresher-tcs-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Software Test Analyst- Fresher</strong><br>
                                                       <span class="text-muted">TCS</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/software-test-analyst-fresher-tcs-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Software Test Analyst- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/software-test-analyst--fresher-bangalore--india/9">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Software Test Analyst- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/software-test-analyst--fresher-bangalore--india/9">Software Test Analyst- Fresher</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        TCS                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job9').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid9").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job9").html('Saved');
                    $("#job9").removeClass('btn-primary');
                    $("#job9").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Software Test Analyst- Fresher <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        (Nasdaq-100 listed) is one of the world’s leading professional services companies, transforming clients’ business, operating and technology models for the digital era.  

 <BR/>
                                        B.E/B.Tech <BR/>
                                        4,00,000 <BR/>
                                        6,00,000 <BR/>
                                        INR <BR/>
                                        Fresher <BR/>
                                        20 <BR/>
                                        26-02-2020 <BR/>
                                        21-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/chartered-accountant-corporate-consultant-sensiple-chennai">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/chartered-accountant-corporate-consultant-sensiple-chennai">  
                                                     
                                                        <strong class="text-dark hoverzoom">Chartered Accountant Corporate Consultant</strong><br>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span>,
                                                       <span class="text-muted">Chennai, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/chartered-accountant-corporate-consultant-sensiple-chennai">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Chartered Accountant Corporate Consultant</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/chartered-accountant-corporate-consultant-chennai--india/12">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Chartered Accountant Corporate Consultant</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/chartered-accountant-corporate-consultant-chennai--india/12">Chartered Accountant Corporate Consultant</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Sensiple India Pvt Ltd                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Chennai, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job12').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid12").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job12").html('Saved');
                    $("#job12").removeClass('btn-primary');
                    $("#job12").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Leading Tier 2 Software company <BR/>
                                        Chartered Accountant Corporate Consultant <BR/>
                                        Chennai, India <BR/>
                                        Permanent  <BR/>
                                        Finance  <BR/>
                                          <BR/>
                                        ISO and CMMI 3 certified IT Software company. <BR/>
                                        Completion of CA Finals <BR/>
                                        7,00,000 <BR/>
                                        10,00,000 <BR/>
                                        INR <BR/>
                                        CA, Finance,  <BR/>
                                         <BR/>
                                        26/02/2020 <BR/>
                                        26/03/2020 <BR/>
                                        26/02/2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/hr-fresher-tcs-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/hr-fresher-tcs-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">HR- Fresher</strong><br>
                                                       <span class="text-muted">TCS</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/hr-fresher-tcs-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">HR- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/hr--fresher-bangalore--india/10">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">HR- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/hr--fresher-bangalore--india/10">HR- Fresher</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        TCS                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job10').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid10").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job10").html('Saved');
                    $("#job10").removeClass('btn-primary');
                    $("#job10").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        HR- Fresher <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        (Nasdaq-100 listed) is one of the world’s leading professional services companies, transforming clients’ business, operating and technology models for the digital era.  

 <BR/>
                                        B.E/B.Tech/B.sc and MBA HR_2020 Graduates <BR/>
                                        4,00,000 <BR/>
                                        6,00,000 <BR/>
                                        INR <BR/>
                                        Fresher <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        21-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/full-stack-developer-hcl-ncr">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/full-stack-developer-hcl-ncr">  
                                                     
                                                        <strong class="text-dark hoverzoom">Full Stack Developer</strong><br>
                                                       <span class="text-muted">HCL</span>,
                                                       <span class="text-muted">NCR,India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/full-stack-developer-hcl-ncr">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">HCL</span><BR/>
                                                       <span class="text-muted">NCR,India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/full-stack-developer-ncr-india/13">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">HCL</span><BR/>
                                                       <span class="text-muted">NCR,India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/full-stack-developer-ncr-india/13">Full Stack Developer</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        HCL                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        NCR,India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job13').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid13").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job13").html('Saved');
                    $("#job13").removeClass('btn-primary');
                    $("#job13").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Full Stack Developer <BR/>
                                        NCR,India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        Leading provider of next generation consulting, technology and outsourcing solutions. Ranks as one among the top 100 most innovative companies in Forbes.
 <BR/>
                                        B.E <BR/>
                                        5,00,000 <BR/>
                                        8,00,000 <BR/>
                                        INR <BR/>
                                        Java , Full stack <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/golang-developer-engineer-babu-indore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/golang-developer-engineer-babu-indore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Golang Developer</strong><br>
                                                       <span class="text-muted">Engineer Babu</span>,
                                                       <span class="text-muted">Indore,India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/golang-developer-engineer-babu-indore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Golang Developer</Strong><BR/>
                                                       <span class="text-muted">Engineer Babu</span><BR/>
                                                       <span class="text-muted">Indore,India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/golang-developer-indore-india/14">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Golang Developer</Strong><BR/>
                                                       <span class="text-muted">Engineer Babu</span><BR/>
                                                       <span class="text-muted">Indore,India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/golang-developer-indore-india/14">Golang Developer</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Engineer Babu                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Indore,India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job14').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid14").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job14").html('Saved');
                    $("#job14").removeClass('btn-primary');
                    $("#job14").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Vibrant and Enthusiastic Startup <BR/>
                                        Golang Developer <BR/>
                                        Indore,India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        Leading provider of next generation technology and software solutions from Indore to worldwide.
 <BR/>
                                        B.E <BR/>
                                        5,00,000 <BR/>
                                        9,00,000 <BR/>
                                        INR <BR/>
                                        Java , Full stack <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->


                                
                                
                                    </div>
                                    <!-- end card-body -->
                                </div>   
                                
                                
                                
                                
<script type="text/javascript">
    $(window).on('load',function(){
        setTimeout(function() {
    $('#thankyou-modal').modal('show');}, 1000)
//        $('#video-modal').modal('show');
    });
</script>
<!-- Signup modal-->

<!-- /.modal -->


















<!-- Signup modal-->

<div id="resume-record" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-left">

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
                        <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold">Live Resume</h5> 
               
                        
                        <p class="text-left ">You can now record your resume online and publish to recruiters.</p>
                      
<ul class="nav nav-tabs tab-grad">
    <li class="nav-item mr-1">
        <a href="https://quantumhunts.com/user/manage/profile/#recordtab" data-toggle="tab" class="nav-link rounded-0 btn-primary text-light">
        <i class="mdi mdi-home-variant d-md-none d-block"></i>
            <span class="d-none d-md-block">Record Video</span>
        </a>
    </li>
    <li class="nav-item">
        <a href="https://quantumhunts.com/user/manage/profile/#uploadtab" data-toggle="tab" class="nav-link rounded-0 btn-primary-two text-dark">
        <i class="mdi mdi-home-variant d-md-none d-block"></i>
            <span class="d-none d-md-block">Upload Video</span>
        </a>
    </li>
</ul>
    <div class="tab-content">
    <div class="tab-pane active show" id="recordtab">
    <br>
  <div class="row">
      <div class="col-8 col-xs-8 col-sm-8 form-inline">
  <button id="startButton" class=" btn btn-primary btn-sm mr-1 float-left"><i class="mdi mdi-circle text-danger mr-1 font-11"></i> Record</button>
  <button id="stopButton" class=" btn btn-primary-two text-dark font-weight-bold btn-sm float-left" style="display:none"><i class="mdi mdi-square text-danger mr-1 font-11"></i> Stop</button>

  <span class="input-group input-group-merge">

  <select id="visibletag" class="form-control" style="display:none">
  <option id="me" value="0">Visible to Me</option>
 <option id="recruiter" value="1">Visible to QH Recruiter</option>  
  <option id="public" value="2">Visible to public (Recommended)</option> 
  </select> 
<button id="storeButton" class="btn btn-primary mr-1 float-left" style="display:none"><i class="mdi mdi-check-circle text-light mr-1 font-11"></i>  Upload</button>
    </span>
    
    <p class="font-10 mt-0 mb-0">When sharing profile outside this platform, always select 'Visible to All' option.</p>    
    
    </div>      
  </div>

                                                                       
    <div class="row mt-2">
    <div class="col-12 border" id="previewcontainer">

    
      <video class="video-js video-tech" id="preview" autoplay="" muted="" style="width:100%;height:400px;" preload="true" fluid="true" width="640" height="400"></video>
    
    </div>
    </div>
<div class="row">
    <div class="col-12 mt-3 mb-3" id="recordingwait" style="display:none">
        <div class="row">
        <div class="col-2"></div>
        <div class="align-middle align-center col-8 align-center text-center">
          <p class="mt-2">Please wait for your video to be rendered. It usually takes a while, but we will make it awesome for you.</p>
        </div>
        <div class="col-2"></div>    
        </div>
        <p class="text-center align-middle align-center">
        <img src="./Edit Resume _ QUANTUMHUNTS_files/ab79a231234507.564a1d23814ef.gif" style="height:24px;width:24px;" class="text-center align-middle align-center">
        </p>
    </div>    
    <div class="col-12 mt-3 mb-3" id="recordingcontainer" style="display:none">
      <br>
      <video id="my-video" class="video-js vjs-tech vjs-theme-city vjs-big-play-centered bg-light" style="width:100%;height:400px;" controls="" preload="true" fluid="true" height="400"></video>
    
    <a id="downloadButton" class="button d-none">Download </a>
    
    </div>
</div>
  <div class="bottom">
    <pre id="log"></pre>
    
  </div>
<br> <div class="alert text-primary" id="resume_record_success_msg" style="display:none;"></div>
<div class="alert text-danger" id="resume_record_fail_msg" style="display:none;"></div>                                                                
                                                                                                                                                                                                      
     </div>                                                                   
    <div class="tab-pane" id="uploadtab">
        <div class="row mt-2 mb-3">
    <div class="col-6">
        
        <div id="progressbar"></div>
        <div id="videopreview">
                </div>
        <div id="videoerr"></div>
    </div>
    <div class="col-6">
        
        <div class="upload-btnv-wrapper mt-2 float-left">
  <button class="btnv btn">Upload a file</button>
  <input type="file" name="myfile" id="videofile" value="myvideo">
</div>

  <div class="form-group formforvideo" id="privacydiv">
 
  <strong>Privacy Option</strong> <br><br> 
  
  <input class="" type="radio" id="me" name="visibilitychoice" value="0">
  <label for="me">Only Me</label> <br>
  
  <input class="" type="radio" id="friends" name="visibilitychoice" value="1">
  <label for="friends">QH Recruiters</label><br>
  
  <input class="" type="radio" id="public" name="visibilitychoice" value="2">
  <label for="public">Visible to All (Recommended)</label><br><br> 

<p class="font-10 mt-0 mb-0">When sharing profile outside this platform, always select 'Visible to All' option.</p>


 <button type="button" class="btn btn-primary mr-auto" id="videosave">Save</button>
 <button type="button" class="btn btn-primary mr-auto" id="cancelvideo">Back</button>
  <button type="button" class="btn btn-primary mr-auto" data-dismiss="modal" aria-label="Close" id="quitvideo">Cancel Upload</button>
  </div>


<br><br>

  
  <div class="text-left"><br>
  <p class="text-left">
      
  <a target="_blank" href="https://quantumhunts.com/bytes/quantumhunts/tips-for-creating-a-quantumhunts-video-resume">How to create a video resume</a><br>
  <a href="https://quantumhunts.com/user/manage/profile/" data-toggle="modal" data-target="#help-modal">Report an issue</a>
  </p>
  
  <span class="small mr-2">Size: 60MB</span>  <br>
  <span class="small mr-2">File: .mov, .mp4</span> <br>
 <span class="small mr-2">Duration: Max 120 seconds</span>  <br>
 <span class="small mr-2">Mode: Landscape</span> 
 </div>
<style>
.formforvideo
{
    display:none;
}

</style>






                    <div class="form-group text-left">
                                <div class="display-callback-error  alert alert-danger" style="display: none">
                                </div>

                    </div>
                    
                    

                <div class="form-group">  
                                <div class="display-callback-success  alert alert-info" style="display: none">
                                   
                                </div>
                </div>

        
    </div>    
</div>












<style>
    .upload-btnv-wrapper {
  position: relative;
  overflow: hidden;
  display: inline-block;
}

.btnv {
  //border: 2px solid gray;
  color: white;
  background-image: linear-gradient( 0.2deg, #536de6 4.8%, rgba(51,102,255,1) 85.5% );;
  padding: 6px 20px;
  //border-radius: 8px;
  font-size: 14px;
  font-weight: bold;
}

.upload-btnv-wrapper input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
}

</style>




    
  <!-- include Google hosted jQuery Library -->
<script src="./Edit Resume _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>


<script type="text/javascript">

$("#videofile").change(function(){
    
    $(".formforvideo").show();
    $(".upload-btnv-wrapper").hide();

         //submit the form here
         //alert("Lets start video upload");
 });
 
 
 $("#cancelvideo").click(function()
 {
     $(".formforvideo").hide();
     $(".upload-btnv-wrapper").show();
 });
 
 

    $(window).on('load',function(){
        setTimeout(function() {
    $('#video-modal').modal('show');}, 5000)
//        $('#video-modal').modal('show');
    });
</script>



<script>
    $(document).ready(function (e) {
 $("#videosave").on('click',(function(e) {
  e.preventDefault();

  var visibility_choice=$("input[name=visibilitychoice]:checked", "#vform").val();
  //alert(visibility_choice);
  
var radio=$('input[type="radio"]:checked').val();

            var file = $('#videofile')[0].files[0];
            form = new FormData();
            form.append('media', file);
            form.append('text', radio);

  $.ajax({
   url: "https://quantumhunts.com/user/manage/profile/upload_videos/",
   type: "POST",
   data:  form,
   contentType: false,
         cache: false,
   processData:false,
   //dataType: 'json',
   beforeSend : function()
   {
    //$("#preview").fadeOut();
    $("#privacydiv").fadeOut();
    $("#videopreview").fadeOut();
    $("#progressbar").html("<img src='https://media0.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif?cid=ecf05e47b4154a06962e932aefbf7a670cb428bafb532ce0&rid=giphy.gif' />");
    $("#videoerr").fadeOut();
   
   },
   success: function(vata)
      {
        //alert(vata.code);
        //alert(vata.msg);
    if(vata=='invalid file')
    {
        //alert("1");
     // invalid file format.
     //$("#preview").html(data.msg).fadeIn();
     //$("#preview").html(vata).fadeIn();
     $("#progressbar").fadeOut();
     $("#videoerr").html("Invalid File !").fadeIn();
    }
    else
    {
     //alert("2");
     // view uploaded file.
     $("#privacydiv").fadeOut();
     $("#progressbar").fadeOut();
     $("#videopreview").html(vata).fadeIn();
     $("#vform")[0].reset(); 
    }
      },
     error: function(e) 
      {
          $("#progressbar").fadeOut();
    $("#videoerr").html(e).fadeIn();
      }          
    });
    
    
    
 }));
});
</script>






              </div>
</div>

<script>
    
let recordedChunks=new Blob();

let preview = document.getElementById("preview");
let recording = document.getElementById("my-video");
//let my-video=document.getElementById("recording");
let startButton = document.getElementById("startButton");
let stopButton = document.getElementById("stopButton");
let downloadButton = document.getElementById("downloadButton");
let logElement = document.getElementById("log");

let recordingTimeMS = 120000;
function log(msg) 
{
    //alert("1");
  //logElement.innerHTML += msg + "\n";
}
function wait(delayInMS) 
{
    //alert("2");    
  return new Promise(resolve => setTimeout(resolve, delayInMS));
}
function startRecording(stream, lengthInMS) {

    //alert("3");
  let recorder = new MediaRecorder(stream);
  let data = [];
 
  recorder.ondataavailable = event => data.push(event.data);
  recorder.start();
  
  log(recorder.state + " for " + (lengthInMS/1000) + " seconds...");
 
  let stopped = new Promise((resolve, reject) => {
    recorder.onstop = resolve;
    recorder.onerror = event => reject(event.name);
        //alert("4");
  });

let recorded = wait(lengthInMS).then(
    () => recorder.state == "recording" && recorder.stop() && $("#stopButton").hide()
);
 
  return Promise.all([
    stopped,
    recorded
  ])
  .then(() => data);
    // alert("6");
}
function stop(stream) 
{
        //alert("7");
 stream.getTracks().forEach(track => track.stop());
 $("#stopButton").hide();  
 $("#startButton").show();    
 $("#previewcontainer").hide();     
 $("#recordingwait").show();    
 $("#visibletag").show(); 
  
}

startButton.addEventListener("click", function() 
{
       // alert("8");

 $("#startButton").hide(); 
 $("#stopButton").show();
 $("#previewcontainer").show();     
 $("#recordingcontainer").hide();  
 $("#storeButton").hide();

    
  navigator.mediaDevices.getUserMedia({
    video: true,
    audio: true
  }).then(stream => {
    preview.srcObject = stream;
    downloadButton.href = stream;
    preview.captureStream = preview.captureStream || preview.mozCaptureStream;
    return new Promise(resolve => preview.onplaying = resolve);
  }).then(() => startRecording(preview.captureStream(), recordingTimeMS))
  .then (recordedChunks => {
    let recordedBlob = new Blob(recordedChunks, { type: "video/webm" });
    recording.src = URL.createObjectURL(recordedBlob);
//    my-video.src = URL.createObjectURL(recordedBlob);    
    downloadButton.href = recording.src;
    downloadButton.download = "RecordedVideo.webm";

//alert("8.1");

 $("#previewcontainer").hide();         
 $("#startButton").show(); 
 $("#stopButton").hide();
 $("#storeButton").show();
 $("#recordingwait").hide();     
 $("#recordingcontainer").show(); 
 $("#visibletag").show();
 $('#storeButton').click(function() {
        var visitag = $("#visibletag").val();
        //alert(visitag); 
      sendVideoToAPI(recordedBlob,visitag); 
 });
    //alert("9");    
    log("Successfully recorded " + recordedBlob.size + " bytes of " +
        recordedBlob.type + " media.");
  })
  .catch(log);
}, false);


stopButton.addEventListener("click", function() {
  stop(preview.srcObject);
  $("#visibletag").show();
  $("#storeButton").show();  
}, false);   
 
</script>


<script>
      
        
function sendVideoToAPI (blob, visiparam) {
    //alert("Api");
    
    let fd = new FormData();
    let vfile = new File([blob], 'recording');

    
    fd.append('data', vfile);
    console.log(fd); // test to see if appending form data would work, it didn't this is completely empty. 


    let vform = new FormData();
    let request = new XMLHttpRequest();

    vform.append("file",vfile);
    
   
   
    vform.append("visibilityoption",visiparam);
   
    
        $.ajax({
   contentType: false,
         cache: false,
            type: "POST",
            
            url: "https://quantumhunts.com/user/manage/profile/record/",
            processData: false,            
            data:vform,            
            success : function(data)
            {
                var response = JSON.parse(data);
                $("#storeButton").hide();
                $("#recordingcontainer").hide();
                if(response.code=="1")
                {
                    $("#resume_record_success_msg").css("display","block");    
                    $("#resume_record_success_msg").html(response.msg);  
                }
                else
                {
                  $("#resume_record_fail_msg").css("display","block");    
                  $("#resume_record_fail_msg").html(response.msg);  
                }      
            }
        });
      }    
   



    </script>



                        


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



















                                
                                
                                
                            </div>
                            
                            
                            
                        </div>
                        <!-- end row-->
                        
                    </div> <!-- End Content -->

                  
                </div> <!-- content-page -->

            </div> <!-- end wrapper-->
        </div><span style="position:absolute; top:-999px; left:0; white-space:pre;"></span><ul id="ui-id-1" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" style="display: none; min-width: 585px;"></ul><div role="status" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div>
        <!-- END Container -->


<!-- Signup modal-->

<div id="help-modal" class="modal fade" tabindex="1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="background-image1: radial-gradient( circle farthest-corner at 18.7% 37.8%,  rgba(250,250,250,1) 0%, rgba(225,234,238,1) 90% );">

            <div class="modal-body">
                <div class="text-center mt-2 mb-0">
                    
                    <span class="text-success">
                        <span><img src="./Edit Resume _ QUANTUMHUNTS_files/square1_qh.png" alt="" height="32" width="32"></span>
                    </span>
                </div>
                
                <div class="card-body text-center">

                    <strong class="text-center text-primary blogmini">QUANTUMHUNTS</strong>
                    <span class="d-block text-center mb-2"> Help &amp; Support</span>

                <div class="row auto-mx float-center text-center"> 
                <div class="col-2">
                </div>
                <div class="col-8">
                <p class="text-center mb-2">Use the below form to reach us for any request or enquires. Average response time less than 24 hours.</p>
                </div>
                <div class="col-2">
                </div>
                </div>

                </div>

                <form class="pl-3 pr-3" id="callbackform" action="https://quantumhunts.com/user/manage/profile/#">
                    
                    
                    
<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input class="form-control form-control-sm" type="name" id="name" required="" placeholder="" value="Vishnu varthan">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="company">Company</label>
                        <input class="form-control form-control-sm" type="text" id="companyname" required="" placeholder="">
                    </div>
</div> <!-- end col -->
</div>                    


<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input class="form-control form-control-sm" type="phone" required="" id="phone" value=" ">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">E-Mail</label>
                        <input class="form-control form-control-sm" type="email" required="" id="email" placeholder="" value="Vishnuvarthan12@gmail.com">
                    </div>
</div> <!-- end col -->
</div>                    
                    
                    



<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="reason">Subject</label>
                        <select class="form-control form-control-sm" id="reason">
                        <option value="Mentorship">Career development</option>  
                        <option value="Courses">Courses</option>              
                        <option value="Business">Business Enquiry</option>
                        <option value="QH-RECRUITER">Premium Plans</option>                 
                        <option value="Help">Help</option>                
                        <option value="AccountIssues">My QH account</option>                        
                        <option value="Issues">Issues &amp; Complaints</option>                                                
                        </select>                        
                    </div>                    

</div>
</div>          





<div class="row">
<div class="col-md-12">
                    <div class="form-group">
                        <label for="comments">Comments</label>
                        <textarea class="form-control" id="comments" placeholder=""></textarea>
                    </div>                    
</div> <!-- end col -->
</div>          





                    


    
                    <div class="form-group text-left">
                                <div class="display-callback-error  alert alert-danger" style="display: none">
                                </div>

                        <button class="btn btn-primary" type="submit" id="callbacksubmit">Submit </button>
                        <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                    </div>
                    
                    
                    <small>By clicking "Submit" I agree to be contacted at the number provided with more information or offers about <span class="text-uppercase text-primary">QuantumHunts</span>. I understand these calls or texts may use computer-assisted dialing or pre-recorded messages.</small>

                </form>
                
                <div class="form-group">  
                                <div class="display-callback-success  alert alert-info" style="display: none">
                                   
                                </div>
                </div>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->









  <!-- include Google hosted jQuery Library -->
<script src="./Edit Resume _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#callbacksubmit').click(function(e){
        e.preventDefault();

    var usertype = $('input[name=customRadio1]:checked').val();
        //alert(usertype);

        var pageurl="https://quantumhunts.com/user/manage/profile/";
        var email = $("#email").val();
        var phone = $("#phone").val();        
        var name = $("#name").val();
        var company = $("#companyname").val();
        var reason =$('#reason option:selected').val();
        var comments = $("#comments").val(); 
        //var comments = "";
        
        //alert(email+name+phone+reason+comments+company);
        
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/user/set/callbacks/",
            dataType: "json",
            data: {name:name,email:email,phone:phone,company:company,reason:reason,comments:comments,pageurl:pageurl},            
            success : function(data){
                if (data.code == "200")
                {
                    $(".display-callback-success").show(); 
                    $(".display-callback-error").hide(); 
                    $("#callbackform").hide();
                    $(".display-callback-success").html(""+data.msg+"");
                    $(".display-callback-success").css("display","block");
                } 
                else {
                    //alert("Success: " +data.msg);
                    $(".display-callback-error").html(""+data.msg+"");
                    $(".display-callback-error").css("display","block");
                }
            }
        });


      });
  });
</script>







    <div id="ReferModal" class="modal " tabindex="-1" role="dialog">
      <div class="modal" tabindex="-1" role="dialog" style="padding-right: 16px; display: block;overflow-y: scroll;" aria-modal="true">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
          <div class="modal-content border-5">
            <div class="modal-body" style="overflow-y: auto;"><div class="card-body">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
              <div class="rounded mb-1 pt-0 mt-0">
		<center> <h5 class="d-block  mt-0 mb-3 text-primary text-uppercase  blogmini">📢 Invite Your Friends
                </h5></center>
		<ul class="nav nav-tabs tab-grad mt-3">
						
						<li class="nav-item "> <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" data-toggle="tab" href="https://quantumhunts.com/user/manage/profile/#profile1">Invite via Mail  </a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="https://quantumhunts.com/user/manage/profile/#home1"> Share via link</a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="https://quantumhunts.com/user/manage/profile/#referrals"> My Rewards</a> </li>						
					</ul>
	

<div class="tab-content">
    <div class="tab-pane show active" id="profile1">
	<br>
        <p>You can now invite your friends through mail so that they join world's 1st video centric job platform. You would get rewarded when your friends create their account with us.</p>
                <div class="media-body">
                  <!--<strong class="d-block  mt-2 text-primary text-uppercase purpletitle">Invite via Mail
                  </strong> -->
                 
                <div class="row">
                  
                  <div class="col-lg-12 col-12">
                      
                      <div class="row">
                      <div class="col-6">
                      
                    <span class="media-body mt-2">
                      <div class="form-group">
                        <label for="inputName">Name
                        </label>
                        <input type="text" class="form-control form-control-sm" id="inputName" required="" placeholder="Enter your Friend&#39;s name..">
                      </div> 
                      <div id="div1">
                      </div> 
                      <div class="alert alert-primary" id="invitenamemsg" style="display:none;">Please Enter Your Friend's Name
                      </div>
                      <div class="form-group">
                        <label for="inputEmail">Email
                        </label>
                        <input type="email" class="form-control form-control-sm" id="inputEmail" required="" placeholder="Enter your Friend&#39;s mail..">
                      </div> 
                      <div id="div2">
                      </div> 
                      <div class="alert alert-primary" id="inviteemailmsg" style="display:none;">Please Enter Your Email Id
                      </div>
                      <div class="alert alert-primary" id="invitevalidemailmsg" style="display:none;">Please Enter a Valid Email Id
                      </div>
                      <button class="btn btn-primary btn-sm" id="submit">Submit 
                      </button>
                    </span>
                    
                    </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="alert text-primary" id="invitesuccessmsg" style="display:none;">Success. Your friend will receive an email very soon.</div>
                			<div class="alert text-danger " id="invitefailuremsg" style="display:none;">Please try again. </div><p></p><br>
                            <div class="alert text-danger " id="inviteloginmsg" style="display:none;">Please login To invite your friends.
                      </div>
                        </div>
                    </div>                
                    
                    
                </div>
<div class="col-3 col-lg-4">
                  </div>
                <div class="col-3">
                </div>
                <div class="col-12">
                </div>
                </div>
            </div>
    </div>
     <div class="tab-pane" id="home1"><br>
        <p>Share this link with your friends so that they join World's 1st video resume platform. You would get rewarded when your friends create their video resume with us.</p>
	                <div class="row mt-3 mx-0">

                  <div class="col-12 col-md-5  my-auto mx-auto">
                        <div class="input-group input-group-merge">
                      <input class="form-control" type="text" value="https://quantumhunts.com/?ref=vishnu-varthan-20210725124136" id="copybox">
                    <div class="input-group-append">
                      <button class="btn btn-primary-two btn-sm font-weight-bold text-dark" onclick="copyfunction()">Copy my link
                      </button>
                        </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-2 text-center my-auto mx-auto">
                    <p style="text-center font-size:20;">or
                    </p>
                  </div>
                  <div class="col-12 col-md-5  my-auto mx-auto">
                    <ul class="share-buttons">
                      
                      
                      <a class="mr-1" href="https://www.facebook.com/sharer/sharer.php?u=https://quantumhunts.com/?ref=vishnu-varthan-20210725124136;" title="Share on Facebook" target="_blank" onclick="window.open(&#39;https://www.facebook.com/sharer/sharer.php?u=&#39; + https://quantumhunts.com/signup/?ref=vishnu-varthan-20210725124136  Create a Professional Login+ &#39;&amp;quote=Apply for this opportunity&#39; ); return false;">
                        <img alt="Share on Facebook" src="./Edit Resume _ QUANTUMHUNTS_files/facebook.png">
                      </a>            
                      
                      
                      <a class="mr-1" href="https://twitter.com/intent/tweet?text=https://quantumhunts.com/?ref=vishnu-varthan-20210725124136%20Create%20a%20Professional%20Login" title="Click to share this post on Twitter" "="" target="_blank" onclick="window.open(&#39;https://twitter.com/intent/tweet?text=&#39; + https://quantumhunts.com/job/vishnu-varthan-20210725124136 + &#39;:%20&#39;  + Apply for this opportunity); return false;">
                      <img alt="Tweet" src="./Edit Resume _ QUANTUMHUNTS_files/twitter.png">
                      </a>

                    <a class="mr-1" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://quantumhunts.com/?ref=vishnu-varthan-20210725124136;title=&amp;summary=&amp;source=" target="_blank" title="Share on LinkedIn">
			<img alt="Share on LinkedIn" src="./Edit Resume _ QUANTUMHUNTS_files/linkedin.png">
                      </a> 
                    </ul>
                </div>
              </div>
    
 	<div class="mt-1 mb-1">
              <br>  <br>
              </div>
              
              <div class="row mt-2 mx-0">

                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row ">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-link text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 1 
                        </h5>    
                        <p class="text-secondary font-13 mb-0 mt-0 pb-0 pt-0 px-0">Share Link with your friends   
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
              
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-user-group text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 2
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">Ask your friends to create video resume  
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mt-n3 ">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-trophy text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 3 
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">We will reward your account 
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div></div>
              
              
    <div class="tab-pane" id="referrals">
        <p class="mt-3">Here is the stats of the valid users who have signed up based on your referral. Better your own numbers by speaking about our platform to your friends and acquaintance. share your referral link today.</p>
        <div class="row">
        <div class="col-4 col-xs-12 col-sm-12 col-md-4">



<div class="card tilebox-one shadow">
                                    <div class="card-body">
                                        <i class="uil uil-users-alt float-right"></i>
                                        <h6 class="text-uppercase mt-0 blogmini text-primary">Verified Users</h6>
                                        <h2 class="my-2" id="active-users-count">0</h2>
                                        <p class="mb-0 text-muted">
                                            <span class="text-nowrap">Since signup</span>  
                                        </p>
                                    </div> <!-- end card-body-->
                                </div>



        </div>
        </div>

    </div>
              
</div>



</div>
    </div>
        </div>
      </div>
    </div>
    </div>
  <br>
  <br>
  <br>
  <br>
  <br>
  </div>
<script src="./Edit Resume _ QUANTUMHUNTS_files/jquery.min.js(1).download">
</script>
<script>
  function copyfunction() {
    var copyText = document.getElementById("copybox");
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
  }
  $(document).ready(function(){
    $('#submit').click(function(){
      var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
      var name = $('#inputName').val();
      var email = $('#inputEmail').val();
      if(name.trim()=='')
      {
        //document.getElementById("div1").innerHTML="Enter a value";
        //document.getElementById("div1").style.color="Red";
        $('#inputName').focus();
      }
      else if(email.trim() == '' ){
        //document.getElementById("div2").innerHTML="Enter the correct email address";
        //document.getElementById("div2").style.color="Red";
        $('#inputEmail').focus();
      }
      else if(email.trim() != '' && !reg.test(email)){
        //$("#invitevalidemailmsg").css("display","block");
        $('#inputEmail').focus();
      }
      else{
        
        $.ajax({
          type:"POST",
          url:"https://quantumhunts.com/invite/send/",
          dataType: "json",
          data:{
            name:name,email:email},
          success:function(data){
            if(data.status == 'ok'){
               $("#invitesuccessmsg").css("display","block");
		$("#inviteloginmsg").hide();
		$("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitesuccessmsg").hide();
              }, 4000);              
            }
            else{ if(data.status=='error'){
             $("#inviteloginmsg").css("display","block");
	     $("#invitesuccessmsg").hide();
	     $("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitevalidemailmsg").hide();
              }, 4000);                            
              }
		else{
              $("#invitefailuremsg").css("display","block");
		$("#invitesuccessmsg").hide();
	     $("#inviteloginmsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitefailuremsg").hide();
              }, 4000);                            
            }
	 }
          }
        }
              );
      }
    }
                      );
  }
                   );
</script>







<!--
<script>

$(function() { 

    $("#video-record-popover").popover('show');

    $("#video-record-popover").on('click', function () {
        
        $('#video-record-popover').popover('destroy');
        $("#resume-record").show();
    });
 }); 

</script>
-->

        <!-- bundle -->
        <script src="./Edit Resume _ QUANTUMHUNTS_files/vendor.min.js.download"></script> 
        <script src="./Edit Resume _ QUANTUMHUNTS_files/app.min.js.download"></script>

        <!-- third party js -->
        <script src="./Edit Resume _ QUANTUMHUNTS_files/apexcharts.min.js.download"></script>
        <script src="./Edit Resume _ QUANTUMHUNTS_files/jquery-jvectormap-1.2.2.min.js.download"></script>
        <script src="./Edit Resume _ QUANTUMHUNTS_files/jquery-jvectormap-world-mill-en.js.download"></script>
        <!-- third party js ends -->
        
        


        <!-- demo app -->
        <script src="./Edit Resume _ QUANTUMHUNTS_files/demo.dashboard.js.download"></script>
        <!-- end demo js-->
        
        <!-- plugin js -->
        <script src="./Edit Resume _ QUANTUMHUNTS_files/summernote-bs4.min.js.download"></script>
        <!-- Summernote demo -->
        <script src="./Edit Resume _ QUANTUMHUNTS_files/demo.summernote.js.download"></script>
        
        <!-- SimpleMDE demo -->
        <script src="./Edit Resume _ QUANTUMHUNTS_files/demo.simplemde.js.download"></script>
        
        
        <!--    
        <script src="https://coderthemes.com/hyper/modern/assets/js/vendor/dragula.min.js"></script>
        <script src="https://coderthemes.com/hyper/modern/assets/js/ui/component.dragula.js"></script>
        -->
        
        <script src="./Edit Resume _ QUANTUMHUNTS_files/bootstrap3-typeahead.js.download"></script>
        
        <script src="./Edit Resume _ QUANTUMHUNTS_files/jquery.star-rating-svg.js.download"></script>
<style>
    .jq-stars {
  display: inline-block;
}

.jq-rating-label {
  font-size: 22px;
  display: inline-block;
  position: relative;
  vertical-align: top;
  font-family: helvetica, arial, verdana;
}

.jq-star {
  width: 100px;
  height: 100px;
  display: inline-block;
  cursor: pointer;
}

.jq-star-svg {
  padding-left: 3px;
  width: 100%;
  height: 100% ;
}

.jq-star:hover .fs-star-svg path {
}

.jq-star-svg path {
  /* stroke: #000; */
  stroke-linejoin: round;
}

/* un-used */
.jq-shadow {
  -webkit-filter: drop-shadow( -2px -2px 2px #888 );
  filter: drop-shadow( -2px -2px 2px #888 );
}
</style>
 
         <script src="./Edit Resume _ QUANTUMHUNTS_files/jquery.rateit.min.js.download"></script>
         <!--<script src="https://quantumhunts.com/user/assets/js/ui/component.rating.js"></script>-->
 

<!--
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
	<script src="./Edit Resume _ QUANTUMHUNTS_files/jquery.backstretch.js.download" type="text/javascript"></script>
	<script type="text/javascript">
	//var jq = $.noConflict();
	$(document).ready(function()
	{
        //$(".learning").backstretch("https://www.groove.co/images/backgrounds/yellowHeader.svg");  
        //$(".learning").backstretch("https://agenda.com/img/about-header-background.jpg");  
        //$(".learning").backstretch("https://www.groove.co/images/backgrounds/orangeHeader.svg");
        $(".learning").backstretch("https://quantumhunts.com/user/assets/images/header/yellow.png");
        $(".bytes").backstretch("https://www.cloud3dprint.com/assets/images/svg/components/bg-elements-3.svg");          
        $(".blogtitles").backstretch("https://quantumhunts.com/user/assets/images/header/outline.png");                  
        $(".corporate").backstretch("https://quantumhunts.com/user/assets/images/header/bluelight.png");   
        $(".passion").backstretch("https://quantumhunts.com/user/assets/images/header/red.png");           
        $(".secondary").backstretch("https://quantumhunts.com/user/assets/images/header/gray.png");
        $(".neon").backstretch("https://quantumhunts.com/user/assets/images/header/neon.png");
        $(".night").backstretch("https://quantumhunts.com/user/assets/images/header/night.png");
        $(".deepnight").backstretch("https://quantumhunts.com/user/assets/images/header/black2.png");
        //$(".jobpostheader").backstretch("https://static.dashthis.com/media/1200/integrations_bg_header.png");
        //$(".jobpostheader").backstretch("https://wizixo.webestica.com/assets/images/bg/pattern/01.png");
        //$(".jobpostheader").backstretch("https://puntlandtvradio.net/images/background/header-middle-bg.png"); gray
        $(".jobpostheader").backstretch("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwuItFn-ng3DNuaysanpZWUIPSuumuFLpHkQ&usqp=CAU");
        //$(".eventheader").backstretch("https://quantumhunts.com/user/assets/images/events/event-web-header.jpg");
        //$(".eventheader").backstretch("https://t4.ftcdn.net/jpg/02/87/00/91/240_F_287009195_dqypC87ah7wxueU1mbIOO5FqSwUqaYH4.jpg"); 
        $(".eventheader").backstretch("http://quantumhunts.com/user/assets/images/events/bg-grid.svg");
        //$(".eventheader").backstretch("https://png.pngtree.com/thumb_back/fw800/back_pic/02/67/67/36578edee23114e.jpg");        
        //$(".jobpostheader").backstretch("https://github.githubassets.com/images/modules/site/patterns/contribution-graph.svg");
        //$(".jobpostheader").backstretch("https://goodkit.goodthemes.co/assets/img/patterns/pattern-1.svg");  
        $(".resume").backstretch("https://static.dashthis.com/media/1200/integrations_bg_header.png");
        $(".plusbg").backstretch("https://quantumhunts.com/user/assets/images/hero/bg_plus.gif");
        $(".coursebg").backstretch("https://www.iot-scotland.net/wp-content/uploads/2019/02/bg-hero-services.jpg");
        //$(".courseenrollbg").backstretch("https://subvrsive.com/wp-content/uploads/2019/12/immersive-workshops_header.jpg");
        $(".courseenrollbg").backstretch("https://i.pinimg.com/originals/7e/b0/50/7eb05083a0b5363fef557d0e30975507.jpg");
        $(".courseenrollbg").backstretch("https://quantumhunts.com/user/assets/images/header/mild-white-wave.jpg");
        $(".courseappliedbg").backstretch("https://www.fuseplm.com/wp-content/uploads/2018/07/client-testimonials-background-darker.jpg");    
        $(".mandate").backstretch("https://quantumhunts.com/user/assets/images/header/mild-white-wave.jpg");
        $(".split").backstretch("https://www.scoutlogicscreening.com/hubfs/offer-background.svg");
        $(".certify").backstretch("https://hojanueva.org/wp-content/plugins/ishyoboy-freelo-assets/ishyoboy-shortcodes/assets/frontend/images/svgs/row-svg-triangles.svg");        
	});
  </script>

       <!-- 
        <script src="https://coderthemes.com/hyper/modern/assets/js/vendor/dropzone.min.js"></script>
       
        <script src="https://coderthemes.com/hyper/modern/assets/js/ui/component.fileupload.js"></script>
        
-->





<!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
<script src="./Edit Resume _ QUANTUMHUNTS_files/videojs-ie8.min.js.download"></script>

<script src="./Edit Resume _ QUANTUMHUNTS_files/video.js.download"></script>


<script src="./Edit Resume _ QUANTUMHUNTS_files/custom.js.download"></script>


<script src="./Edit Resume _ QUANTUMHUNTS_files/wow.min.js.download"></script>
<script>
new WOW().init();
</script>




<!-- SimpleMDE js 
<script src="https://coderthemes.com/hyper/modern/assets/js/vendor/simplemde.min.js"></script>
<script src="https://coderthemes.com/hyper/modern/assets/js/pages/demo.simplemde.js"></script>      
 SimpleMDE demo -->


<!-- SimpleMDE js -->
<script src="./Edit Resume _ QUANTUMHUNTS_files/simplemde.min.js.download"></script>
<!-- SimpleMDE demo -->
<script src="./Edit Resume _ QUANTUMHUNTS_files/demo.simplemde.js(1).download"></script>      



<script>
var simplemde_jd = new SimpleMDE({ element: document.getElementById("jd") });
//simplemde_jd.togglePreview();
</script> 

<script>
var simplemde_jq = new SimpleMDE({ element: document.getElementById("jq") });
</script>

<script>
var simplemde_companyabout = new SimpleMDE({ element: document.getElementById("companydesc") });
</script>


<script>
var simplemde_post = new SimpleMDE({ element: document.getElementById("postcontent") });
//simplemde_post.togglePreview();
</script>

<!--
 
 <script>
var simplemde1 = new SimpleMDE({ element: $("#jd")[0] });
</script>

<script>
var simplemde2 = new SimpleMDE({ element: $("#jq")[0] });
</script>
-->


<!--
<script src="https://www.jqueryscript.net/demo/Simple-Flexible-jQuery-Alert-Notification-Plugin-notify-js/js/notify.js"></script>
-->
<script src="./Edit Resume _ QUANTUMHUNTS_files/notify.js.download"></script>

<!-- <script src="https://quantumhunts.com/user/assets/js/custom/notyf.min.js1"></script> 
 <script src="https://quantumhunts.com/user/assets/js/custom/notify.js"></script> -->
  
 <script src="./Edit Resume _ QUANTUMHUNTS_files/typed.min.js.download">
      
</script>

<script id="rendered-js">

$(function () {
    
  $(".superlative").typed({
    strings: ["are QuantumHunts","Help Jobseekers","Train Professionals","are Trusted HR Partners"],
    // Optionally use an HTML element to grab strings from (must wrap each string in a <p>)
    stringsElement: null,
    // typing speed
    typeSpeed: 10,
    // time before typing starts
    startDelay: 300,
    // backspacing speed
    backSpeed: 20,
    // time before backspacing
    backDelay: 300,
    // loop
    loop: true,
    // false = infinite
    //loopCount: 5,
    // show cursor
    showCursor: true,
    // character for cursor
    cursorChar: "|",
    // attribute to type (null == text)
    attr: null,
    // either html or text
    contentType: 'html',
    // call when done callback function
    callback: function () {},
    // starting callback function before each string
    preStringTyped: function () {},
    //callback for every typed string
    onStringTyped: function () {},
    // callback for reset
    resetCallback: function () {} });
    
    
    

});

</script>



<!-- Analytics -->
<script async="" src="./Edit Resume _ QUANTUMHUNTS_files/js"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-908Z83GP55');
</script>
  







<?php
      include($root."/jobs/footer.php");

        ?>