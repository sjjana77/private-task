<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$conn = new mysqli($db_servername, $db_username, $db_password, $db_dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$c_id=$_SESSION['candidate_id'];
$code=200;

echo json_encode(['code'=>200]);
exit;
?>
