<?php
session_start();
$flow="1";
$code=200;
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$q_id=$_SESSION['question_id'];
$question=$_POST['question'];
$time=$_POST['time'];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
$sql="UPDATE vj_questions set question_question='$question',question_time='$time' where question_id='$q_id'";
if ($conn->query($sql)==TRUE){
    echo json_encode(['code'=>400, 'msg'=>'success']);
    $conn->close(); 
    exit;
}  
else{
    echo json_encode(['code'=>200, 'msg'=>'f']);
    $conn->close(); 
    exit;
}
?>