<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';

$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
$q_id=$_SESSION["question_id"];
$sql = "SELECT * FROM vj_questions where question_id='$q_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
    $question=$row['question_question'];
    $time=$row['question_time'];
}
}
?>
<!DOCTYPE html>
<!-- saved from url=(0090)https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta property="og:url" content="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455">
<meta property="og:type" content="website">
<meta property="og:title" content="Talent Development Manager at HCL, Bangalore, India ">
<meta property="og:description" content="HCL Software is a division of HCL Technologies (HCL) that operates its primary software business. It develops, markets, sells, and supports over 20 product fami">
<meta property="og:image" content="https://quantumhunts.com/user/assets/images/header/job_openning_300px.png">
<meta property="fb:app_id" content="525323715034631"> 


        <title>VJA | Edit Question </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="* Understand and appreciate software product engineering, technologies &amp; methodologies at a conceptu " name="description">
        <meta content="QUANTUMHUNTS" name="author">
<?php
  include($root."/header_employer.php");
?>
        <!-- Start Content-->
       
       
       
       
        <div class="container-fluid">

            <!-- Begin page -->
            <div class="wrapper">

                <!-- ========== Left Sidebar Start ========== -->
<div class=""></div>

                <!-- Left Sidebar End -->
                       
                
                
                
 <div class="content-page">
                    <div class="content">

                        <div class="row">
                            

                           



                        


<div class="col-xl-12 col-lg-12">
    
    
         



        <div class="row">  
        

<div class="col-lg-8">
<div class="row">
<div class="col-12">


<br><br><br>
        <div class="card border shadow1 card-body">
        <h5 class="mb-0 font-weight-bold mb-1 text-left text-uppercase text-primary blogmini">Edit Question</h5>

            <div class="form-group">
              <label for="title">Question
              </label>
              <input type="text" id="question" class="form-control form-control-sm" value="<?php echo $question; ?>">
            </div>
<div class="row">
        <div class="col-6">
            <div class="form-group">
              <label for="title">Time (In mintutes)
              </label>
              <input type="number" id="time" class="form-control form-control-sm" value="<?php echo $time; ?>">
            </div>
            </div>
<div class="col-6"></div></div>

<div class="row">
        <div class="col-6">
<button type="button" id="submit" class="btn btn-primary font-weight-bold">Update
    </button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <button type="button" onclick="back()" class="btn btn-primary font-weight-bold">Back
    </button>
    </div>
<div class="col-6"></div></div>

        </div></div></div></div></div></div></div></div>
        </div></div></div>

<?php
  include($root."/jobs/footer.php");
?>

<script type="text/javascript">
            $(document).ready(function() {  
                $('#submit').click(function(){
                          var question=$("#question").val();   
                          var time=$("#time").val();  
                          $.ajax({
                type: "POST",
                url: "http://localhost/edit-questions/edit-questions.php",
                dataType: "json", 
                data:{question:question,time:time},
                success : function(data){
                    //alert(data.code);
                    if (data.code == "400")
                    {
                        back();
                    }
                }

            });
                });
            });
                </script>