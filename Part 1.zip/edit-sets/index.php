<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';

$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
$s_id=$_SESSION["set_id"];
$sql = "SELECT * FROM vj_question_set where set_id='$s_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
    $setname=$row['set_name'];
    $subname=$row['set_sub_name'];
    $complexity=$row['set_complexity'];
    $audible=$row['set_audible'];
}
}


?>
<!DOCTYPE html>
<!-- saved from url=(0090)https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta property="og:url" content="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455">
<meta property="og:type" content="website">
<meta property="og:title" content="Talent Development Manager at HCL, Bangalore, India ">
<meta property="og:description" content="HCL Software is a division of HCL Technologies (HCL) that operates its primary software business. It develops, markets, sells, and supports over 20 product fami">
<meta property="og:image" content="https://quantumhunts.com/user/assets/images/header/job_openning_300px.png">
<meta property="fb:app_id" content="525323715034631"> 


        <title>VJA | Edit Set </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="* Understand and appreciate software product engineering, technologies &amp; methodologies at a conceptu " name="description">
        <meta content="QUANTUMHUNTS" name="author">
<?php
  include($root."/header_employer.php");
?>
        <!-- Start Content-->
       
       
       
       
        <div class="container-fluid">

            <!-- Begin page -->
            <div class="wrapper">

                <!-- ========== Left Sidebar Start ========== -->
<div class=""></div>

                <!-- Left Sidebar End -->
                       
                
                
                
 <div class="content-page">
                    <div class="content">

                        <div class="row">
                            

                           



                        


<div class="col-xl-12 col-lg-12">
    
    
         



        <div class="row">  
        

<div class="col-lg-8">
<div class="row">
<div class="col-12">


<br><br><br>
        <div class="card border shadow1 card-body">
        <h5 class="mb-0 font-weight-bold mb-1 text-left text-uppercase text-primary blogmini">Edit Question Set</h5>
<div class="row">
        <div class="col-6">
            <div class="form-group">
              <label for="title">Set Name
              </label>
              <input type="text" id="setname" class="form-control form-control-sm" value="<?php echo $setname; ?>">
            </div>
            </div>
<div class="col-6"></div></div>

<div class="row">
        <div class="col-6">
            <div class="form-group">
              <label for="title">Sub Name
              </label>
              <input type="text" id="subname" class="form-control form-control-sm" value="<?php echo $subname; ?>">
            </div>
            </div>
<div class="col-6"></div></div>
<div class="row">
        <div class="col-6">
            <div class="form-group">
              <label for="title">Audible
              </label>
              <select class="form-control form-control-sm" id="audible">
              <?php if($audible=="yes"){ ?>
              <option value="yes">
              Yes          </option>
            <option value="no">
            No          </option>
            <?php } else{ ?>
                <option value="no">
            No          </option>
            <option value="yes">
              Yes          </option>
              <?php } ?>
</select>
            </div>
            </div>
<div class="col-6"></div></div>
<div class="row">
        <div class="col-6">
            <div class="form-group">
              <label for="title">Set Name
              </label>
              <select class="form-control form-control-sm" id="complexity">
              <?php if($complexity=="Easy"){ ?>
                <option value="Easy">
              Easy          </option>
            <option value="Intermediate">
            Intermediate          </option>
            <option value="Advance">
            Advance          </option>
                <?php  } else if($complexity=="Intermediate") { ?>
                    <option value="Intermediate">
            Intermediate          </option>
            <option value="Advance">
            Advance          </option>
            <option value="Easy">
              Easy          </option>
              <?php } else{  ?>
                <option value="Advance">
            Advance          </option>
            <option value="Easy">
              Easy          </option>
              <option value="Advance">
            Advance          </option>
                <?php } ?>

</select>
            </div>
            </div>
<div class="col-6"></div></div>
<div class="row">
        <div class="col-6">
<button type="button" id="submit" class="btn btn-primary font-weight-bold">Update
    </button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <button type="button" onclick="back()" class="btn btn-primary font-weight-bold">Back
    </button>
    </div>
<div class="col-6"></div></div>

        </div></div></div></div></div></div></div></div>
        </div></div></div>

<?php
  include($root."/jobs/footer.php");
?>
<script type="text/javascript">
            $(document).ready(function() {  
                $('#submit').click(function(){
                          var setname=$("#setname").val();   
                          var subname=$("#subname").val();  
                          var complexity=$("#complexity").val();
                          var audible=$("#audible").val();
                          $.ajax({
                type: "POST",
                url: "http://localhost/edit-sets/edit-sets.php",
                dataType: "json", 
                data:{setname:setname,subname:subname,complexity:complexity,audible:audible},
                success : function(data){
                    //alert(data.code);
                    if (data.code == "400")
                    {
                        back();
                    }
                }

            });
                });
            });
                </script>