<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$idd=$_SESSION['recruiter_id'];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
$sql="SELECT * from vj_jobs where job_added_by='$idd'";
$job_id=[];
$job_title=[];
$job_location=[];
$job_position=[];
$job_applied=[];
$tt=date("d-M-y");
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    array_push($job_id,$row['job_id']);
    array_push($job_title,$row['job_title']);
    array_push($job_location,$row['job_location']);
    array_push($job_position,$row['job_position']);
    array_push($job_applied,$row['job_applied']);
    }
  }
  $conn->close();   
?>
<!DOCTYPE html>
<!-- saved from url=(0039)http://localhost/employer/jobs/ -->
<html lang="en" class="mm-active"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Employer Dashboard | VJA</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Search &amp; Apply for Jobs with VJX, India&#39;s No 1 job agency for startups &amp; corporates" name="description">
        <meta content="VJX" name="author">
<?php
  include($root."/header_employer.php");
?>
        
        
        

<!--
<p>&nbsp;</p>        
    -->    
        
        


        <!-- Start Content-->
        <div class="container-fluid mm-active">

            <!-- Begin page -->
            <div class="wrapper mm-show">

                <!-- ========== Left Sidebar Start ========== -->

                               
                                
<div class="left-side-menu left-side-menu-detached mm-active shadow1" style="background-color:transparent;background1:#fafbfe;margin-top:0px;">
    
    <div class="leftbar-user1 border1 active">


	

                        <a href="javascript: void(0);">
                            <!--<img src="assets/images/users/avatar-1.jpg" alt="user-image" height="42" class="rounded-circle shadow-sm">-->
                            <span class="leftbar-user-name"></span>
                        </a>




                    </div>

<!-- <div class="card-header bg-primary text-light">    QuantumHunts   </div>    -->
    
                    <ul class="metismenu side-nav mm-show">

                        <!--<li class="side-nav-title side-nav-item text-info">Navigation</li>-->

<!--
                        <li class="side-nav-item">
                            <a href="http://localhost/jobs/home/" class="side-nav-link">
                                <i class="uil-home-alt text-dark"></i>
                                <span> Home </span>
                            </a>
                        </li>
-->                        


    	    
    
                    <!--- Sidemenu -->


            
                                            <!--

                            <li class="side-nav-item">
                            <a href="http://localhost/user/post/company/" class="side-nav-link  mb-0 pb-0">
                                <i class="uil uil-bag-alt"></i> 
                                <span> Create a Company </span> 
                            </a>
                        </li>
                        -->

                                  
                
                
                      <li class="side-nav-item mb-0 pb-0 mm-active">
                            <a href="http://localhost/employer/jobs/" class="side-nav-link mb-0 pb-0 active">
                                <img src="./Employer Dashboard _ QUANTUMHUNTS_files/2206371.svg" height="18" class="mr-2 sidebaricon"> 
                                <span class="font-14">Employer Home</span>
                            </a>
                        </li>
                    
                
                            <li class="side-nav-item mb-0 pb-0">
                            <a href="http://localhost/post-job/" class="side-nav-link  mb-0 pb-0">
                                <img src="./Employer Dashboard _ QUANTUMHUNTS_files/2921779.svg" height="18" class="mr-2 sidebaricon"> 
                                <span class="font-14"> Post a Job </span>
                            </a>
                        </li>
                        

                        <li class="side-nav-item">
                            <a href="http://localhost/directory/" class="side-nav-link  mb-0 pb-0">
                                <img src="./Employer Dashboard _ QUANTUMHUNTS_files/1062311.svg" height="18" class="mr-2 sidebaricon">
                                <span class="font-14"> Directory</span>
                            </a>
                        </li>                        
                        
                        
                        <hr>                        
                                  

                       
                        
    	 
    	    
    

<p>&nbsp;</p>

                            
                        

                       

        
                    </ul>

                    <!-- Help Box 
                    <div class="help-box text-center">
                        <a href="javascript: void(0);" class="float-right close-btn text-body">
                            <i class="mdi mdi-close"></i>
                        </a>
                        <img src="https://coderthemes.com/hyper/modern/assets/images/help-icon.svg" height="90" alt="Helper Icon Image">
                        <h5 class="mt-3">Unlimited Access</h5>
                        <p class="mb-3">Upgrade to plan to get access to unlimited reports</p>
                        <a href="javascript: void(0);" class="btn btn-outline-primary btn-sm">Upgrade</a>
                    </div>
                    end Help Box -->
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>
                    <!-- Sidebar -left -->

                </div>
                <!-- Left Sidebar End -->












<div class="content-page text-dark">
<div class="content">

<div class="row">   
                
                
                
                
<div class="col-xl-12 col-lg-12">
    

<div class="row">
                                                    <div class="col-lg-8">






<div class="row">
                            <div class="col-12">







                                <span id="jdb"></span>
                                <div class="card shadow1 border">
                                    <div class="card-body">
                                        <div class="dropdown float-right">
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <!-- item-->
                                                <a href="http://localhost/post-job/" class="dropdown-item">Post a Job</a>
                                                <!-- item-->
                                                <a href="javascript:void(0);" class="dropdown-item">Monthly Report</a>
                                                <!-- item-->
                                                <a href="javascript:void(0);" class="dropdown-item">Action</a>
                                                <!-- item-->
                                                <a href="javascript:void(0);" class="dropdown-item">Settings</a>
                                            </div>
                                        </div>
                                        <h5 class="mb-2 font-weight-bold mb-0 text-left text-uppercase text-dark" style="letter-spacing:1.2px;">JOBS DASHBOARD</h5>                                        

                                       
                                        <!--<p><b>107</b> posted so far</p> -->



  <div class="" style="background-color1: #eaedfd  !important;">
      <p class="text-dark mb-0 ml-2 pt-2 font-weight-bold">Search for jobs that you manage</p>
<form1 class="mb-2" autocomplete="none-off">
    <div class="form-row align-items-center app-search1 pt-0 pb-2 pl-2">
        <div class="col-5 col-md-3 mt-1">
                        <div class="input-group">
                            <input type="text" id="skills" class="typeahead form-control-sm form-control" placeholder="Search jobs by roles skills" onkeydown="searchFilter()" autocomplete="none-off">
                            
                        
                        </div>
        </div>        
        <div class="col-5 col-md-2 mt-1">
                        <div class="input-group">
<select class="form-control form-control-sm" id="reviewstatus">
    <option value="All" selected="">All Jobs
    </option>
    <option value="Approved">Approved
    </option>
    <option value="Review">Under Review
    </option>
    <option value="Reject">Rejected 
    </option>
  </select>     
                            
                        </div>
        </div>
        <div class="col-5 col-md-3 mt-1">
                        <div class="input-group">
                            <input type="text" id="location" class="typeahead form-control-sm form-control" placeholder="Location" autocomplete="none-off">
                            
                        </div>
        </div>        
        <div class="col-5 col-md-2 mt-1">
                        <div class="input-group">
            <select class="form-control form-control-sm" id="sort">
            <option value="">Sort by</option>                
            <option value="new">Newest</option>
            <option value="old">Oldest</option>
            </select>
                        </div>
        </div>        
        <div class="col-1 col-md-2 mt-1">
                            <div class="input-group-append">
                                <button class="btn btn-primary font-weight-bold btn-sm" type="submit" onclick="searchFilter();">Go</button>
                            </div>
            
        </div>            
    </div>
    
</form1>
    
</div>          


<br>



<div id="posts_content">
                                                    
        
    
    
    <!--    -->
    
    


<div class="col-12 border-bottom">        
<div class="row mb-1 mt-1">
    <div class="col-xs-5 col-sm-5 col-md-5 overflow-hidden employereachjob" style="overflow:hidden; text-overflow:ellipsis;">
      <!--<i class="mdi mdi-circle text-info mr-md-2 font-11"></i>--> <strong><span class="font-12 mt-0 text-uppercase text-primary blogmini">Job Title</span></strong>
    </div>
    <div class="d-none d-md-block col-3  overflow-hidden">
        <span class="font-12  mt-0 employereachjob text-uppercase text-primary blogmini"><strong> Location</strong> </span>        
    </div>    

    <div class="d-none d-md-block col-1">
            <span class="font-12 text-uppercase text-primary blogmini"><strong>#</strong></span>
    </div>
    
    <div class="d-none d-md-block col-2">
            <span class="font-12 text-uppercase text-primary blogmini"><strong>Applied</strong> </span>
    </div>
    
       
</div>
</div>


<script>

  function view_job(a){
    var aa=a;
    $.ajax({
type:"POST",
url:"http://localhost/login/session.php",
dataType:"json",
data:{a:aa},
success:function(data){
if(data.code=='200'){
  window.location.href = "http://localhost/view-job/";
//alert(data.msg);
}

}
});
   
  }
</script>


  <?php  for($x=0;$x<count($job_id);$x++) { ?>       
<div id="<?php echo $job_id[$x]; ?>" class="col-12 border-bottom view_job">  

<div class="row mb-1 mt-1">
    
    <div class="col-xs-5 col-sm-5 col-md-5 overflow-hidden employereachjob" style="overflow:hidden; text-overflow:ellipsis;white-space: nowrap;">
      <i class="btn btn-xs btn-primary-two border-light mdi mdi-checkbox-blank-circle font-8 mr-1 mr-md-3" style="color:#FFFAFA;" ;=""></i>      <!--<i class="mdi mdi-circle text-info mr-md-2 font-11"></i>--> 
      <strong1>
          <span class="mt-0 text-dark" style="overflow:hidden1; text-overflow:ellipsis1;">
          <a class="text-dark employereachjob" style="overflow:hidden1; text-overflow:ellipsis1;"><button class="btn btn-primary-two btn-xs btn-rounded text-dark"><?php echo $job_title[$x]; ?></button>
          </a>
          </span>
       </strong1>
    </div>
    
    <div class="d-none d-md-block col-3  overflow-hidden" style="overflow:hidden; text-overflow:ellipsis;white-space: nowrap;">
        <span class="mt-0 text-dark employereachjob" href="""><button class="btn btn-primary-two btn-xs btn-rounded text-dark"><?php echo $job_location[$x]; ?></button></span>        
    </div>    

    <div class="d-none d-md-block col-1"">
        <a href="http://localhost/employer/jobs/#" class="dropdown-toggle arrow-none card-drop" data-toggle="dropdown" aria-expanded="false">
            <span class="text-muted font-13 pl-1"><?php echo $job_position[$x]; ?> </span>
        </a>        
    </div>

    
    <div class="d-none d-md-block col-1">
        <a href="http://localhost/employer/jobs/#" class="dropdown-toggle arrow-none card-drop" data-toggle="dropdown" aria-expanded="false">
            <span class="text-uppercase font-weight-bold purpletitle font-10 text-primary" data-toggle="popover" data-trigger="hover" title="" data-content="Job is live and ready for candidate to apply for. Keep looking for candidates." data-original-title="Live - What it means?"> <?php echo $job_applied[$x]; ?> </span>
        </a>        
    </div>
    

    <div class="col-xs-1 col-sm-1 col-md-1 align-middle my-auto">
    <div class="dropdown float-right align-middle">
    <div class="col-xs-1 col-sm-1 col-md-1 align-middle my-auto">
        <button id="<?php echo $job_id[$x]; ?>" onclick="view_job(this.id)" class="view_job btn btn-xs btn-primary-two"> <i class="fas text-muted">&#xf0c1;</i></button>
    </div>

    </div>        
    </div>        

    

</div>
</div>
        
<?php } ?>
                                                    
                                                    
                                            
        
        

	
	     
     


          

<p>&nbsp;</p>   
    
     
        

	
	
	
	
	

</div>                                     

 <!-- Display pagination links 
                        -->

                                               
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->





                      
                                
                                
                                <div class="card shadow1">
                                    <div class="card-body">
                                        <h5 class="mb-0 font-weight-bold mb-0 text-left text-uppercase text-primary" style="letter-spacing:1.2px;">VJX Recruiter Support</h5>                                        
                                </div>
                                    <div class="card-body p-0">
                                        <div class="row no-gutters">
                                            <div class="col-2 col-md-2 d-none1 col-sm-block1 col-md-41">
                                                <div class="card shadow-none m-0">
                                                    <div class="card-body text-center">
                                                        <img src="./Employer Dashboard _ QUANTUMHUNTS_files/1377931.svg" style="height:32px;width:32px;"><br>
                                                        <!--<i class="dripicons-briefcase text-dark" style="font-size: 24px;"></i>-->
                                                        <span class="text-dark">Support</span>
                                                    </div>
                                                </div>
                                            </div>
                

            
                
                                        </div> <!-- end row -->
                                    </div>                                
                                </div>

                                
                                

                                
                                
                                
                            </div> <!-- end col-->
                        </div>
                        




                                
                                
                                
                                
                                
                                
                                
                            </div><!-- end col-->


                            <div class="col-lg-4">
     <div class="row">

                            <div class="col-xl-12 col-lg-12">



<div class="card border cta-box">
<div class="card-body">
<div id="company_box">

<h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold" id="create" style="display:none">Create Company</h5>
<p id="aboutcompany" style="display:none">Create a company and manage the recruitment process as a team by adding question set and users to the company.</p>
<br><h5 id="company" style="">Question Set</h5>
<p id="d2" style="visibility: hidden"></p>
<input type="text" class="form-control" style="display:none" id="companyname"><br>


<button type="button" id="companynamesubmit" style="display:none" class="btn btn-primary btn-sm mt-2">Submit</button> 
<a href="http://localhost/view-sets/" type="button" class="btn btn-primary"><span style="color:white;"> Manage Set</span></a><br>
</div>
</div>
</div>

<div id="view" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true" style="display:none;">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">

        <div class="modal-content">

            <div class="modal-body card-body ">


                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
		<h5 class="mb-1 text-primary text-center text-uppercase purpletitle font-weight-bold">Question Set</h5> 
			
              <div class="card-body">
                        
                      
<div class="row">
<div class="col-12">
<ul class="nav nav-tab tab-grad mt-3">
    	
    <li class="nav-item">
        <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" href="http://localhost/employer/jobs/#viewset" data-toggle="tab" aria-expanded="true">
            <span class="d-none d-md-block">View Set</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" href="http://localhost/employer/jobs/#setadd" data-toggle="tab" aria-expanded="false">    
            <span class="d-none d-md-block">Create a New Set</span>
        </a>
    </li>
</ul>
<div class="tab-content ">
   
    <div class="tab-pane text-left" id="setadd">
<br><p>By Filling this Form You are able to Create a Set for your Company or Team</p><br>
	<div class="row"><div class="col-6">
	<div class="form-group"><lable for="setcategory">Module/Functionality</lable>
	<input type="text" class="form-control form-control-sm" placeholder="Python,Java,.etc" id="setcategory">
	</div>
	<div class="form-group"><lable for="settype">Type</lable>
	<i class="dripicons-information" style="font-size:15px;" data-toggle="popover" data-trigger="hover" data-placement="right" title="" data-content="Asynchronous Video is Virtual type Question interview." data-original-title="Type"></i>
	<br>
	<select class="form-control form-control-sm" name="settype" id="settype">
	<option value="Virtual">Asynchronous Video</option>
	<option value="MCQ">Multiple Choice Question</option></select>	
	</div>
	<div class="form-group">
	<lable for="setcomplexity">Complexity</lable>
	<br>
	<select class="form-control form-control-sm" name="setcomplexity" id="setcomplexity">
	<option value="Easy">Easy</option>
	<option value="Intermediate">Intermediate</option>
	<option value="Complex">Complex</option>
	</select>
												
	</div>
	<div class="form-group"><lable for="setaudible">Audible</lable><br><select class="form-control form-control-sm" name="settype" id="setaudible">
	<option value="Yes">Yes</option>
	<option value="No">No</option></select>
	</div></div></div>
	<div class="row"><div class="col-6">

	<lable for="settime">Time (in Mintues)</lable>
	<input type="number" role="spinbutton" placeholder="Eg:1 hour= 60 mintues" class="form-control form-control-sm" id="settime">
	</div></div>
	<br>
	<p class="text-center">
	<button type="submit" class="btn btn-primary btn-sm text-center" id="submit_set">Save
                      </button></p>
	<div class="alert alert-danger " id="categorymsg" style="display:none;">Please Enter the functionality.</div>
	<div class="alert alert-danger " id="typemsg" style="display:none;">Please Select the Type.</div>
	<div class="alert alert-danger " id="complexmsg" style="display:none;">Please Select the Complexity.</div>
	<div class="alert alert-danger " id="audiblemsg" style="display:none;">Please Select the Audible.</div>
	<div class="alert alert-danger " id="timemsg" style="display:none;">Please Enter the Set Time.</div>
	<p id="msg"></p>
	</div>
	<div class="tab-pane show active" id="viewset">
	<div id="seta" style="display:none"><p class="text-left">
	<br>Your Company or Team Doesn't create a set.If You are interest in create a set <br> 
	</p><ul class="nav nav-tab tab-grad mt-3">
    	
    <li class="nav-item">
        <a href="http://localhost/employer/jobs/#setadd" data-toggle="tab" aria-expanded="false" class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2">
            <span class="d-none d-md-block">Create a Set</span>
        </a>
    </li></ul>
<p></p></div>
<br>
<div id="setclass" style="display:none;">
<p>The Below list is the Question Set created by Your Company or Team</p><br>
	
<table class="table table-hover table-sm table-centered mb-0 table-responsive table-bordered table-striped">
    <tbody>

            <tr class="bg-light text-dark">
            <td> </td>
            <td><strong> Module/Functionality</strong></td>
            <td><strong> Type</strong></td>
	    <td><strong> Complexity</strong></td>
	    <td><strong> Audible</strong></td>
	    <td><strong></strong></td>
 		<td></td>           </tr> 
			</tbody><tbody id="vset">
</tbody>

                
    </table>
	<br><p class="text-center" id="setsave"></p></div>

	<div class="alert alert-info " id="deletemsg" style="display:none;">Set Deleted Sucessfully.</div>
<div class="alert alert-info " id="setsavemsg" style="display:none;">Set Saved Sucessfully..</div>
	</div>
	</div>               
</div></div> </div>

           </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->  
<div id="questview" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">

        <div class="modal-content">

            <div class="modal-body card-body ">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
              

                        <h5 class="mb-1 text-primary  text-uppercase purpletitle font-weight-bold">Question <i class="uil-angle-double-right"><p id="set_name"></p></i></h5> 
                        
                      <div class="card-body">

                 <div class="row">
<div class="col-12">
<ul class="nav nav-tab tab-grad mt-3">
    	
    <li class="nav-item">
        <a href="http://localhost/employer/jobs/#viewquestion" data-toggle="tab" aria-expanded="true" class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2">
            <i class="mdi mdi-account-circle d-md-none d-block"></i>
            <span class="d-none d-md-block">View Questions</span>
        </a>
    </li>
    <li class="nav-item">
        <a href="http://localhost/employer/jobs/#questionadd" data-toggle="tab" aria-expanded="false" class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2">
            
	   <i class="mdi mdi-home-variant d-md-none d-block"></i>
            <span class="d-none d-md-block">Add Question</span>
        </a>
    </li>
</ul>
<div class="tab-content">
   
    <div class="tab-pane " id="questionadd">
	<p>By Filling this Form You are able to create a Question for Company or Team</p>
	<p id="setname"></p><br>
	<p id="add_question"></p>
	</div>
	<div class="tab-pane show active" id="viewquestion">
	<div id="normalquestion" style="display:none"><br>
	<p>The List below are The Asynchronous Video Question of your Company or Team.</p><br>
	
	<div class="row"><div class="col-6">
	<lable for="setqtime">Time (in Mintues)</lable>
	<input type="number" role="spinbutton" placeholder="Eg:1 hour= 60 mintues" class="form-control form-control-sm" id="setqtime">
	</div>
<div class="col-6"><p id="setname1"></p></div>
</div><br>
	<p id="viewq"></p>
	</div>
	<div id="mcqquestion" style="display:none">
<br>
<p>The List below are The Multiple Choice Question of your Company or Team.</p>
<div class="row"><div class="col-6">

<lable for="setmcqtime">Time (in Mintues)</lable>
<input type="number" role="spinbutton" placeholder="Eg:1 hour= 60 mintues" class="form-control form-control-sm" id="setmcqtime">
</div>
<div class="col-6">
<p id="setname2"></p></div>
</div>
<br>
<p id="viewqq"></p>


</div>
<div class="alert alert-danger " id="questionmsg" style="display:none;">Please Enter the Question.</div>
<div class="alert alert-danger " id="questiontimemsg" style="display:none;">Please Enter the QuestionTime.</div>
<div class="alert alert-danger " id="choiceamsg" style="display:none;">Please Enter the  Choice A .</div>
<div class="alert alert-danger " id="choicebmsg" style="display:none;">Please Enter the  Choice B .</div>
<div class="alert alert-danger " id="choicecmsg" style="display:none;">Please Enter the  Choice C .</div>
<div class="alert alert-danger " id="choicedmsg" style="display:none;">Please Enter the  Choice D .</div>
<div class="alert alert-danger " id="answermsg" style="display:none;">Please Enter the Answer.</div>
<div class="alert alert-info " id="sucmsg" style="display:none;">Question added Sucessfully.</div>
<div class="alert alert-info " id="questionsavemsg" style="display:none;">Saved Sucessfully.</div>
<div class="alert alert-info " id="deleteqmsg" style="display:none;">Question Deleted Sucessfully.</div>
<p class="text-center" id="viewb"></p>

</div></div>

</div></div>

</div>
<div class="modal-footer">
<p class="text-center mt-3">
	<button type="button" class="btn btn-primary text-center" data-toggle="modal" data-dismiss="modal" onclick="view_set()" data-target="#view">Back</button> 

                         </p>

		</div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script id="expandfunction"></script>
<script>
function equestion(id,setid){
//alert(id);
var l=id.length;
//alert(l);
var arr=id.split(',');
//alert(arr);
//alert(arr.length);
var i;
var question=new Array();
for(i=0;i<arr.length;i++)
{
var q="question";
var b=q.concat(arr[i]);
question[i]=document.getElementById(b).value;
}

var questiontime=new Array();
for(i=0;i<arr.length;i++)
{
var qt="questiontime";
var bt=qt.concat(arr[i]);
questiontime[i]=document.getElementById(bt).value;
}
var settime=document.getElementById('setqtime').value;
//alert(question);
//alert(questiontime);
$.ajax({
type:"POST",
url:"http://localhost/dev/video-message/record/updateq.php",
dataType:"json",
data:{arr:arr,question:question,questiontime:questiontime,settime:settime,setid},
success:function(data){
if(data.code=='200'){
//alert(data.msg);
$('#questionsavemsg').show();
		$('#questionsavemsg').fadeOut(10000);
}
else{
//alert(data.msg);
}
}
});
}
function editquestion(question_id,id,companyname,questiontime){
//alert(question_id);
//alert(questiontime);
$.ajax({
	type:"POST",
	url:"http://localhost/dev/video-message/record/updatequestion.php",
	dataType: "json",
	data:{question_id:question_id,id:id,companyname:companyname,questiontime:questiontime},
	success: function(data){
	if(data.code=='200'){
	//alert(data.msg);
	var company=data.msg[2];
	//alert(company);
	$.ajax({
	
	type:"POST",
	url:"http://localhost/dev/video-message/record/view.php",
	dataType: "json",
	data:{setcompany:company},
	success: function(data){
	if(data.code=='200'){
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);var i=0;
	document.getElementById('questionid').value = data.msg[i+1];
	document.getElementById('setqtime').value = data.setqtime;
	$('#viewq').html('');
	var j=1;
	while(i<len)
	{
	$('#viewq').append('<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'">'+
  '<div class="card mb-0"><div class="card-header" id="headingFour"><h5 class="m-0">'+
   '<a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse-'+data.msg[i+1]+'"aria-expanded="false" aria-controls="collapseFour">'+
     'Q'+j+'.  '+data.msg[i+2]+'<i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5> </div>'+
            
        '<div id="collapse-'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'">'+
           ' <div class="card-body">   <div class="row"><div class="col-6">'+
'<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea>'+ 
'</div>'+

'<div class="col-6">'+


'<input type="text" class="form-control form-control-sm" id="questiontime'+data.msg[i+1]+'" value="'+data.msg[i+4]+'"/ >'
+'</div>'
+'<button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" data-target="#editquestion" >Delete</button>'
+'</div>            </div></div>'

+'<td>'+'</td>'+'</tr>'+'</table></div></div>');
j=j+1;i=i+5;}
$('#viewb').html('<button class="btn btn-primary" onclick="equestion(&#39;'+data.id+'&#39;,&#39;'+data.msg[i+1]+'&#39;)">save</button>');	
}
}
});



	
}
}
});
}



$(document).ready(function(){
    $('#submit_question').click(function(){
//alert("question");
      var questionid = $('#questionid').val();
      var question=$('#question').val();
      var questiontime=$('#questiontime').val();
	var questionaddedby=$('#questionaddedby').val();  
//alert("question");    
if(question=='')
{

}
else
{    
        $.ajax({
          type:"POST",
          url:"http://localhost/dev/video-message/record/addquestions.php",
          dataType: "json",
          data:{
            questionid:questionid,question:question,questiontime:questiontime,questionaddedby:questionaddedby},
          success:function(data){
	//alert(data.msg);
            if(data.status == 'ok'){
             //  alert(data.msg);
		document.getElementById('question').value = '';
		document.getElementById('questiontime').value = '';
		var company=data.msg[1];
	//alert(company);
	$.ajax({
	
	type:"POST",
	url:"http://localhost/dev/video-message/record/view.php",
	dataType: "json",
	data:{setcompany:company},
	success: function(data){
	if(data.code=='200'){
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);var i=0;
	document.getElementById('questionid').value = data.id;
	$('#viewq').html('');
	//alert(data.id);
	var j=1;
	while(i<len)
	{
	$('#viewq').append('<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'">'+
  '<div class="card mb-0"><div class="card-header" id="headingFour"><h5 class="m-0">'+
   '<a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse-'+data.msg[i+1]+'"aria-expanded="false" aria-controls="collapseFour">'+
     'Q'+j+'.  '+data.msg[i+2]+'<i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5> </div>'+
            
        '<div id="collapse-'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'">'+
           ' <div class="card-body">   <div class="row"><div class="col-6">'+
'<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea>'+ 
'</div>'+

'<div class="col-6">'+


'<input type="text" class="form-control form-control-sm" id="questiontime'+data.msg[i+1]+'" value="'+data.msg[i+4]+'"/ >'
+'</div>'
+'<button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" data-target="#editquestion" >Delete</button>'
+'</div>            </div></div>'

+'<td>'+'</td>'+'</tr>'+'</table></div></div>');
j=j+1;i=i+5;}
$('#viewb').html('<button class="btn btn-primary" onclick="equestion(&#39;'+data.id+'&#39;)">save</button>');	
}}

});



		
            }
            else{
		//alert(data.msg);
	 }
          }
        }
              );
	}
    }
                      );
  }
                   );





</script>
<script>
function submit_question(){
//alert("question");
      var questionid = $('#questionid').val();
      var question=$('#question').val();
      var questiontime=$('#questiontime').val();
	//var questionaddedby=$('#questionaddedby').val();  
//alert("question");       
if(question=='')
{
$('#questionmsg').show();
$('#question').focus();
}
else if(questiontime=='')
{
$('#questiontime').focus();
$('#questiontimemsg').show();
$('#questionmsg').hide();
}
else
{  
        $.ajax({
          type:"POST",
          url:"http://localhost/dev/video-message/record/addquestions.php",
          dataType: "json",
          data:{
            questionid:questionid,question:question,questiontime:questiontime},
          success:function(data){
	//alert(data.msg);
            if(data.status == 'ok'){
             //  alert(data.msg);
		$('#sucmsg').show();
		$('#sucmsg').fadeOut(10000);
		$('#questionmsg').hide();
		$('#questiontimemsg').hide();
		document.getElementById('question').value = '';
		document.getElementById('questiontime').value = '';
		var company=data.msg[1];
	//alert(company);
	$.ajax({
	
	type:"POST",
	url:"http://localhost/dev/video-message/record/view.php",
	dataType: "json",
	data:{setcompany:company},
	success: function(data){
	if(data.code=='200'){
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);
	var i=0;
	document.getElementById('questionid').value = data.id;
	document.getElementById('setqtime').value = data.setqtime;
	$('#viewq').html('');
//	alert(data.msg[i+1]);
	var j=1;
	while(i<len)
	{
	$('#viewq').append('<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'">'+
  '<div class="card mb-0"><div class="card-header" id="headingFour"><h5 class="m-0">'+
   '<a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse-'+data.msg[i+1]+'"aria-expanded="false" aria-controls="collapseFour">'+
     'Q'+j+'.  '+data.msg[i+2]+'<i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5> </div>'+
            
        '<div id="collapse-'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'">'+
           ' <div class="card-body">   <div class="row"><div class="col-6">'+
'<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea>'+ 
'</div>'+

'<div class="col-6">'+


'<input type="text" class="form-control form-control-sm" id="questiontime'+data.msg[i+1]+'" value="'+data.msg[i+4]+'"/ >'
+'</div>'
+'<button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" data-target="#editquestion" >Delete</button>'
+'</div>            </div></div>'

+'</div></div>');
j=j+1;i=i+6;}
$('#viewb').html('<button class="btn btn-primary" onclick="equestion(&#39;'+data.id+'&#39;,&#39;'+data.id+'&#39;)">save</button>');		
	}}
	
});



		
            }
            else{
		//alert(data.msg);
	 }
          }
        }
              );
}
}
</script>
<script>
function mcq_question()
{
//alert("add question");
//alert($('#choicea').val());
     var questionid = $('#questionid').val();
      var question=$('#question').val();
      var choicea=$('#choicea').val();
	var choiceb=$('#choiceb').val();
	var choicec=$('#choicec').val();
	var choiced=$('#choiced').val();
	var answer=$('#answer').val();
	var questionaddedby=$('#questionaddedby').val(); 
if(question=='')
{
$('#questionmsg').show();
$('#question').focus();
}
else if(choicea=='')
{
$('#choicea').focus();
$('#choiceamsg').show();
$('#questionmsg').hide();
}
else if(choiceb=='')
{
$('#choiceb').focus();
$('#choicebmsg').show();
$('#questionmsg').hide();
		$('#choiceamsg').hide();
		
}
else if(choicec=='')
{
$('#choicec').focus();
$('#choicecmsg').show();
$('#questionmsg').hide();
		$('#choiceamsg').hide();
		$('#choicebmsg').hide();
		
}
else if(choiced=='')
{
$('#choiced').focus();
$('#choicedmsg').show();
$('#questionmsg').hide();
		$('#choiceamsg').hide();
		$('#choicebmsg').hide();
		$('#choicecmsg').hide();
		
}
else if(answer=='')
{
$('#answer').focus();
$('#answermsg').show();
$('#questionmsg').hide();
		$('#choiceamsg').hide();
		$('#choicebmsg').hide();
		$('#choicecmsg').hide();
		$('#choicedmsg').hide();
		
}
else
{  
//alert(answer);        
        $.ajax({
          type:"POST",
          url:"http://localhost/dev/video-message/record/add_mcq_questions.php",
          dataType: "json",
          data:{
            questionid:questionid,question:question,choicea:choicea,choiceb:choiceb,choicec:choicec,choiced:choiced,answer:answer,questionaddedby:questionaddedby},
          success:function(data){
	//alert(data.msg);
            if(data.status == 'ok'){
               //alert(data.msg);
		document.getElementById('question').value = '';
		document.getElementById('choicea').value = '';
		document.getElementById('choiceb').value = '';
		document.getElementById('choicec').value = '';
		document.getElementById('choiced').value = '';
		//document.getElementById('answer').value = '';
		$('#sucmsg').show();
		$('#sucmsg').fadeOut(10000);
		$('#questionmsg').hide();
		$('#choiceamsg').hide();
		$('#choicebmsg').hide();
		$('#choicecmsg').hide();
		$('#choicedmsg').hide();
		$('#answermsg').hide();
		//var company=data.msg[1];
	//alert(company);
	var company=data.msg[2];
	var type='Multiple Choice Question';
	//alert(company);
	$.ajax({
	
	type:"POST",
	url:"http://localhost/dev/video-message/record/view.php",
	dataType: "json",
	data:{setcompany:company,type:type},
	success: function(data){
	if(data.code=='200'){
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);
	//var i=0;
	document.getElementById('questionid').value = data.id;
	var i=0;
	var j=1;
	$('#viewqq').html('');
	while(i<len)
	{
	$('#viewqq').append('<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'"><div class="card mb-0"> <div class="card-header" id="headingFour">'+
            '<h5 class="m-0"> <a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse'+data.msg[i+1]+'" aria-expanded="false" aria-controls="collapseFour">'+
             'Q'+j+'.'+data.msg[i+2]+' <i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5></div>'+
           ' <div id="collapse'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'"><div class="card-body">'+
	'<p class="card-text">'+
     '<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea></p>'+
    ' <div class="card-body"><div class="row"><div class=" col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 ">'+
   '<input type="radio" id="choicea'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'a' ? 'class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'>'+
  '<textarea class="form-control form-control-sm" id="choicea'+data.msg[i+1]+'" rows="4"  style="height: 92px; overflow: hidden;" spellcheck="false">'
  +data.msg[i+4]+'</textarea>'+
  '</div><div class=" col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 "><input type="radio" id="choiceb'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'b' ? ' class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'></td><td>'+
  '<textarea class="form-control form-control-sm" id="choiceb'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+5]+'</textarea>'+
 '</div> </div>'+
 '<div class="row"><div class="col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 " ><p class="card-text">'+
'<input type="radio" id="choicec'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'c' ? 'class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'>'+
'<textarea class="form-control form-control-sm" id="choicec'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+6]+'</textarea>'+
'</div><div class=" col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 "><input type="radio" id="choiced'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'd' ? 'class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'>'+
'<textarea class="form-control form-control-sm" id="choiced'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+7]+'</textarea>'+
'</p></div></div></div> '+'<button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" >Delete</button>'+' </div></div></div></div>');
	i=i+10;
	j=j+1;
	}
$('#viewb').html('<button class="btn btn-primary" onclick="mcqquestion(&#39;'+data.se+'&#39;,&#39;'+data.id+'&#39;,&#39;'+data.type+'&#39;,&#39;'+j+'&#39;)">save</button>');	
}}	
});

		
            }
            else{
		//alert(data.msg);
	 }
          }
        }
              );
}
}
function mcqquestion(id,s,type,j){
//alert(id);
var le=id.length;
//alert(le);
var arr=s.split(',');
//alert(arr);
//alert(arr.length);
var i;
var setmcqtime = $('#setmcqtime').val();

var se=new Array();
se=s;
//alert(se);
var question=new Array();
for(i=0;i<arr.length;i++)
{
var qq="question";
var bq=qq.concat(arr[i]);
question[i]=document.getElementById(bq).value;
}
//alert(question);
var choicea=new Array();
for(i=0;i<arr.length;i++)
{
var qa="choicea";
var ba=qa.concat(arr[i]);
choicea[i]=document.getElementById(ba).value;
}
var choiceb=new Array();
for(i=0;i<arr.length;i++)
{
var qb="choiceb";
var bb=qb.concat(arr[i]);
choiceb[i]=document.getElementById(bb).value;
}
var choicec=new Array();
for(i=0;i<arr.length;i++)
{
var qc="choicec";
var bc=qc.concat(arr[i]);
choicec[i]=document.getElementById(bc).value;
}
var choiced=new Array();
for(i=0;i<arr.length;i++)
{
var qd="choiced";
var bd=qd.concat(arr[i]);
choiced[i]=document.getElementById(bd).value;
}
var answer=new Array();
var k=1;
for(i=0;(i<arr.length)&(k<j);i++)
{

var qt="answer";
var bta=qa.concat(k);
var btb=qb.concat(k);
var btc=qc.concat(k);
var btd=qd.concat(k);
//alert(bta);
if(document.getElementById(bta).checked){
answer[i]='a';
}
else if(document.getElementById(btb).checked){
answer[i]='b';
}
else if(document.getElementById(btc).checked){
answer[i]='c';
}
else if(document.getElementById(btd).checked){
answer[i]='d';
}
k++;
}
//alert(choicea);
//alert(answer);
$.ajax({
type:"POST",
url:"http://localhost/dev/video-message/record/updatemcqq.php",
dataType:"json",
data:{arr:arr,id:id,se:se,question:question,choicea:choicea,choiceb:choiceb,choicec:choicec,choiced:choiced,answer:answer,setmcqtime:setmcqtime},
success:function(data){
if(data.code=='200'){
//alert(data.msg);
$('#questionsavemsg').show();
		$('#questionsavemsg').fadeOut(10000);
}
else{
//alert(data.msg);
}
}
});
}
</script>
<script>
function deletequestion(id,se,type){
$.ajax({
type:"POST",
url:"http://localhost/dev/video-message/record/deleteq.php",
dataType:"json",
data:{id:id,se:se,type:type},
success:function(data){
if(data.code=='200'){
//alert("success");
$('#deleteqmsg').show();
$('#deleteqmsg').fadeOut(100000);
var type=data.type;
var company=data.se;
$.ajax({
	
	type:"POST",
	url:"http://localhost/dev/video-message/record/view.php",
	dataType: "json",
	data:{setcompany:company,type:type},
	success: function(data){
	if(data.code=='200'){
		if(data.type=='Asynchronous Video'){
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);
	var i=0;
	//alert(data.id);
	$('#add_question').html('');
	$('#add_question').append('<p>'+
'<div class="form-group" style="display:none;">'+
'<lable for="questionid">Question Id</lable>'+
'<textarea class="form-control form-control-sm" id="questionid" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
                       
'</div></p><br>'+
'<div class="form-group">'+
'<lable for="question">Question</lable>'+
'<textarea class="form-control form-control-sm" id="question" rows="4"  style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
'</div><br><div class="row"><div class="col-6">'+
'<div class="form-group">'+
'<lable for="questiontime">Question Time (in seconds)</lable>'+
'<input type="number" role="spinbutton" class="form-control form-control-sm" id="questiontime" placeholder="Eg: 1 hour= 3,600 seconds" / >'+
'</div></div></div>'+
'<br>'+
'<button type="submit"  class="btn btn-primary btn-sm" onclick="submit_question()"  id="submit_question">Save '+
                      '</button>');
	document.getElementById('questionid').value = data.se;
	$('#viewq').html('');
	$('#mcqquestion').hide();
	$('#normalquestion').show();
	var j=1;
	while(i<len)
	{
	$('#viewq').append('<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'">'+
  '<div class="card mb-0"><div class="card-header" id="headingFour"><h5 class="m-0">'+
   '<a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse-'+data.msg[i+1]+'"aria-expanded="false" aria-controls="collapseFour">'+
     'Q'+j+'.  '+data.msg[i+2]+'<i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5> </div>'+
            
        '<div id="collapse-'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'">'+
           ' <div class="card-body text-left">   <div class="row">'+'<lable>Question</lable>'+
'<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea>'+ 
'</div>'+

'<div class="row">'+

'<lable>Question Time(in seconds)</lable>'+
'<input type="text" class="form-control form-control-sm" id="questiontime'+data.msg[i+1]+'" value="'+data.msg[i+4]+'"/ >'
+'</div><br>'
+'<p class="text-center"><button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" data-target="#editquestion" >Delete</button></p>'
+'            </div></div>'

+'<td>'+'</td>'+'</tr>'+'</table></div></div>');

$('#expandfunction').append('expandTextarea(&#39;question' + data.msg[i+1] + '&#39;)&#59;');
i=i+6;j=j+1;}
$('#viewb').html('<button class="btn btn-primary text-center" onclick="equestion(&#39;'+data.id+'&#39;)">save</button>');	
	}		
	else if(data.type=='Multiple Choice Question'){
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);
	var i=0;
	//alert(data.id);
	$('#add_question').html('');
	$('#add_question').append('<p >'+
'<div class="form-group" style="display:none;">'+
'<lable for="questionid">Question Id</lable>'+
'<input type="text" class="form-control form-control-sm" id="questionid" / >'+
                       
'</div></p>'+
'<div class="form-group">'+
'<lable for="question">Question</lable>'+

'<textarea class="form-control form-control-sm" id="question" rows="4"  style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
'</div>'+
'<div class="row"><div class="col-6"><div class="form-group">'+
'<lable for="choicea">Choice A</lable>'+
'<textarea class="form-control form-control-sm" id="choicea" rows="4" placeholder="Choice A" style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
'</div></div>'+
'<div class="col-6"><div class="form-group">'+
'<lable for="choiceb">Choice B</lable>'+

'<textarea class="form-control form-control-sm" id="choiceb" rows="4" placeholder="Choice B" style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+

'</div></div></div>'+
'<div class="row"><div class="col-6"><div class="form-group">'+
'<lable for="choicec">Choice C</lable>'+
'<textarea class="form-control form-control-sm" id="choicec" rows="4" placeholder="Choice C" style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+

'</div></div>'+
'<div class="col-6"><div class="form-group">'+
'<lable for="choiced">Choice D</lable>'+
'<textarea class="form-control form-control-sm" id="choiced" rows="4" placeholder="Choice D" style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
'</div></div></div>'+
'<div class="form-group"><lable for="answer">Answer</lable><br><select name="answer" id="answer">'+
	'<option value="a">A</option>'+
	'<option value="b">B</option>'+

	'<option value="c">C</option>'+
	'<option value="d">D</option></select>'+
	'</div><br>'+
'<button type="submit"  class="btn btn-primary btn-sm" onclick="mcq_question()"  id="submit_mcq_question">Save '+
                      '</button>'
);
	document.getElementById('questionid').value = data.se;
	document.getElementById('setmcqtime').value = data.setmcqtime;
	$('#viewqq').html('');
	$('#normalquestion').hide();
	$('#mcqquestion').show();
	var j=1;
	while(i<len)
	{
	$('#viewqq').append('<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'"><div class="card mb-0"> <div class="card-header" id="headingFour">'+
            '<h5 class="m-0"> <a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse'+data.msg[i+1]+'" aria-expanded="false" aria-controls="collapseFour">'+
             'Q'+j+'.'+data.msg[i+2]+' <i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5></div>'+
           ' <div id="collapse'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'"><div class="card-body">'+
	'<p class="card-text">'+
     '<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea></p>'+
    ' <div class="card-body"><div class="row"><div class=" col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 ">'+
   '<input type="radio" id="choicea'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'a' ? 'class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'>'+
  '<textarea class="form-control form-control-sm" id="choicea'+data.msg[i+1]+'" rows="4"  style="height: 92px; overflow: hidden;" spellcheck="false">'
  +data.msg[i+4]+'</textarea>'+
  '</div><div class=" col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 "><input type="radio" id="choiceb'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'b' ? ' class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'></td><td>'+
  '<textarea class="form-control form-control-sm" id="choiceb'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+5]+'</textarea>'+
 '</div> </div>'+
 '<div class="row"><div class="col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 " ><p class="card-text">'+
'<input type="radio" id="choicec'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'c' ? 'class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'>'+
'<textarea class="form-control form-control-sm" id="choicec'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+6]+'</textarea>'+
'</div><div class=" col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 "><input type="radio" id="choiced'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'd' ? 'class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'>'+
'<textarea class="form-control form-control-sm" id="choiced'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+7]+'</textarea>'+
'</p></div></div></div> '+'<button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" >Delete</button>'+' </div></div></div></div>');
	i=i+10;
	j=j+1;
	}
	while(i<len)
	{
	$('#viewqq').append('<tr>'+
	'<td>'+data.msg[i]+'</td>'+'<td>'+data.msg[i+9]+'</td>'+'<td><input type="text" class="form-control form-control-sm" id="question'+data.msg[i+1]+'" value="'+data.msg[i+2]+'"/ ></td>'+
'<td><input type="text" class="form-control form-control-sm" id="choicea'+data.msg[i+1]+'" value="'+data.msg[i+4]+'"/ ></td>'
+'<td><input type="text" class="form-control form-control-sm" id="choiceb'+data.msg[i+1]+'" value="'+data.msg[i+5]+'"/ ></td>'
+'<td><input type="text" class="form-control form-control-sm" id="choicec'+data.msg[i+1]+'" value="'+data.msg[i+6]+'"/ ></td>'
+'<td><input type="text" class="form-control form-control-sm" id="choiced'+data.msg[i+1]+'" value="'+data.msg[i+7]+'"/ ></td>'
+'<td><input type="text" class="form-control form-control-sm" id="answer'+data.msg[i+1]+'" value="'+data.msg[i+8]+'"/ ></td>'
+'<td><button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" >Delete</button>'+'</td>'+'</tr>');
i=i+10;}
$('#viewb').html('<button class="btn btn-primary" onclick="mcqquestion(&#39;'+data.se+'&#39;,&#39;'+data.id+'&#39;,&#39;'+data.type+'&#39;,&#39;'+j+'&#39;)">save</button>');	
	//alert(j);}		
else{
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);
	var i=0;
	//alert(data.id);
	$('#add_question').html('');
	$('#add_question').append('<tr>'+
	'<td></td>'+
'<td></td>'+
'<td><div class="form-group">'+
'<lable for="questionid">Question Id</lable>'+
'<input type="text" class="form-control form-control-sm" id="questionid" / >'+
                       
'</div></td>'+
'<td><div class="form-group">'+
'<lable for="question">Question</lable>'+
'<input type="text" class="form-control form-control-sm" id="question" / >'+

'</div></td>'+
'<td><div class="form-group">'+
'<lable for="questiontime">Question Time</lable>'+
'<input type="text" class="form-control form-control-sm" id="questiontime" / >'+
'</div></td>'+
'<td>'+
'</td>'+
'<td>'+
'<button type="submit"  class="btn btn-primary btn-sm"   id="submit_question">Save '+
                      '</button>'+
'</td>'+
'</tr>');
	document.getElementById('questionid').value = data.se;
	
	$('#viewq').html('');
	$('#mcqquestion').hide();
	$('#normalquestion').show();
	while(i<len)
	{
	$('#viewq').append(
'<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'">'+
  '<div class="card mb-0"><div class="card-header" id="headingFour"><h5 class="m-0">'+
   '<a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse-'+data.msg[i+1]+'"aria-expanded="false" aria-controls="collapseFour">'+
     'Q'+j+'.  '+data.msg[i+2]+'<i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5> </div>'+
            
        '<div id="collapse-'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'">'+
           ' <div class="card-body">   <div class="row"><div class="col-6">'+
'<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea>'+ 
'</div>'+

'<div class="col-6">'+


'<input type="text" class="form-control form-control-sm" id="questiontime'+data.msg[i+1]+'" value="'+data.msg[i+4]+'"/ >'
+'</div>'
+'<button type="button" class="btn btn-primary text-right" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" data-target="#editquestion" >Delete</button>'
+'</div>            </div></div>'

+'<td>'+'</td>'+'</tr>'+'</table></div></div>');
i=i+6;}

$('#viewb').html('<button class="btn btn-primary text-center" onclick="equestion(&#39;'+data.id+'&#39;)">save</button>');	
	}


}



}
});
}
}
});
}

function expandTextarea(id) {
    document.getElementById(id).addEventListener('keyup', function() {
        this.style.overflow = 'hidden';
        this.style.height = 0;
        this.style.height = this.scrollHeight + 'px';
    }, false);
}

</script>
      


<script>
function expandTextarea(id) {
    document.getElementById(id).addEventListener('keyup', function() {
        this.style.overflow = 'hidden';
        this.style.height = 0;
        this.style.height = this.scrollHeight + 'px';
    }, false);
}

function view_set(){
	$('#view').show();
//alert("viewset");
		$.ajax({
	type:"POST",
	url:"http://localhost/dev/video-message/record/set.php",
	dataType: "json",
	success: function(data){
	if(data.code=='200'){
	$('#setclass').show();
	$('#view').show();	
//alert(data.msg[5]);
	//alert(data.id);
	$('#view').show();
	$('#seta').hide();
	var len=data.msg.length;
	//alert(len);
	$('#vset').html('');
	var i=0;
	while(i<len)
	{
	$('#vset').append('<tr>'+
	'<td>'+data.msg[i]+'</td>'+'<td>'+data.msg[i+4]+'{'+data.msg[i+3]+'}'+
	'</td>'+'<td>'+data.msg[i+5]+'</td>'+
'<td><select class="form-control form-control-sm" name="setcomplexity" id="setcomplexity'+data.msg[i+1]+'">'
	+'<option value="Easy"'+ (data.msg[i+6] == 'Easy' ? 'selected ': ' ')+'>Easy</option>'
	+'<option value="Intermediate" '+ (data.msg[i+6] == 'Intermediate' ? 'selected ': ' ')+'>Intermediate</option>'
	+'<option value="Complex"'+ (data.msg[i+6] == 'Complex' ? 'selected ': ' ')+'>Complex</option>'
	+'</select>'
+'</td>'+
'<td><select class="form-control form-control-sm" name="settype" id="setaudible'+data.msg[i+1]+'">'
	+'<option value="Yes" '+ (data.msg[i+7] == 'Yes' ? 'selected ': ' ')+'>Yes</option>'
	+'<option value="No" '+ (data.msg[i+7] == 'No' ? 'selected ': ' ')+'>No</option></select>'
+'</td>'+
'<td><button type="button" class="btn btn-primary" data-toggle="modal" data-dismiss="modal" onclick="view_question(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.msg[i+5]+'&#39;,&#39;'+data.msg[i+4]+'{'+data.msg[i+3]+'}'+'&#39;)"  data-target="#questview"><i class="fa fa-question-circle"></i></button>'
+'</td>'+'<td><button type="button" class="btn btn-danger" onclick="delete_set(&#39;'+data.msg[i+1]+'&#39;)" ><i class="fa fa-trash"></i></button>'
+'</td>' +'</tr>');
i=i+8;}
	$('#setsave').html('<button class="btn btn-primary" onclick="saveset(&#39;'+data.id+'&#39;)">save</button>');	
}
else
{
//alert(data.msg);
$('#seta').show();
}
}
});
}
</script>
<script>
function delete_set(id)
{
//alert(id);
$.ajax({
type:"POST",
url:"http://localhost/dev/video-message/record/deleteset.php",
dataType:"json",
data:{id:id},
success:function(data){
if(data.code=='200'){
$('#view').show();
//alert("viewset");
$('#deletemsg').show();
$('#deletemsg').fadeOut(100000);
		$.ajax({
	type:"POST",
	url:"http://localhost/dev/video-message/record/set.php",
	dataType: "json",
	success: function(data){
	if(data.code=='200'){
	$('#setclass').show();
	$('#view').show();	
//alert(data.msg[5]);
	//alert(data.id);
	$('#view').show();
	$('#seta').hide();
	var len=data.msg.length;
	//alert(len);
	$('#vset').html('');
	var i=0;
	while(i<len)
	{
	$('#vset').append('<tr>'+
	'<td>'+data.msg[i]+'</td>'+'<td>'+data.msg[i+4]+'{'+data.msg[i+3]+'}'+
	'</td>'+'<td>'+data.msg[i+5]+'</td>'+
'<td><select class="form-control form-control-sm" name="setcomplexity" id="setcomplexity'+data.msg[i+1]+'">'
	+'<option value="Easy"'+ (data.msg[i+6] == 'Easy' ? 'selected ': ' ')+'>Easy</option>'
	+'<option value="Intermediate" '+ (data.msg[i+6] == 'Intermediate' ? 'selected ': ' ')+'>Intermediate</option>'
	+'<option value="Complex"'+ (data.msg[i+6] == 'Complex' ? 'selected ': ' ')+'>Complex</option>'
	+'</select>'
+'</td>'+
'<td><select class="form-control form-control-sm" name="settype" id="setaudible'+data.msg[i+1]+'">'
	+'<option value="Yes" '+ (data.msg[i+7] == 'Yes' ? 'selected ': ' ')+'>Yes</option>'
	+'<option value="No" '+ (data.msg[i+7] == 'No' ? 'selected ': ' ')+'>No</option></select>'
+'</td>'+
'<td><button type="button" class="btn btn-primary" data-toggle="modal" data-dismiss="modal" onclick="view_question(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.msg[i+5]+'&#39;,&#39;'+data.msg[i+4]+'{'+data.msg[i+3]+'}'+'&#39;)"  data-target="#questview"><i class="fa fa-question-circle"></i></button>'
+'</td>'+'<td><button type="button" class="btn btn-danger" onclick="delete_set(&#39;'+data.msg[i+1]+'&#39;)" ><i class="fa fa-trash"></i></button>'
+'</td>' +'</tr>');
i=i+8;}
	$('#setsave').html('<button class="btn btn-primary" onclick="saveset(&#39;'+data.id+'&#39;)">save</button>');	
}
else
{
//alert(data.msg);
$('#seta').show();
}
}
});
}
}
});

}
</script>
<script>
function saveset(id){
//alert(id);
var len=id.length;
//alert(len);
var arr=new Array();arr=id.split(',');
//alert(arr);
//alert(arr.length);
var i;
var setcomplexity=new Array();
for(i=0;i<arr.length;i++)
{
var qt="setcomplexity";
var bt=qt.concat(arr[i]);
setcomplexity[i]=document.getElementById(bt).value;
}
var j;
var setaudible=new Array();
for(j=0;j<arr.length;j++)
{
var qaud="setaudible";
var baud=qaud.concat(arr[j]);
setaudible[j]=document.getElementById(baud).value;
}

//alert(settype);
//alert(setcomplexity);
$.ajax({
type:"POST",
url:"http://localhost/dev/video-message/record/update_set.php",
dataType:"json",
data:{arr:arr,setcomplexity:setcomplexity,setaudible:setaudible},
success:function(data){
if(data.code=='200'){
$('#setclass').show();
//alert(data.msg);
$('#setsavemsg').show();
		$('#setsavemsg').fadeOut(10000);
}
else{
//alert(data.msg);
}
}
});
}
</script>
<script>
function view_question(company,type,setname)
{
//alert(company);
//alert(type);
$.ajax({
	
	type:"POST",
	url:"http://localhost/dev/video-message/record/view.php",
	dataType: "json",
	data:{setcompany:company,type:type},
	success: function(data){
	if(data.code=='200'){
	$('#setname').html();
		if(data.type=='Asynchronous Video'){
	//alert(data.msg);
	$('#set_name').html(setname);
	$('#setname1').html();
	$('#setname1').append('.<br> Type :'+type+'.');
	var len=data.msg.length;
	//alert(len);
	var i=0;
	//alert(data.id);
	$('#add_question').html('');
	$('#add_question').append('<p>'+
'<div class="form-group" style="display:none;">'+
'<lable for="questionid">Question Id</lable>'+
'<textarea class="form-control form-control-sm" id="questionid" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
                       
'</div></p><br>'+
'<div class="form-group">'+
'<lable for="question">Question</lable>'+
'<textarea class="form-control form-control-sm" id="question" rows="4"  style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
'</div><br><div class="row"><div class="col-6">'+
'<div class="form-group">'+
'<lable for="questiontime">Question Time (in seconds)</lable>'+
'<input type="number" role="spinbutton" class="form-control form-control-sm" id="questiontime" placeholder="Eg: 1 hour= 3,600 seconds" / >'+
'</div></div></div>'+
'<br>'+
'<button type="submit"  class="btn btn-primary btn-sm" onclick="submit_question()"  id="submit_question">Save '+
                      '</button>');
	document.getElementById('questionid').value = data.se;
	document.getElementById('setqtime').value = data.setqtime;
	$('#viewq').html('');
	$('#mcqquestion').hide();
	$('#normalquestion').show();
	var j=1;
	while(i<len)
	{
	$('#viewq').append('<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'">'+
  '<div class="card mb-0"><div class="card-header" id="headingFour"><h5 class="m-0">'+
   '<a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse-'+data.msg[i+1]+'"aria-expanded="false" aria-controls="collapseFour">'+
     '<ul class="pagination pagination-rounded"><li class="paginate_button page-item "><span class="page-link pagination pagination-rounded active">Q'+j+'.</span></li></ul>  '+data.msg[i+2]+'<i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5> </div>'+
            
        '<div id="collapse-'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'">'+
           ' <div class="card-body text-left">   <div class="row">'+'<lable>Question</lable>'+
'<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea>'+ 
'</div>'+

'<div class="row">'+

'<lable>Question Time(in seconds)</lable>'+
'<input type="text" class="form-control form-control-sm" id="questiontime'+data.msg[i+1]+'" value="'+data.msg[i+4]+'"/ >'
+'</div><br>'
+'<p class="text-center"><button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" data-target="#editquestion" >Delete</button></p>'
+'            </div></div>'

+'<td>'+'</td>'+'</tr>'+'</table></div></div>');

$('#expandfunction').append('expandTextarea(&#39;question' + data.msg[i+1] + '&#39;)&#59;');
i=i+6;j=j+1;}
$('#viewb').html('<button class="btn btn-primary text-center" onclick="equestion(&#39;'+data.id+'&#39;,&#39;'+data.se+'&#39;)">save</button>');	
	}		
	else if(data.type=='Multiple Choice Question'){
	$('#set_name').html(setname);
	$('#setname2').html('');
	$('#setname2').append('.<br> Type :'+type+'.');
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);
	var i=0;
	//alert(data.id);
	$('#add_question').html('');
	$('#add_question').append('<p >'+
'<div class="form-group" style="display:none;">'+
'<lable for="questionid">Question Id</lable>'+
'<input type="text" class="form-control form-control-sm" id="questionid" / >'+
                       
'</div></p>'+
'<div class="form-group">'+
'<lable for="question">Question</lable>'+

'<textarea class="form-control form-control-sm" id="question" rows="4"  style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
'</div>'+
'<div class="row"><div class="col-6"><div class="form-group">'+
'<lable for="choicea">Choice A</lable>'+
'<textarea class="form-control form-control-sm" id="choicea" rows="4" placeholder="Choice A" style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
'</div></div>'+
'<div class="col-6"><div class="form-group">'+
'<lable for="choiceb">Choice B</lable>'+

'<textarea class="form-control form-control-sm" id="choiceb" rows="4" placeholder="Choice B" style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+

'</div></div></div>'+
'<div class="row"><div class="col-6"><div class="form-group">'+
'<lable for="choicec">Choice C</lable>'+
'<textarea class="form-control form-control-sm" id="choicec" rows="4" placeholder="Choice C" style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+

'</div></div>'+
'<div class="col-6"><div class="form-group">'+
'<lable for="choiced">Choice D</lable>'+
'<textarea class="form-control form-control-sm" id="choiced" rows="4" placeholder="Choice D" style="height: 92px; overflow: hidden;" spellcheck="false"></textarea>'+
'</div></div></div>'+
'<div class="form-group"><lable for="answer">Answer</lable><br><select name="answer" id="answer">'+
	'<option value="a">A</option>'+
	'<option value="b">B</option>'+

	'<option value="c">C</option>'+
	'<option value="d">D</option></select>'+
	'</div><br>'+
'<button type="submit"  class="btn btn-primary btn-sm" onclick="mcq_question()"  id="submit_mcq_question">Save '+
                      '</button>'
);
	document.getElementById('questionid').value = data.se;
	document.getElementById('setmcqtime').value = data.setmcqtime;
	$('#viewqq').html('');
	$('#normalquestion').hide();
	$('#mcqquestion').show();
	var j=1;
	while(i<len)
	{
	$('#viewqq').append('<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'"><div class="card mb-0"> <div class="card-header" id="headingFour">'+
            '<h5 class="m-0"> <a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse'+data.msg[i+1]+'" aria-expanded="false" aria-controls="collapseFour">'+
             'Q'+j+'.'+data.msg[i+2]+' <i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5></div>'+
           ' <div id="collapse'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'"><div class="card-body">'+
	'<p class="card-text">'+
     '<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea></p>'+
    ' <div class="card-body"><div class="row"><div class=" col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 ">'+
   '<input type="radio" id="choicea'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'a' ? 'class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'>'+
  '<textarea class="form-control form-control-sm" id="choicea'+data.msg[i+1]+'" rows="4"  style="height: 92px; overflow: hidden;" spellcheck="false">'
  +data.msg[i+4]+'</textarea>'+
  '</div><div class=" col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 "><input type="radio" id="choiceb'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'b' ? ' class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'></td><td>'+
  '<textarea class="form-control form-control-sm" id="choiceb'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+5]+'</textarea>'+
 '</div> </div>'+
 '<div class="row"><div class="col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 " ><p class="card-text">'+
'<input type="radio" id="choicec'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'c' ? 'class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'>'+
'<textarea class="form-control form-control-sm" id="choicec'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+6]+'</textarea>'+
'</div><div class=" col-12 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 "><input type="radio" id="choiced'+j+'" name="answer'+data.msg[i+1]+'" '+(data.msg[i+8] == 'd' ? 'class="custom-control custom-radio custom-radio-success mb-2" checked ': ' class="custom-control custom-radio custom-radio-danger mb-2"')+'>'+
'<textarea class="form-control form-control-sm" id="choiced'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+7]+'</textarea>'+
'</p></div></div></div> '+'<button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" >Delete</button>'+' </div></div></div></div>');
	i=i+10;
	j=j+1;
	}
	while(i<len)
	{
	$('#viewqq').append('<tr>'+
	'<td>'+data.msg[i]+'</td>'+'<td>'+data.msg[i+9]+'</td>'+'<td><input type="text" class="form-control form-control-sm" id="question'+data.msg[i+1]+'" value="'+data.msg[i+2]+'"/ ></td>'+
'<td><input type="text" class="form-control form-control-sm" id="choicea'+data.msg[i+1]+'" value="'+data.msg[i+4]+'"/ ></td>'
+'<td><input type="text" class="form-control form-control-sm" id="choiceb'+data.msg[i+1]+'" value="'+data.msg[i+5]+'"/ ></td>'
+'<td><input type="text" class="form-control form-control-sm" id="choicec'+data.msg[i+1]+'" value="'+data.msg[i+6]+'"/ ></td>'
+'<td><input type="text" class="form-control form-control-sm" id="choiced'+data.msg[i+1]+'" value="'+data.msg[i+7]+'"/ ></td>'
+'<td><input type="text" class="form-control form-control-sm" id="answer'+data.msg[i+1]+'" value="'+data.msg[i+8]+'"/ ></td>'
+'<td><button type="button" class="btn btn-primary" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" >Delete</button>'+'</td>'+'</tr>');
i=i+10;}
$('#viewb').html('<button class="btn btn-primary" onclick="mcqquestion(&#39;'+data.se+'&#39;,&#39;'+data.id+'&#39;,&#39;'+data.type+'&#39;,&#39;'+j+'&#39;)">save</button>');	
	//alert(j);}		
else{
	$('#set_name').html(setname);
	$('#setname1').html();
	$('#setname1').append('.<br> Type :'+type+'.');
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);
	var i=0;
	//alert(data.id);
	$('#add_question').html('');
	$('#add_question').append('<tr>'+
	'<td></td>'+
'<td></td>'+
'<td><div class="form-group">'+
'<lable for="questionid">Question Id</lable>'+
'<input type="text" class="form-control form-control-sm" id="questionid" / >'+
                       
'</div></td>'+
'<td><div class="form-group">'+
'<lable for="question">Question</lable>'+
'<input type="text" class="form-control form-control-sm" id="question" / >'+

'</div></td>'+
'<td><div class="form-group">'+
'<lable for="questiontime">Question Time</lable>'+
'<input type="text" class="form-control form-control-sm" id="questiontime" / >'+
'</div></td>'+
'<td>'+
'</td>'+
'<td>'+
'<button type="submit"  class="btn btn-primary btn-sm"   id="submit_question">Save '+
                      '</button>'+
'</td>'+
'</tr>');
	document.getElementById('questionid').value = data.se;
	document.getElementById('setqtime').value = data.setqtime;
	$('#viewq').html('');
	$('#mcqquestion').hide();
	$('#normalquestion').show();
	while(i<len)
	{
	$('#viewq').append(
'<div class="accordion custom-accordion" id="custom-accordion-'+data.msg[i+1]+'">'+
  '<div class="card mb-0"><div class="card-header" id="headingFour"><h5 class="m-0">'+
   '<a class="custom-accordion-title d-block py-1" data-toggle="collapse" href="#collapse-'+data.msg[i+1]+'"aria-expanded="false" aria-controls="collapseFour">'+
     'Q'+j+'.  '+data.msg[i+2]+'<i class="mdi mdi-chevron-down accordion-arrow"></i></a></h5> </div>'+
            
        '<div id="collapse-'+data.msg[i+1]+'" class="collapse"aria-labelledby="headingFour" data-parent="#custom-accordion-'+data.msg[i+1]+'">'+
           ' <div class="card-body">   <div class="row"><div class="col-6">'+
'<textarea class="form-control form-control-sm" id="question'+data.msg[i+1]+'" rows="4" placeholder="Write something..." style="height: 92px; overflow: hidden;" spellcheck="false">'+data.msg[i+2]+'</textarea>'+ 
'</div>'+

'<div class="col-6">'+


'<input type="text" class="form-control form-control-sm" id="questiontime'+data.msg[i+1]+'" value="'+data.msg[i+4]+'"/ >'
+'</div>'
+'<button type="button" class="btn btn-primary text-right" data-toggle="modal" onclick="deletequestion(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.se+'&#39;,&#39;'+data.type+'&#39;)" data-target="#editquestion" >Delete</button>'
+'</div>            </div></div>'

+'<td>'+'</td>'+'</tr>'+'</table></div></div>');
i=i+6;}

$('#viewb').html('<button class="btn btn-primary text-center" onclick="equestion(&#39;'+data.id+'&#39;,&#39;'+data.se+'&#39;)">save</button>');	
	}



}



}
});
}
</script>
<script>
$(document).ready(function(){
    $('#submit_set').click(function(){
	//alert("set");
      var setcategory = $('#setcategory').val();
      var settype=$('#settype').val();
	var setcomplexity=$('#setcomplexity').val();
	var setaudible=$('#setaudible').val();
	var settime=$('#settime').val();
           //alert(setcategory); 
if(setcategory==''){
	$('#categorymsg').show();
	$('#setcategory').focus();
	}
else if(settype=='')
{
$('#typemsg').show();
	$('#settype').focus();
$('#categorymsg').hide();
}
else if(setcomplexity=='')
{
$('#complexmsg').show();
	$('#setcomplexity').focus();
$('#categorymsg').hide();
		$('#typemsg').hide();
		
}
else if(setaudible=='')
{
$('#audiblemsg').show();
	$('#setaudible').focus();
$('#categorymsg').hide();
		$('#typemsg').hide();
		$('#complexmsg').hide();
}
else if(settime=='')
{	
	$('#timemsg').show();
	$('#audiblemsg').hide();
	$('#categorymsg').hide();
		$('#typemsg').hide();
		$('#complexmsg').hide();
}
	else{
        $.ajax({
          type:"POST",
          url:"http://localhost/dev/video-message/record/addset.php",
          dataType: "json",
          data:{
            setcategory:setcategory,settype:settype,setcomplexity:setcomplexity,setaudible:setaudible,setime:settime},
          success:function(data){
            if(data.status == 'ok'){
               //alert(data.msg);
		document.getElementById('setcategory').value = '';
		document.getElementById('settime').value = '';
		$('#categorymsg').hide();
		$('#typemsg').hide();
		$('#complexmsg').hide();
		$('#audiblemsg').hide();
		$('#timemsg').hide();
		$('#msg').html('<div class="alert alert-info " id="setsucessmsg" >'+data.set+
                      '</div>');
		$('#msg').fadeOut(10000);
		$.ajax({
	type:"POST",
	url:"http://localhost/dev/video-message/record/set.php",
	dataType: "json",
	success: function(data){
	if(data.code=='200'){
	//alert(data.msg);
	var len=data.msg.length;
	//alert(len);
	$('#vset').html('');
	var i=0;
	while(i<len)
	{
	$('#vset').append('<tr>'+
	'<td>'+data.msg[i]+'</td>'+'<td>'+data.msg[i+4]+'{'+data.msg[i+3]+'}'+
	'</td>'+'<td>'+data.msg[i+5]+'</td>'+
'<td><select class="form-control form-control-sm" name="setcomplexity" id="setcomplexity'+data.msg[i+1]+'">'
	+'<option value="Easy"'+ (data.msg[i+6] == 'Easy' ? 'selected ': ' ')+'>Easy</option>'
	+'<option value="Intermediate" '+ (data.msg[i+6] == 'Intermediate' ? 'selected ': ' ')+'>Intermediate</option>'
	+'<option value="Complex"'+ (data.msg[i+6] == 'Complex' ? 'selected ': ' ')+'>Complex</option>'
	+'</select>'
+'</td>'+
'<td><select class="form-control form-control-sm" name="settype" id="setaudible'+data.msg[i+1]+'">'
	+'<option value="Yes" '+ (data.msg[i+7] == 'Yes' ? 'selected ': ' ')+'>Yes</option>'
	+'<option value="No" '+ (data.msg[i+7] == 'No' ? 'selected ': ' ')+'>No</option></select>'
+'</td>'+
'<td><button type="button" class="btn btn-primary" data-toggle="modal" data-dismiss="modal" onclick="view_question(&#39;'+data.msg[i+1]+'&#39;,&#39;'+data.msg[i+5]+'&#39;,&#39;'+data.msg[i+4]+'{'+data.msg[i+3]+'}'+'&#39;)"  data-target="#questview"><i class="fa fa-question-circle"></i></button>'
+'</td>'+'<td><button type="button" class="btn btn-danger" onclick="delete_set(&#39;'+data.msg[i+1]+'&#39;)" ><i class="fa fa-trash"></i></button>'
+'</td>' +'</tr>');
i=i+8;}
	$('#setsave').html('<button class="btn btn-primary" onclick="saveset(&#39;'+data.id+'&#39;)">save</button>');	
}
}

});
		
            }
            else{
		//alert(data.msg);
	 }
          }
        }
              );
}
    });
  });

</script>

<script>







function editset(setid){
//alert(setid);
$.ajax({
	
	type:"POST",
	url:"http://localhost/dev/video-message/3/edit_set/edit.php",
	dataType: "json",
	data:{setid:setid},
	success: function(data){
	if(data.code=='200'){
	//alert(data.msg);
	//document.getElementById('testing').innerHTML = data.msg;
	document.getElementById('set_id').value = data.msg[0];
	document.getElementById('set_company').value = data.msg[1];
	document.getElementById('set_name').value = data.msg[2];
	document.getElementById('set_category').value = data.msg[3];
	document.getElementById('set_status').value = data.msg[4];

}
}
});
}
</script>
<div id="manageuser" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">            
            <div class="modal-body card-body text-left">
            <div class="card-body">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
            </button>

            <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold">Add Users To Company</h5>
            <p id="d3">Add all recruiters of your company to this list so that they can manage their recruitment process.</p><br>
            
            <link rel="stylesheet" type="text/css" href="./Employer Dashboard _ QUANTUMHUNTS_files/jquery.tagsinput.min.css">
            <script type="text/javascript" src="./Employer Dashboard _ QUANTUMHUNTS_files/jquery.tagsinput.min.js.download"></script>
            <script src="./Employer Dashboard _ QUANTUMHUNTS_files/bootstrap-tagsinput.min.js.download" integrity="sha512-9UR1ynHntZdqHnwXKTaOm1s6V9fExqejKvg5XMawEMToW4sSw+3jtLrYfZPijvnwnnE8Uol1O9BcAskoxgec+g==" crossorigin="anonymous"></script>
            <link rel="stylesheet" type="text/css" href="./Employer Dashboard _ QUANTUMHUNTS_files/styles.css">
            

            
            
            <textarea type="text" id="otherusermail" class="form-control" name="email" data-role="tagsinput" rows="4" cols="50" data-tagsinput-init="true" style="display: none;">            </textarea><div id="otherusermail_tagsinput" class="tagsinput" style="width: auto; min-height: 100px; height: 100px;"><div id="otherusermail_addTag"><input id="otherusermail_tag" value="" data-default="Enter email" style="color: rgb(102, 102, 102); width: 88px;"></div><div class="tags_clear"></div></div>
            
            <span class="text-danger" id="error"></span>
             
              <style>
            //.tagsinput {display: none;}

 #otherusermail_tag {
  width: 100px;
}
                .goodtag {
             border: solid 1px blue !important;
             background-color: #536de6 !important;
              color: white !important;
              }
             .goodtag a {
             color: #fff !important;
                }
             </style>

<script type="text/javascript">
    // setTimeout(() => {
        $("#otherusermail").tagsInput({
        'width': 'auto',
        'delimiter': ',',
        'defaultText': 'Enter email',
        
        
        onAddTag: function(item) {
    $($(".tagsinput").get(0)).find(".tag").each(function() {
      
        $(this).addClass("goodtag");
      
    });
  },
  'onChange': function(item) {
		$($(".tagsinput").get(0)).find(".tag").each(function() {
      
        $(this).addClass("goodtag");
      
    });
  }

       });

   
                
</script>


<div class="text-left">
                    <button type="button" id="add" class="btn btn-primary btn-sm mt-3" onclick="addemail()">Save</button> 
                    <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button>
                    </div></div>
                    <script>
                    function addemail(){
                    
                     var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;  
                     var other_user_mail = $("#otherusermail").val();
                     var mail=other_user_mail.split(',');
                     var l=mail.length;
                     var i=0; var j=0;
                     alert(l);
                     for(i=0;i<l;i++)
                     {
                     
                     if(mail[i] =="")
                     {
                         j=2;
                        
                    }
                     else if(mail[i] !="" && !reg.test(mail[i]))
                     {
                       j=1;
                             }}
                            
                         if(j==1)
                         
                         {
                            alert("PLEASE ENTER CORRECT EMAIL ADDRESS");
                            $("#otherusermail").focus();
                            $("#error").html("PLEASE ENTER CORRECT EMAIL ADDRESS");
                        }

                     else{     
                        // alert(other_user_mail);
                        console.log(other_user_mail);
                        var company_name = document.getElementById('d1').textContent;
                                               
                        $.ajax({
                        type:"POST",
                        url:"http://localhost/dev/video-record/3/user_mail.php/",
                        dataType: "json",
  	                    data:{company_name:company_name,other_user_mail:other_user_mail},                        
                        success:function(data){
                        console.log(data);
                        if(data.status == 'ok'){
                       
                        console.log(data.num);
                        alert("Insert success");
                        if((data.num > l) || (data.num < l))
                        {
                        console.log("increaseordecrseinmail");
                        $.ajax({
                        type:"POST",
                        url:"http://localhost/dev/video-record/3/send_mail.php/",
                        dataType: "json",  
                        data:{name:"sreelekha",email:"sreelekhabiswasm15@gmail.com"},                                   
                        success:function(data){
                        console.log(data);
                        if(data.status == 'ok')
                           {console.log(data.msg);
                           console.log("emailworking");}
                        else
                        {console.log(data.msg); }                          
                                            }
                              });
                        }
                        else
                        {console.log("nochangeinnumber");}
                        }
                        else if(data.status == 'okay'){
                        alert(data.msg);
                        $("#error").html(data.msg);
                        }
                        else{
                        alert(data.msg);
                        console.log('here');
                        alert("insert unsuccessful");
                        }
                        },
                        error: function (jqXhr, textStatus, errorMessage) { 
                            console.log(jqXhr);
                            console.log(jqXhr.responseText);
                            console.log(textStatus,errorMessage);
                                                                      }
                        }); 
                        
                     }   
                    }                       
                    </script>


                        


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

 

<script>
console.log(2928);


   $(document).ready(function() {
   console.log(2928);
   
   //console.log('user_d',user_id)
    $.ajax({
      type:"POST",
      url:"http://localhost/dev/video-record/3/company_check.php/",
      dataType: "json",
      success:function(data){
     // console.log("company check",data);
      if(data.code == "200"){
         console.log(data.msg);
         console.log(data.id);
         $("#create").show(); 
         $("#aboutcompany").show();    
         $("#company").show();    
         $("#companyname").show();            
         $("#companynamesubmit").show();
         $("#ManageUser").hide();
         $("#ManageSet").hide(); 
      }
      else if(data.code == "400"){
         console.log(data.msg);
         console.log(data.id); 
         $("#create").hide();  
         $("#aboutcompany").hide();    
         $("#company").show();       
         $("#companyname").hide();
         $("#companynamesubmit").hide();  
         $("#ManageUser").show();
         $("#ManageSet").show();   
         $("#d1").html(data.msg);
      }
      else if(data.code == "600"){
         console.log(data.msg);
         console.log(data.id);
         console.log(data.com);
         $("#create").hide();
         $("#aboutcompany").hide();    
         $("#company").show();  
         $("#companyname").hide();
         $("#companynamesubmit").hide();  
         $("#ManageUser").hide();
         $("#ManageSet").show();   
         $("#d1").html(data.msg);
      }
      else {
         console.log(data.msg);
         console.log(data.id);
         $("#create").hide();
         $("#aboutcompany").hide();    
         $("#company").hide();  
         $("#companyname").hide();
         $("#companynamesubmit").hide();  
         $("#ManageUser").hide();
         $("#ManageSet").hide();   
        // $("#d1").html(data.msg);
      }
         
      },
      error: function (jqXhr, textStatus, errorMessage) { 
      console.log(jqXhr);
      console.log(jqXhr.responseText);
      console.log(textStatus,errorMessage);             }
   });   
});
</script>

<script>
var user_id = '2928';
   $("#companynamesubmit").click( function() {  
    var company_name = $("#companyname").val();
       if(company_name =="")
      {
          $("#companyname").focus();
          }

     else{
      console.log("company_name",company_name);
      $.ajax({
      type:"POST",
      url:"http://localhost/dev/video-record/3/insert_company.php/",
      dataType: "json",
  	   data:{company_name:company_name,company_createby: user_id},
      success:function(data){
         console.log(data)
      if(data.status == 'ok')
      {   
         
      // alert(data.msg);
         console.log(data.msg);
         $("#create").hide();
         $("#aboutcompany").hide();
         $("#aboutcompany").hide();    
         $("#company").show();  
         $("#companyname").hide();
         $("#companynamesubmit").hide();
         $("#d1").html(company_name);  
     
         $("#ManageSet").show();
         $("#ManageUser").show();
      }

      else
      {
         console.log(data.msg);
         console.log("insertion unsuccessfull");
         //$("#d1").html(data.msg);  
         $("#create").show();                
         $("#aboutcompany").show();    
         $("#company").show();   
         $("#companyname").show();
         $("#companynamesubmit").show();	
      }
},
error: function (jqXhr, textStatus, errorMessage) { 
      console.log(jqXhr);
      console.log(jqXhr.responseText);
      console.log(textStatus,errorMessage);
    }

 });

   }
  });
  </script>

<script>

function open_user()
{ 
var x = document.getElementById('d1').textContent;
console.log(x);
$.ajax({
   type:"POST",
   url:"http://localhost/dev/video-record/3/add_mail.php/",
   dataType: "json",
   data:{company_name:x},
   success:function(data){
   if(data.status == 'ok'){
     // alert(data.msg); 
   console.log(data.msg);   
 
$("#otherusermail_tag").val(data.msg);

     //  $("#otherusermail").show();
   $('#manageuser').modal('show');     
  
   
   }
   else{
   console.log(data.msg);
   }
   },
error: function (jqXhr, textStatus, errorMessage) { 
      console.log(jqXhr);
      console.log(jqXhr.responseText);
      console.log(textStatus,errorMessage);
    }
   });
 }

 </script> 


 
 
                                <div class="card border cta-box">
                                    <div class="card-body">

                                     <div class="text-center mb-3">
                                     <img src="./Employer Dashboard _ QUANTUMHUNTS_files/2910803.svg" height="40">
                                     </div>
                                        
                                    <h5 class="m-0 mb-2 font-weight-bold cta-box-title1 text-left text-dark text-uppercase blogmini">Upskill yourself</h5>    
                                    <p class="">If you are looking for skill development or resume upgrade, please click below. We'll connect you to <span class="text-dark text-uppercase font-weight-bold font-12">QUANTUMHUNTS</span> HR Buddies.</p>
                                    <button type="button" class="btn btn-sm btn-outline-primary" data-toggle="modal" data-target="#help-modal">Contact </button>

                                    </div>
                                </div>    


<div class="card border cta-box">
                                    <div class="card-body">
                                     <div class="text-center"> <!--<i class="h2 mdi mdi-email-outline text-dark text-primary"></i>-->
                                     <img src="./Employer Dashboard _ QUANTUMHUNTS_files/mail_qh.png" height="64">
                                    <h5 class="m-0 font-weight-bold cta-box-title1 text-left text-dark text-uppercase mb-2 blogmini">Subscribe to Bytes</h5>    
                                    <p class="text-left">Get special offers on the latest developments from our QUANTUM-Bytes.</p>
                                    <div class="form-group text-left" id="subsform">

                                    <input class="form-control form-control-sm mt-1" name="subsemail" id="subsemail">
                                    <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="btn-subscribe"> Subscribe</button>
                                     
                                    </div>
                                    <div class="display-error  alert alert-danger subs-error" style="display: none">
                                    </div>
                                    <div class="display-success  alert alert-info subs-success" style="display: none">
                                    </div>                                    

                                    </div>
                                    </div>
</div>







  <!-- include Google hosted jQuery Library -->
<script src="./Employer Dashboard _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#btn-subscribe').click(function(e){
        e.preventDefault();

        var subsemail = $("#subsemail").val();
        //alert(subsemail);
        
        $.ajax({
            type: "POST",
            url: "http://localhost/user/set/subscribe/",
            dataType: "json",
            data: {email:subsemail},            
            success : function(data){
                if (data.code == "200")
                {
                    $(".subs-success").show(); 
                    $(".subs-error").hide(); 
                    $("#subsform").hide();
                    $(".subs-success").html(""+data.msg+"");
                    $(".subs-success").css("display","block");
                } 
                else {
                    //alert("Success: " +data.msg);
                    $(".subs-error").html(""+data.msg+"");
                    $(".subs-error").css("display","block");
                }
            }
        });


      });
  });
</script>






</div>

   <div class="col-xl-12 col-lg-12">




                                

                        
                            </div>    
                                        
                                
                            </div> 
                                                               
                            </div><!-- end col-->

                        </div>
    
    
    
    

    
    




<script>
    $(document).ready(function () {
        $('#location').typeahead({
            source: function (query, result) {
                $.ajax({
                    url: "http://localhost/user/get/locations/",
					data: 'query=' + query,            
                    dataType: "json",
                    type: "POST",
                    success: function (data) {
						result($.map(data, function (item) {
							return item;
                        }));
                    }
                });
            }
        });
    });
</script>


























<!--
                
<div class="card border shadow"  style="padding-top:0px;"> -->  
<div class="card-body1 p-2 pt-0 " style="margin-top:0px;padding-top">
    
                          
                            
                            
                            
 


                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
           <div class="row">                 

                            <div class="col-xl-12 col-lg-12">
                                

  <!-- include Google hosted jQuery Library -->
<script src="./Employer Dashboard _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

<!--<h5 class="text-uppercase font-8 mb-0 text-secondary">Search Jobs</h5>-->

                                                    




<script>
function searchFilter(page_num) 
{
   // alert("hello");
    page_num = page_num?page_num:0;
    var skills = $('#skills').val();
    var location=$('#location').val();    
    var sort = $('#sort').val();
    var reviewstatus = $('#reviewstatus').val();    

    $.ajax({
        type: 'POST',
        url: 'http://localhost/user/get/jobs-employer/',
        data:'page='+page_num+'&skills='+skills+'&sortBy='+sort+'&location='+location+'&reviewstatus='+reviewstatus,
        beforeSend: function () 
        {
            $('.loading-overlay').show();
            //$('.loading-overlay').hide();
            
        },
        success: function (html) 
        {
            //alert("Employer Results are displayed");
            $('#posts_content').html(html);
            $('.loading-overlay').fadeOut("slow");
           // $('body,html').animate({scrollTop: 0}, 600);
        }
    });
}
</script>


	   
 <script src="./Employer Dashboard _ QUANTUMHUNTS_files/jquery.min.js.download"></script>

<script>
function openjob(jobid)
{
    //$('#eachjob').modal('hide');
    $.ajax({
        type: 'POST',
        url: 'http://localhost/user/get/this-job-json/',
        data:'jobid='+jobid,
        beforeSend: function () 
        {
            $('.loading-overlay').show();
            //$('.loading-overlay').hide();
            
        },
        success: function (data) 
        {
            var obj= $.parseJSON(data)
            //alert("Employer jobs Results are displayed");
            //$('#posts_content').html(obj);
            $('.loading-overlay').fadeOut("slow");
           // $('body,html').animate({scrollTop: 0}, 600);
           $('#modalviewlink1').attr("href", obj.viewslug);
           //alert(obj.postedon);
           $('#modaleditlink1').attr("href", obj.editslug);    
            $('#postedon').html(obj.postedon);   
            $('#modaljobtitle').html(obj.postedcompanyname);
            $('#reviewcomments').html(obj.postedreviewcomments);
            $('#thisvisibility').html(obj.job_visibility);
            $('#thisreviewstatus').html(obj.job_review);
            $('#modalplan').html(obj.job_plan);
            $('#modaldesc').html(obj.job_modal_desc);
            $('#modaljobidspan').html(obj.job_jobid);
            $('#eachjob').modal('show');
        }
    });
    
    
}
</script>



<script>
function upgrade(upgradejobid,option)
{
    alert("Hi");
    //$('#eachjob').modal('hide');
    $.ajax({
        type: 'POST',
        url: 'http://localhost/user/set/job-upgrade1/',
        data:'jobid='suppliedjobid+',option='+option,
        beforeSend: function () 
        {
            alert("Hi");
            $('.loading-overlay').show();
            //$('.loading-overlay').hide();
            
        },
        success: function (data) 
        {
            var obj= $.parseJSON(data)
            //alert("Employer jobs Results are displayed");
            //$('#posts_content').html(obj);
            $('.loading-overlay').fadeOut("slow");

           // $('body,html').animate({scrollTop: 0}, 600);
           $('#modalviewlink').attr("href", obj.viewslug);
           $('#modaleditlink').attr("href", obj.editslug);    
           //$('#modalviewlink1').attr("href", obj.viewslug);
           //$('#modaleditlink1').attr("href", obj.editslug);    

            $('#postedon').html(obj.postedon);   
            $('#modaljobtitle').html(obj.postedcompanyname);
            $('#reviewcomments').html(obj.postedreviewcomments);
            $('#thisvisibility').html(obj.job_visibility);
            $('#thismodaljobid').html(obj.job_modal_job_id);
            
            $('#eachjob').modal('show');
        }
    });
    
    
}


</script>


<script>

function basic()
{
    alert("Hello");
  var upgradejobid=$('#thismodaljobid').val;
  var opt="Basic";
  upgrade(upgradejobid,opt);    
}

$("#basic").click(basic);
</script>





<!-- Modal -->
<div class="modal fade" id="eachjob" tabindex="-1" role="dialog" aria-labelledby="eachjobtitle" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
    <div class="modal-content border-5">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <div class="rounded p-2 mb-1">
                                                    <div class="media auto-mx">
                                                        <img class="mr-3 rounded-circle1" src="./Employer Dashboard _ QUANTUMHUNTS_files/square1_qh.png" alt="icon" height="48" width="48">
                                                        <div class="media-body">
                                                            <h4 class="text-left text-dark">Manage Job</h4>
                                                            <h6 class="mb-1 font-weight-bold text-left text-uppercase text-primary purpletitle blogmini"><span id="modaljobtitle"></span></h6>
                                                            <p class="text-muted m-0 p-0"> (<a id="modalviewlink1" class="font-weight-light text-muted" href="http://localhost/employer/jobs/"> View</a> / <a id="modaleditlink1" class="font-weight-light text-muted" href="http://localhost/employer/jobs/"> Edit</a>)</p>
                                                            <hr class="">

                                                            <h5 class="modal-title mb-1 text-dark" id="eachjobtitle">   </h5>
                                                            <strong class="d-block">Job Description</strong>
                                                            <p id="modaldesc"> </p>                         
                                                            
                                                            
                                                            <strong class="d-block">Job Information</strong>
                                                            <table width="100%" class="">
                                                                <tbody><tr>
                                                                    <td><span>Visibiliy</span></td>
                                                                    <td><span class="text-muted" id="thisvisibility"></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td><span>Current Status</span> </td>
                                                                    <td><span class="text-muted" id="thisreviewstatus"></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td><span>Posted on</span></td>
                                                                    <td><span class="text-muted" id="postedon"></span>  </td>
                                                                </tr>
                                                            </tbody></table>
                                                            

                                                                
                                                            <span id="reviewcomments" class=" text-danger"></span>
                                                            
                                                            <span id="thismodaljobid" class="hidden"></span>
                                                            <hr class="">
                                                                
                                                                    
        
        
        <div class="row">
            <div class="col-12 col-sm-6">
                <span class="mr-2"><span class="mb-0 font-weight-bold text-left text-uppercase text-primary mr-1 purpletitle">Current Plan:</span> <span class="purpletitle" id="modalplan"></span> </span>
            </div>
            <div class="col-12 col-sm-6">
             <span><span class="float-right float-sm-left mr-1 mb-0 font-weight-bold text-left text-uppercase text-primary mr-1 purpletitle">Recommendation :</span> <span class="purpletitle">Recruiter</span>  </span>
            </div>            
        </div>
        
        <p>&nbsp;</p>
        
        <div class="text-left mt-2">        
        <a class="btn btn-sm btn-primary " href="https://www.payumoney.com/paybypayumoney/#/C17073CD713683C3AEE36D728E45E3B2">Upgrade</a>
        </div>                                                            

  


<!--  <a class="btn btn-primary btn-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Current Plan: <span id="modalplan"></span> 
  </a>


  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item"  id="Basic">Basic</a>
    <a class="dropdown-item" id="Recruiter">Recruiter</a>
    <a class="dropdown-item" id="Advanced">Advanced</a>
  </div>
-->  

  

   

                                                        </div>
                                                    </div>

    
        </div>
      </div>
    </div>
  </div>
</div>






<script>
document.getElementById("Recruiter").addEventListener("click", function() 
{
  var upgradejobid=$('#thismodaljobid').val;
  var opt="Recruiter";
  upgrade(upgradejobid,opt);
});
</script>



<script>
document.getElementById("Advanced").addEventListener("click", function() 
{
  var upgradejobid=$('#thismodaljobid').val;
  var opt="Advanced";
  upgrade(upgradejobid,opt);
});
</script>		
 


<style>

.loading-overlay 
{
display: none;
}
    
</style>



            
            
          
</div>
</div>





<!--
                </div> -->
                </div>
                            
    
    
    

    
    
    
    
    
    
    
    
                                       
                                    
                            </div> <!-- end col -->
                        </div>
                        <!-- end row-->
                        
                        
   
                            
    
                        
                        
                    </div> <!-- End Content -->


                 
                

            </div> <!-- end wrapper-->
        </div>
        <!-- END Container -->






<!-- Signup modal-->

<div id="help-modal" class="modal fade" tabindex="1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="background-image1: radial-gradient( circle farthest-corner at 18.7% 37.8%,  rgba(250,250,250,1) 0%, rgba(225,234,238,1) 90% );">

            <div class="modal-body">
                <div class="text-center mt-2 mb-0">
                    
                    <span class="text-success">
                        <span><img src="./Employer Dashboard _ QUANTUMHUNTS_files/square1_qh.png" alt="" height="32" width="32"></span>
                    </span>
                </div>
                
                <div class="card-body text-center">

                    <strong class="text-center text-primary blogmini">QUANTUMHUNTS</strong>
                    <span class="d-block text-center mb-2"> Help &amp; Support</span>

                <div class="row auto-mx float-center text-center"> 
                <div class="col-2">
                </div>
                <div class="col-8">
                <p class="text-center mb-2">Use the below form to reach us for any request or enquires. Average response time less than 24 hours.</p>
                </div>
                <div class="col-2">
                </div>
                </div>

                </div>

                <form class="pl-3 pr-3" id="callbackform" action="http://localhost/employer/jobs/#">
                    
                    
                    
<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input class="form-control form-control-sm" type="name" id="name" required="" placeholder="" value="Test Employer Test Employer">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="company">Company</label>
                        <input class="form-control form-control-sm" type="text" id="companyname" required="" placeholder="">
                    </div>
</div> <!-- end col -->
</div>                    


<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input class="form-control form-control-sm" type="phone" required="" id="phone" value="India +91 ">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">E-Mail</label>
                        <input class="form-control form-control-sm" type="email" required="" id="email" placeholder="" value="tanishsun@hotmail.com">
                    </div>
</div> <!-- end col -->
</div>                    
                    
                    



<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="reason">Subject</label>
                        <select class="form-control form-control-sm" id="reason">
                        <option value="Mentorship">Career development</option>  
                        <option value="Courses">Courses</option>              
                        <option value="Business">Business Enquiry</option>
                        <option value="QH-RECRUITER">Premium Plans</option>                 
                        <option value="Help">Help</option>                
                        <option value="AccountIssues">My QH account</option>                        
                        <option value="Issues">Issues &amp; Complaints</option>                                                
                        </select>                        
                    </div>                    

</div>
</div>          





<div class="row">
<div class="col-md-12">
                    <div class="form-group">
                        <label for="comments">Comments</label>
                        <textarea class="form-control" id="comments" placeholder=""></textarea>
                    </div>                    
</div> <!-- end col -->
</div>          





                    


    
                    <div class="form-group text-left">
                                <div class="display-callback-error  alert alert-danger" style="display: none">
                                </div>

                        <button class="btn btn-primary" type="submit" id="callbacksubmit">Submit </button>
                        <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                    </div>
                    
                    
                    <small>By clicking "Submit" I agree to be contacted at the number provided with more information or offers about <span class="text-uppercase text-primary">QuantumHunts</span>. I understand these calls or texts may use computer-assisted dialing or pre-recorded messages.</small>

                </form>
                
                <div class="form-group">  
                                <div class="display-callback-success  alert alert-info" style="display: none">
                                   
                                </div>
                </div>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->









  <!-- include Google hosted jQuery Library -->
<script src="./Employer Dashboard _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#callbacksubmit').click(function(e){
        e.preventDefault();

    var usertype = $('input[name=customRadio1]:checked').val();
        //alert(usertype);

        var pageurl="http://localhost/employer/jobs/";
        var email = $("#email").val();
        var phone = $("#phone").val();        
        var name = $("#name").val();
        var company = $("#companyname").val();
        var reason =$('#reason option:selected').val();
        var comments = $("#comments").val(); 
        //var comments = "";
        
        //alert(email+name+phone+reason+comments+company);
        
        $.ajax({
            type: "POST",
            url: "http://localhost/user/set/callbacks/",
            dataType: "json",
            data: {name:name,email:email,phone:phone,company:company,reason:reason,comments:comments,pageurl:pageurl},            
            success : function(data){
                if (data.code == "200")
                {
                    $(".display-callback-success").show(); 
                    $(".display-callback-error").hide(); 
                    $("#callbackform").hide();
                    $(".display-callback-success").html(""+data.msg+"");
                    $(".display-callback-success").css("display","block");
                } 
                else {
                    //alert("Success: " +data.msg);
                    $(".display-callback-error").html(""+data.msg+"");
                    $(".display-callback-error").css("display","block");
                }
            }
        });


      });
  });
</script>



</div><tester id="otherusermail_tag_autosize_tester" style="position: absolute; top: -9999px; left: -9999px; width: auto; font-size: 13px; font-family: helvetica; font-weight: 400; letter-spacing: 0px; white-space: nowrap;"></tester>


    <div id="ReferModal" class="modal " tabindex="-1" role="dialog">
      <div class="modal" tabindex="-1" role="dialog" style="padding-right: 16px; display: block;overflow-y: scroll;" aria-modal="true">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
          <div class="modal-content border-5">
            <div class="modal-body" style="overflow-y: auto;"><div class="card-body">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
              <div class="rounded mb-1 pt-0 mt-0">
		<center> <h5 class="d-block  mt-0 mb-3 text-primary text-uppercase  blogmini">📢 Invite Your Friends
                </h5></center>
		<ul class="nav nav-tabs tab-grad mt-3">
						
						<li class="nav-item "> <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" data-toggle="tab" href="http://localhost/employer/jobs/#profile1">Invite via Mail  </a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="http://localhost/employer/jobs/#home1"> Share via link</a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="http://localhost/employer/jobs/#referrals"> My Rewards</a> </li>						
					</ul>
	

<div class="tab-content">
    <div class="tab-pane show active" id="profile1">
	<br>
        <p>You can now invite your friends through mail so that they join world's 1st video centric job platform. You would get rewarded when your friends create their account with us.</p>
                <div class="media-body">
                  <!--<strong class="d-block  mt-2 text-primary text-uppercase purpletitle">Invite via Mail
                  </strong> -->
                 
                <div class="row">
                  
                  <div class="col-lg-12 col-12">
                      
                      <div class="row">
                      <div class="col-6">
                      
                    <span class="media-body mt-2">
                      <div class="form-group">
                        <label for="inputName">Name
                        </label>
                        <input type="text" class="form-control form-control-sm" id="inputName" required="" placeholder="Enter your Friend&#39;s name..">
                      </div> 
                      <div id="div1">
                      </div> 
                      <div class="alert alert-primary" id="invitenamemsg" style="display:none;">Please Enter Your Friend's Name
                      </div>
                      <div class="form-group">
                        <label for="inputEmail">Email
                        </label>
                        <input type="email" class="form-control form-control-sm" id="inputEmail" required="" placeholder="Enter your Friend&#39;s mail..">
                      </div> 
                      <div id="div2">
                      </div> 
                      <div class="alert alert-primary" id="inviteemailmsg" style="display:none;">Please Enter Your Email Id
                      </div>
                      <div class="alert alert-primary" id="invitevalidemailmsg" style="display:none;">Please Enter a Valid Email Id
                      </div>
                      <button class="btn btn-primary btn-sm" id="submit">Submit 
                      </button>
                    </span>
                    
                    </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="alert text-primary" id="invitesuccessmsg" style="display:none;">Success. Your friend will receive an email very soon.</div>
                			<div class="alert text-danger " id="invitefailuremsg" style="display:none;">Please try again. </div><p></p><br>
                            <div class="alert text-danger " id="inviteloginmsg" style="display:none;">Please login To invite your friends.
                      </div>
                        </div>
                    </div>                
                    
                    
                </div>
<div class="col-3 col-lg-4">
                  </div>
                <div class="col-3">
                </div>
                <div class="col-12">
                </div>
                </div>
            </div>
    </div>
     <div class="tab-pane" id="home1"><br>
        <p>Share this link with your friends so that they join World's 1st video resume platform. You would get rewarded when your friends create their video resume with us.</p>
	                <div class="row mt-3 mx-0">

                  <div class="col-12 col-md-5  my-auto mx-auto">
                        <div class="input-group input-group-merge">
                      <input class="form-control" type="text" value="http://localhost/?ref=tanish-sun-20210108120453" id="copybox">
                    <div class="input-group-append">
                      <button class="btn btn-primary-two btn-sm font-weight-bold text-dark" onclick="copyfunction()">Copy my link
                      </button>
                        </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-2 text-center my-auto mx-auto">
                    <p style="text-center font-size:20;">or
                    </p>
                  </div>
                  <div class="col-12 col-md-5  my-auto mx-auto">
                    <ul class="share-buttons">
                      
                      
                      <a class="mr-1" href="https://www.facebook.com/sharer/sharer.php?u=http://localhost/?ref=tanish-sun-20210108120453;" title="Share on Facebook" target="_blank" onclick="window.open(&#39;https://www.facebook.com/sharer/sharer.php?u=&#39; + http://localhost/signup/?ref=tanish-sun-20210108120453  Create a Professional Login+ &#39;&amp;quote=Apply for this opportunity&#39; ); return false;">
                        <img alt="Share on Facebook" src="./Employer Dashboard _ QUANTUMHUNTS_files/facebook.png">
                      </a>            
                      
                      
                      <a class="mr-1" href="https://twitter.com/intent/tweet?text=http://localhost/?ref=tanish-sun-20210108120453%20Create%20a%20Professional%20Login" title="Click to share this post on Twitter" "="" target="_blank" onclick="window.open(&#39;https://twitter.com/intent/tweet?text=&#39; + http://localhost/job/tanish-sun-20210108120453 + &#39;:%20&#39;  + Apply for this opportunity); return false;">
                      <img alt="Tweet" src="./Employer Dashboard _ QUANTUMHUNTS_files/twitter.png">
                      </a>

                    <a class="mr-1" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=http://localhost/?ref=tanish-sun-20210108120453;title=&amp;summary=&amp;source=" target="_blank" title="Share on LinkedIn">
			<img alt="Share on LinkedIn" src="./Employer Dashboard _ QUANTUMHUNTS_files/linkedin.png">
                      </a> 
                    </ul>
                </div>
              </div>
    
 	<div class="mt-1 mb-1">
              <br>  <br>
              </div>
              
              <div class="row mt-2 mx-0">

                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row ">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-link text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 1 
                        </h5>    
                        <p class="text-secondary font-13 mb-0 mt-0 pb-0 pt-0 px-0">Share Link with your friends   
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
              
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-user-group text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 2
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">Ask your friends to create video resume  
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mt-n3 ">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-trophy text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 3 
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">We will reward your account 
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div></div>
              
              
    <div class="tab-pane" id="referrals">
        <p class="mt-3">Here is the stats of the valid users who have signed up based on your referral. Better your own numbers by speaking about our platform to your friends and acquaintance. share your referral link today.</p>
        <div class="row">
        <div class="col-4 col-xs-12 col-sm-12 col-md-4">



<div class="card tilebox-one shadow">
                                    <div class="card-body">
                                        <i class="uil uil-users-alt float-right"></i>
                                        <h6 class="text-uppercase mt-0 blogmini text-primary">Verified Users</h6>
                                        <h2 class="my-2" id="active-users-count">0</h2>
                                        <p class="mb-0 text-muted">
                                            <span class="text-nowrap">Since signup</span>  
                                        </p>
                                    </div> <!-- end card-body-->
                                </div>



        </div>
        </div>

    </div>
              
</div>



</div>
    </div>
        </div>
      </div>
    </div>
    </div>
  <br>
  <br>
  <br>
  <br>
  <br>
  </div>
<script src="./Employer Dashboard _ QUANTUMHUNTS_files/jquery.min.js(1).download">
</script>
<script>
  function copyfunction() {
    var copyText = document.getElementById("copybox");
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
  }
  $(document).ready(function(){
    $('#submit').click(function(){
      var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
      var name = $('#inputName').val();
      var email = $('#inputEmail').val();
      if(name.trim()=='')
      {
        //document.getElementById("div1").innerHTML="Enter a value";
        //document.getElementById("div1").style.color="Red";
        $('#inputName').focus();
      }
      else if(email.trim() == '' ){
        //document.getElementById("div2").innerHTML="Enter the correct email address";
        //document.getElementById("div2").style.color="Red";
        $('#inputEmail').focus();
      }
      else if(email.trim() != '' && !reg.test(email)){
        //$("#invitevalidemailmsg").css("display","block");
        $('#inputEmail').focus();
      }
      else{
        
        $.ajax({
          type:"POST",
          url:"http://localhost/invite/send/",
          dataType: "json",
          data:{
            name:name,email:email},
          success:function(data){
            if(data.status == 'ok'){
               $("#invitesuccessmsg").css("display","block");
		$("#inviteloginmsg").hide();
		$("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitesuccessmsg").hide();
              }, 4000);              
            }
            else{ if(data.status=='error'){
             $("#inviteloginmsg").css("display","block");
	     $("#invitesuccessmsg").hide();
	     $("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitevalidemailmsg").hide();
              }, 4000);                            
              }
		else{
              $("#invitefailuremsg").css("display","block");
		$("#invitesuccessmsg").hide();
	     $("#inviteloginmsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitefailuremsg").hide();
              }, 4000);                            
            }
	 }
          }
        }
              );
      }
    }
                      );
  }
                   );
</script>



<?php
  include($root."/jobs/footer.php");
?>