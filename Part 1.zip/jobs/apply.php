<?php
session_start();
$cid=$_POST['a'];
$jid=$_POST['b'];
$cname=$_POST['cname'];
$jname=$_POST['jname'];
$uname=$_POST['uname'];
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$dd=date("Y-m-d");
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
$sql2 = "INSERT into vj_applications(application_job_id,application_user_id,application_time,application_company,application_job_name,application_user_name) values('$jid','$cid','$dd','$cname','$jname','$uname')";
    if ($conn->query($sql2) === TRUE) {
   
    }
echo json_encode(['code'=>200, 'msg'=>' You have applied for this job.']);
$conn->close(); 
exit;
?>