<?php
session_start();
$flow="1";

$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
 $code=200;
 $empty=array();
 $interview_id = $_POST["interview_id2"];
 $full_id = $_POST["fullid"];
 $count_id = count($full_id);
 $set_id = '';
 $start='';
 $end='';
 $company='';
 $error=0;
 $y = '';
 $fid = 3;
 $errorid='';
 $error2 = 0;
if($flow=="1")
{   
    $root=$_SERVER["DOCUMENT_ROOT"];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
for($x=0;$x<$count_id;$x++){
    $y = $full_id[$x];
    $sql2 = "SELECT * FROM vj_interviews WHERE interview_id='$y'";
    $result2 = $conn->query($sql2);
    if ($result2->num_rows > 0) {
        // output data of each row
       
        while($row = $result2->fetch_assoc()) {
            $tmmp = $row['interview_actual_start_date'];
            $tmmp1 = $row['interview_actual_end_date'];
            if ($interview_id==$y){
                $application_id2 = $row["interview_appid"];
                             
      $job_title=$row['interview_job'];
          $company_title=$row['interview_company'];        
      $set_id = $row['interview_ref'];
                $start = $row['interview_schedule_start_date'];
                $end = $row['interview_schedule_end_date'];
                $company = $row['interview_created_by'];
                $subject=$row['interview_subject'];
            }
            if ($error!=1){
            if($tmmp==""){
                $error = 0;
            }
            else{
                if ($tmmp!="" and $interview_id==$y){
                    if ($tmmp1!="" and $interview_id==$y){
                        $error2 = 3;
                        $fid = $y;
                        break;
                    }
                 }
                else{
                    if($tmmp!=="" and $tmmp1==""){
                        $error = 1;
                        $errorid = $y;
                        break;
                    }
                    }
               
            }
        }
        }
    }        
}
$total=0;
if ($error==1){
    echo json_encode(['code'=>400, 'error'=>$error, 'idd'=>$errorid]);
    $conn->close(); 
    exit;
}
else  {  	
    $sql = "SELECT question_question,question_time FROM vj_questions WHERE question_set_id='$set_id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
    
    $statuss="success";
// output data of each row
        while($row = $result->fetch_assoc()) 
        {
            array_push($empty, $row['question_question']);
            $total+=$row['question_time'];
            array_push($empty, $row['question_time']);
    
        }
    }
        echo json_encode(['code'=>200, 'subject'=>$subject, 'total'=>$total, 'set'=>$set_id, 'full'=>$full_id, 'company_title'=>$company_title, 'job_title'=>$job_title, 'cc'=>$count_id, 'error'=>$error2, 'fid'=>$fid, 'start'=>$start, 'end'=>$end]);
        $conn->close(); 
        exit;
    }
}







?>



