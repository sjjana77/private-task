<?php
session_start();
$flow="1";
$root=$_SERVER["DOCUMENT_ROOT"];
$iddd=$_SESSION['candidate_id'];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
if($flow=="1")
{  
    $aa=array(); 
    $sql = "SELECT * FROM vj_interviews WHERE interview_user_id='$iddd'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $r=$result->num_rows;
        while($row = $result->fetch_assoc()) {
            if($row['interview_actual_start_date']!="" and $row['interview_actual_end_date']==""){
                $r=9;
                    array_push($aa,$row['interview_id']);
            
        }
    }
}
for($x=0;$x<count($aa);$x++){
    $y=$aa[$x];
    $sql2 = "UPDATE vj_interviews SET interview_actual_end_date='-' WHERE interview_id='$y'";
    if ($conn->query($sql2) === TRUE) {
   
    }
}
        echo json_encode(['code'=>200,'a'=>$r]);
        $conn->close(); 
    	exit;
}
?>