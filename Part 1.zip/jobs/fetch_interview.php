<script type="text/javascript">
var no_of_interviews;
var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function dateFormat(d){
   var t = new Date(d);
 return t.getDate()+'-'+monthNames[t.getMonth()]+'-'+t.getFullYear();
}                             
  var today = Date("j-M-Y, H:i");
  var starting_date = dateFormat(today) +" "+ today.substring(16,25);
</script>
<?php

/*if($_SESSION["no_of_interviews"]!=NULL){
$_SESSION["no_of_interviews"] = "0";  }
else{
  $_SESSION["no_of_interviews"] = "1";
}  */
$root=$_SERVER["DOCUMENT_ROOT"];
include($root."/jobs/record_modal.php");
include($root."/jobs/progress.php");
include($root."/jobs/meet.php");
$conn = mysqli_connect('localhost', 'root', '', 'project');
$interviewid=array();
$monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
$ty =  date("m")-1;
$current_time = date("m/d/Y");     //it contains current time with required format
$fullid=array();
//stime=array();
//$etime=array();
$company_title=array();
$job_title=array();
$subject=array();
$meet_company=array();
$meet_job=array();
$iddd=$_SESSION['candidate_id'];  //hardcode $_SESSION['user_id']
$meet=array();
$meet_type=array();
$meet_subject=array();
//$this_app_user_id
//$this_app_id
//$sq="UPDATE qh_interviews SET interview_appid='705' WHERE interview_user_id='$iddd'";
//if ($conn->query($sq) === TRUE) {}
$sql1 = "SELECT * FROM vj_interviews WHERE interview_user_id='$iddd'"; //hardcode interview_user_id
$no_of_available_interviews=0;
$result1 = $conn->query($sql1);
if ($result1->num_rows > 0) {
  // output data of each row
  while($row = $result1->fetch_assoc()) {
    array_push($fullid, $row['interview_id']); 
    if ($row['interview_actual_start_date']==""){   //taking interview ids by checking their actual start is empty
      if(strtotime($row['interview_schedule_start_date'])<=strtotime($current_time)){  //checking schedule start date less than current date
        if(strtotime($current_time)<=strtotime($row['interview_schedule_end_date'])){  //checking current date less than schedule end date
    $no_of_available_interviews+=1;     
    if($row['interview_type']=="virtual"){ 

      array_push($subject, $row['interview_subject']);                                                                 //Counting the no of interview ids
    array_push($interviewid, $row['interview_id']);
    //array_push($stime, $row['interview_schedule_start_date']);
    //array_push($etime, $row['interview_schedule_end_date']);

          array_push($company_title, $row["interview_company"]);
          array_push($job_title, $row["interview_job"]);//company name, job title
                             
           }
   else{
    array_push($meet_type, $row["interview_type"]);
    array_push($meet, $row['interview_id']);
    array_push($meet_company, $row["interview_company"]);
    array_push($meet_job, $row["interview_job"]); 
    if($row["interview_ref"]!=""){  
    array_push($meet_subject, "Link Given"); }                           
      
   } 
   
  }
}                                    
  }
   
  }
}
?>


<script type="text/javascript"> 
<?php  //if($no_of_available_interviews>=1){
//    if($no_of_available_interviews>=1 && $_SESSION["no_of_interviews"] == "1"){
?>
//$("#ReferModal22").modal();
<?php //}
?>
var interview_id = new Array();
    <?php foreach($interviewid as $key => $val){ ?>
      interview_id.push('<?php echo $val; ?>');
    <?php } ?> 
var full_id = new Array();
    <?php foreach($fullid as $key => $val){ ?>
        full_id.push('<?php echo $val; ?>');
    <?php } ?>    
var lk =0;
var total=0;
var sett_id = '';
var set_no = '';


//let nm=interview_idd.length;


//for(let k=0;k<nm;k++){

  //document.write('<div class="card border cta-box"><div class="card-body"> <button type="button" id='+interview_idd[k]+' class="btn btn-primary interview"><i class="uil uil-tv-retro"></i>'+' Interview '+interview_idd[k]+'</button></div></div>');
 
 //var btn3 = document.createElement("button");
 // btn3.innerHTML = "interview "+interview_idd[k];
 // $("#inter").append(btn3);
   // $(".interview:first").addClass("btn-primary");
  // $(".interview:first").addClass("btn");
 /* 
 var btn = document.createElement("BUTTON");
  btn.id = interview_id[k];
  btn.innerHTML = "Interview "+interview_id[k];
  document.body.appendChild(btn);
  document.write('</div></div>');
  document.getElementById(interview_id[k]).className = "interview"; */
//}

</script>
<div class="card border cta-box"><div class="card-body">
<h5 class="m-0 font-weight-bold cta-box-title1 text-left text-dark mb-2 text-uppercase blogmini font-12">My interviews</h5>
<!-- test -->
<div class="inbox-widget">
<!--<table class="table-bordered table-striped table-sm table-responsive mb-0" style="font-size:2.0rem;"> -->
<?php 

for($x=0;$x<count($interviewid);$x++){
?><a id="<?php echo $interviewid[$x]; ?>" class="interview" style="cursor: pointer;"> 
<div class="inbox-item">

                                               <div class="inbox-item-img"><img src="https://quantumhunts.com/dev/video-message/2/images/virtual.png" class="rounded-circle" alt=""></div>
                                                <p class="inbox-item-author"><?php echo $company_title[$x]; ?></p>
                                                <p class="inbox-item-text"><?php echo $job_title[$x]."<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Re: ".$subject[$x]; ?></p>
                                            </div> </a>
<!--<tr style="font-size:0.9rem;"><td>-->   

<?php //echo $company_title[$x]."<br>".$job_title[$x]; ?>  <!--</td><td>  -->
<!--<button class="btn btn-primary interview" type="button" id="<?php //echo $interviewid[$x]; ?>"><i class="uil uil-tv-retro"></i>Attend</button>
</td></tr>-->
<?php }
?>
<?php 
$imgg_url = "https://quantumhunts.com/dev/video-message/2/images/";
for($y=0;$y<count($meet);$y++){
    if($meet_type[$y]=="Google Meet"){
      $img_url = $imgg_url."meet.png";
    }
    else if($meet_type[$y]=="Zoom"){
      $img_url = $imgg_url."zoom.png";
    }
    else if($meet_type[$y]=="Hangouts"){
      $img_url = $imgg_url."hangouts.png";
    }
    else if($meet_type[$y]=="Webex"){
      $img_url = $imgg_url."webex.png";
    }
    else{
      $img_url = $imgg_url."face_to_face.png";
    }
  ?>
  <a id="<?php echo $meet[$y]; ?>" class="interview"> 
<div class="inbox-item">
                                                <div class="inbox-item-img"><img src="<?php echo $img_url; ?>" class="rounded-circle" alt=""></div>
                                                <p class="inbox-item-author"><?php echo $meet_company[$y]; ?></p>
                                                <p class="inbox-item-text"><?php echo $meet_job[$y]."<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$meet_subject[$y]; ?></p>
                                            </div> </a>
<!--<tr style="font-size:0.9rem;"><td>-->

<?php //echo $company_title[$x]."<br>".$job_title[$x]; ?>  <!--</td><td>  -->
<!--<button class="btn btn-primary interview" type="button" id="<?php //echo $interviewid[$x]; ?>"><i class="uil uil-tv-retro"></i>Attend</button>
</td></tr>-->
<?php }
?>
<!--</table> -->
</div>
</div></div>
<style>
  .interview{
    cursor: pointer;
  }
</style>
<script type="text/javascript">
var total2;
var total;
$(document).ready(function(){
  $(".interview").click(function(){
    sett_id = this.id;
    clicked_id2 = this.id;
    var id_of_interview = interview_id.includes(sett_id);
    if(id_of_interview==true)
    {
    $.ajax({
          url: "http://localhost/jobs/check.php",
          type: "POST",
          dataType: "json",
          data: {interview_id2:clicked_id2,fullid:full_id},
          success : function(data){
          
              if (data.code == "400")
              {
               
                if(clicked_id2==data.idd){
                  $("#border").css({"border-width": "0px"});
                  $("#resume-record").modal();
                }
                else{
                  $("#border").css({"border-width": "35px"});
                  $("#resume-record2").modal();
                }
              }
              if (data.code == "200")
              {
               if (data.error=="3")
               {
                  if(clicked_id2==data.fid){
                    $("#ins").hide();
                    $("#border").css({"border-width": "35px"});
                    document.getElementById('msgleft').innerHTML = "";
                    $("#completeButton").hide();
                    $("#inss").hide();
                    $("#completeButton2").show();
                    $("#displayButton").hide();
                    $("#startButton").hide();
                    $("#resume-record").modal();
                  }
               }
               else{
               document.getElementById('interviewid').innerHTML = "Interview id: "+clicked_id2;
               document.getElementById('interviewcompany').innerHTML = "Company: "+data.company_title;
               document.getElementById('interviewjob').innerHTML = "Job: "+data.job_title;
               document.getElementById('interviewsubject').innerHTML = "Subject: "+data.subject;
               document.getElementById('interviewend').innerHTML = "Complete Before: "+data.end;
                set_no = data.set;
                total = 0;
                total = data.total*60*1000;
                total2=data.total;
                if(lk==1){
                  $("#completeButton2").hide();
                  $("#ins").show();
                  $("#border").css({"border-width": "0px"});
                  //document.getElementById('msgleft').innerHTML = "You can now attend our interview publish to recruiters.";
                  $("#resume-record").modal();
                $("#completeButton").hide();
                $("#wait").hide();
                $("#preview").show();
                $("#startButton").show();
                $("#recordingwait").show();
                $("#next").show();   
                
                }
                else{
                  //document.getElementById('msgleft').innerHTML = "You can now attend our interview publish to recruiters.";
                  $("#border").css({"border-width": "0px"});
                  $("#resume-record").modal();
                }
              }
              }
          }
        }); 
    }
    else{
      $.ajax({
          url: "http://localhost/jobs/meet_check.php",
          type: "POST",
          dataType: "json",
          data: {interview_id2:clicked_id2},
          success : function(data){
          
              if (data.code == "200")
              {
                document.getElementById('interviewid_meet').innerHTML = "Interview id: "+clicked_id2;
               document.getElementById('interviewcompanym').innerHTML = "Company: "+data.company;
               document.getElementById('interviewjobm').innerHTML = "Job: "+data.job;
               document.getElementById('interviewendm').innerHTML = "Date: "+data.end;
               document.getElementById('type').innerHTML = "Type: "+data.type;
               document.getElementById('locationm').innerHTML = "";
               document.getElementById('interviewlink').innerHTML = "Link: "+data.location;
               document.getElementById('sstime').innerHTML = "Start Time: "+data.sstime;
               document.getElementById('eetime').innerHTML = "End Time: "+data.eetime;
               if(data.type=="Face to Face"){
                document.getElementById('locationm').innerHTML = "Address: "+data.location;
               }
                $("#meet").modal();
              }
            }
        });        
    }
  });
});
</script>
<!-- Signup modal-->

<div id="no_interview" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-left">


                        <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold"> You have been scheduled for <?php if($no_of_available_interviews>1){ echo "$no_of_available_interviews interviews"; } else{ echo "$no_of_available_interviews interview"; } ?> to attend</h5> 


                        <p class="text-center mt-3">
                        <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button>    	                                                           
                        </p>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

 <!-- Modal content -->
 <div id="ReferModal22" class="modal" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">
      <div class="modal" tabindex="-1" role="dialog" style="padding-right: 16px; display: block;overflow-y: scroll;" aria-modal="true">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
          <div class="modal-content border-5">
            <div class="modal-body" style="overflow-y: auto;"><div class="card-body">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
              <div class="rounded mb-1 pt-0 mt-0">
		<center> <h5 class="d-block  mt-0 mb-3 text-primary text-uppercase  blogmini">📢 Interview Invite
                </h5></center>
		<ul class="nav nav-tabs tab-grad mt-3">
						
						<li class="nav-item "> <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" data-toggle="tab" href="#profile11">Interviews  </a> </li>

						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" target="_blank" href="https://quantumhunts.com/user/view/jobs/"> Applied Jobs</a> </li>						
					</ul>
	

<div class="tab-content">
  <!--
    <div class="tab-pane show" id="referrals">
	<br>
        <p>yYou can now invite your friends through mail so that they join world's 1st video centric job platform. You would get rewarded when your friends create their account with us.</p>
                <div class="media-body">
                 
                 
            </div>
    </div>
-->        
 <div class="tab-pane active" id="profile11">
        <p class="mt-3">Interview details </p>
        <div class="row">
        <div class="col-12 col-xs-12 col-sm-12 col-md-4">
<div class="card tilebox-one shadow">
    <div class="card-body">
           <i class="uil uil-users-alt float-right"></i>
            <h6 class="text-uppercase mt-0 blogmini text-primary">attend</h6>
            <h2 class="my-2" id="active-users-count"><?php echo $no_of_available_interviews; ?></h2>
             <p class="mb-0 text-muted">
             <span class="text-nowrap"><?php if($no_of_available_interviews>1){ echo "Interviews"; } else{ echo "Interview"; } ?></span>  
                </p>
   </div> <!-- end card-body-->
</div></div>
<div class="col-12 col-xs-12 col-sm-12 col-md-4">
<div class="card tilebox-one shadow">
                                    <div class="card-body">
                                        <i class="uil uil-users-alt float-right"></i>
                                        <h6 class="text-uppercase mt-0 blogmini text-primary">completed </h6>
                                        <h2 class="my-2" id="active-users-count">2</h2>
                                        <p class="mb-0 text-muted">
                                            <span class="text-nowrap">interviews</span>  
                                        </p>
                                    </div> 
</div>
</div>
</div>
</div>       
</div>
<!-- tab content -->
</div>
    </div>
        </div>
      </div>
    </div>
    </div>
 <!-- modal content -->

<!-- Signup modal-->











