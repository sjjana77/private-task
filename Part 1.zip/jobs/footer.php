<footer class="bg-dark py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <img src="./Jobs _ QUANTUMHUNTS_files/square1_qh.png" alt="" class="logo-dark" height="38">
                        <p class="text-white-50 mt-4">
                        
                        VJA is a career platform for connecting job seekers and job providers. We help companies build amazing team and build awesome products and services.
                            
                        <!--We help you find the best people, build successful teams and generate value for everyone who trust us. We strive harder to work smart and make the earth best place to work.--></p>

                        <!--
                        <ul class="social-list list-inline mt-3">
                            <li class="list-inline-item text-center">
                                <a href="javascript: void(0);" class="social-list-item border-primary text-primary"><i class="mdi mdi-facebook"></i></a>
                            </li>
                            <li class="list-inline-item text-center">
                                <a href="javascript: void(0);" class="social-list-item border-danger text-danger"><i class="mdi mdi-google"></i></a>
                            </li>
                            <li class="list-inline-item text-center">
                                <a href="javascript: void(0);" class="social-list-item border-info text-info"><i class="mdi mdi-twitter"></i></a>
                            </li>
                            <li class="list-inline-item text-center">
                                <a href="javascript: void(0);" class="social-list-item border-secondary text-secondary"><i class="mdi mdi-github-circle"></i></a>
                            </li>
                        </ul> -->

                    </div>

                    <div class="col-6 col-lg-2 mt-3 mt-lg-0">
                        <h5 class="text-white text-uppercase blogmini">Company</h5>

                        <ul class="list-unstyled pl-0 mb-0 mt-3">
                            <li class="mt-2"><a href="https://quantumhunts.com/company/about-us/" class="text-white-50">About Us</a></li>
                            <li class="mt-2"><a href="https://quantumhunts.com/company/solutions/" class="text-white-50">Solutions</a></li>
                            <li class="mt-2"><a href="https://quantumhunts.com/company/approach/" class="text-white-50">Approach</a></li>
                            <li class="mt-2"><a href="https://quantumhunts.com/events/" class="text-white-50">Events</a></li>                            
                        </ul>

                    </div>

                    <div class="col-6 col-lg-2 mt-3 mt-lg-0">
                        <h5 class="text-white text-uppercase blogmini">Career</h5>

                        <ul class="list-unstyled pl-0 mb-0 mt-3">
                            <li class="mt-2"><a href="https://quantumhunts.com/careers/culture/" class="text-white-50">Culture</a></li>
                            <li class="mt-2"><a href="https://quantumhunts.com/company/careers/" class="text-white-50">Careers</a></li>
                            <li class="mt-2"><a href="https://quantumhunts.com/jobs/" class="text-white-50">Jobs</a></li>                            
                        </ul>
                    </div>

                    <div class="col-6 col-lg-2 mt-3 mt-lg-0">
                        <h5 class="text-white text-uppercase blogmini">Support</h5>

                        <ul class="list-unstyled pl-0 mb-0 mt-3">
                            <!--<li class="mt-2"><a href="https://quantumhunts.com/contact/" class="text-white-50">Contact</a></li>-->
                            <li class="mt-2"><a href="https://quantumhunts.com/jobs/" data-toggle="modal" data-target="#help-modal" class="text-white-50">Contact </a></li>
                            <li class="mt-2"><a href="https://quantumhunts.com/employer/survey/" class="text-white-50">Employer Feedback </a></li>                            
                            <li class="mt-2"><a href="https://quantumhunts.com/contact/locations/" class="text-white-50">Location</a></li>
                            <li class="mt-2"><a href="https://quantumhunts.com/company/privacy/" class="text-white-50">Privacy</a></li>
                        </ul>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="mt-1">
                            <p class="text-white-50 mt-1 text-center mb-0"></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>


<!--
<script>

$(function() { 

    $("#video-record-popover").popover('show');

    $("#video-record-popover").on('click', function () {
        
        $('#video-record-popover').popover('destroy');
        $("#resume-record").show();
    });
 }); 

</script>
-->

        <!-- bundle -->
        <script src="./Jobs _ QUANTUMHUNTS_files/vendor.min.js.download"></script> 
        <script src="./Jobs _ QUANTUMHUNTS_files/app.min.js.download"></script>

        <!-- third party js -->
        <script src="./Jobs _ QUANTUMHUNTS_files/apexcharts.min.js.download"></script>
        <script src="./Jobs _ QUANTUMHUNTS_files/jquery-jvectormap-1.2.2.min.js.download"></script>
        <script src="./Jobs _ QUANTUMHUNTS_files/jquery-jvectormap-world-mill-en.js.download"></script>
        <!-- third party js ends -->
        
        


        <!-- demo app -->
        <script src="./Jobs _ QUANTUMHUNTS_files/demo.dashboard.js.download"></script>
        <!-- end demo js-->
        
        <!-- plugin js -->
        <script src="./Jobs _ QUANTUMHUNTS_files/summernote-bs4.min.js.download"></script>
        <!-- Summernote demo -->
        <script src="./Jobs _ QUANTUMHUNTS_files/demo.summernote.js.download"></script>
        
        <!-- SimpleMDE demo -->
        <script src="./Jobs _ QUANTUMHUNTS_files/demo.simplemde.js.download"></script>
        
        
        <!--    
        <script src="https://coderthemes.com/hyper/modern/assets/js/vendor/dragula.min.js"></script>
        <script src="https://coderthemes.com/hyper/modern/assets/js/ui/component.dragula.js"></script>
        -->
        
        <script src="./Jobs _ QUANTUMHUNTS_files/bootstrap3-typeahead.js.download"></script>
        
        <script src="./Jobs _ QUANTUMHUNTS_files/jquery.star-rating-svg.js.download"></script>
<style>
    .jq-stars {
  display: inline-block;
}

.jq-rating-label {
  font-size: 22px;
  display: inline-block;
  position: relative;
  vertical-align: top;
  font-family: helvetica, arial, verdana;
}

.jq-star {
  width: 100px;
  height: 100px;
  display: inline-block;
  cursor: pointer;
}

.jq-star-svg {
  padding-left: 3px;
  width: 100%;
  height: 100% ;
}

.jq-star:hover .fs-star-svg path {
}

.jq-star-svg path {
  /* stroke: #000; */
  stroke-linejoin: round;
}

/* un-used */
.jq-shadow {
  -webkit-filter: drop-shadow( -2px -2px 2px #888 );
  filter: drop-shadow( -2px -2px 2px #888 );
}
</style>
 
         <script src="./Jobs _ QUANTUMHUNTS_files/jquery.rateit.min.js.download"></script>
         <!--<script src="https://quantumhunts.com/user/assets/js/ui/component.rating.js"></script>-->
 

<!--
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
	<script src="./Jobs _ QUANTUMHUNTS_files/jquery.backstretch.js.download" type="text/javascript"></script>
	<script type="text/javascript">
	//var jq = $.noConflict();
	$(document).ready(function()
	{
        //$(".learning").backstretch("https://www.groove.co/images/backgrounds/yellowHeader.svg");  
        //$(".learning").backstretch("https://agenda.com/img/about-header-background.jpg");  
        //$(".learning").backstretch("https://www.groove.co/images/backgrounds/orangeHeader.svg");
        $(".learning").backstretch("https://quantumhunts.com/user/assets/images/header/yellow.png");
        $(".bytes").backstretch("https://www.cloud3dprint.com/assets/images/svg/components/bg-elements-3.svg");          
        $(".blogtitles").backstretch("https://quantumhunts.com/user/assets/images/header/outline.png");                  
        $(".corporate").backstretch("https://quantumhunts.com/user/assets/images/header/bluelight.png");   
        $(".passion").backstretch("https://quantumhunts.com/user/assets/images/header/red.png");           
        $(".secondary").backstretch("https://quantumhunts.com/user/assets/images/header/gray.png");
        $(".neon").backstretch("https://quantumhunts.com/user/assets/images/header/neon.png");
        $(".night").backstretch("https://quantumhunts.com/user/assets/images/header/night.png");
        $(".deepnight").backstretch("https://quantumhunts.com/user/assets/images/header/black2.png");
        //$(".jobpostheader").backstretch("https://static.dashthis.com/media/1200/integrations_bg_header.png");
        //$(".jobpostheader").backstretch("https://wizixo.webestica.com/assets/images/bg/pattern/01.png");
        //$(".jobpostheader").backstretch("https://puntlandtvradio.net/images/background/header-middle-bg.png"); gray
        $(".jobpostheader").backstretch("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwuItFn-ng3DNuaysanpZWUIPSuumuFLpHkQ&usqp=CAU");
        //$(".eventheader").backstretch("https://quantumhunts.com/user/assets/images/events/event-web-header.jpg");
        //$(".eventheader").backstretch("https://t4.ftcdn.net/jpg/02/87/00/91/240_F_287009195_dqypC87ah7wxueU1mbIOO5FqSwUqaYH4.jpg"); 
        $(".eventheader").backstretch("http://quantumhunts.com/user/assets/images/events/bg-grid.svg");
        //$(".eventheader").backstretch("https://png.pngtree.com/thumb_back/fw800/back_pic/02/67/67/36578edee23114e.jpg");        
        //$(".jobpostheader").backstretch("https://github.githubassets.com/images/modules/site/patterns/contribution-graph.svg");
        //$(".jobpostheader").backstretch("https://goodkit.goodthemes.co/assets/img/patterns/pattern-1.svg");  
        $(".resume").backstretch("https://static.dashthis.com/media/1200/integrations_bg_header.png");
        $(".plusbg").backstretch("https://quantumhunts.com/user/assets/images/hero/bg_plus.gif");
        $(".coursebg").backstretch("https://www.iot-scotland.net/wp-content/uploads/2019/02/bg-hero-services.jpg");
        //$(".courseenrollbg").backstretch("https://subvrsive.com/wp-content/uploads/2019/12/immersive-workshops_header.jpg");
        $(".courseenrollbg").backstretch("https://i.pinimg.com/originals/7e/b0/50/7eb05083a0b5363fef557d0e30975507.jpg");
        $(".courseenrollbg").backstretch("https://quantumhunts.com/user/assets/images/header/mild-white-wave.jpg");
        $(".courseappliedbg").backstretch("https://www.fuseplm.com/wp-content/uploads/2018/07/client-testimonials-background-darker.jpg");    
        $(".mandate").backstretch("https://quantumhunts.com/user/assets/images/header/mild-white-wave.jpg");
        $(".split").backstretch("https://www.scoutlogicscreening.com/hubfs/offer-background.svg");
        $(".certify").backstretch("https://hojanueva.org/wp-content/plugins/ishyoboy-freelo-assets/ishyoboy-shortcodes/assets/frontend/images/svgs/row-svg-triangles.svg");        
	});
  </script>

       <!-- 
        <script src="https://coderthemes.com/hyper/modern/assets/js/vendor/dropzone.min.js"></script>
       
        <script src="https://coderthemes.com/hyper/modern/assets/js/ui/component.fileupload.js"></script>
        
-->





<!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
<script src="./Jobs _ QUANTUMHUNTS_files/videojs-ie8.min.js.download"></script>

<script src="./Jobs _ QUANTUMHUNTS_files/video.js.download"></script>


<script src="./Jobs _ QUANTUMHUNTS_files/custom.js.download"></script>


<script src="./Jobs _ QUANTUMHUNTS_files/wow.min.js.download"></script>
<script>
new WOW().init();
</script>




<!-- SimpleMDE js 
<script src="https://coderthemes.com/hyper/modern/assets/js/vendor/simplemde.min.js"></script>
<script src="https://coderthemes.com/hyper/modern/assets/js/pages/demo.simplemde.js"></script>      
 SimpleMDE demo -->


<!-- SimpleMDE js -->
<script src="./Jobs _ QUANTUMHUNTS_files/simplemde.min.js.download"></script>
<!-- SimpleMDE demo -->
<script src="./Jobs _ QUANTUMHUNTS_files/demo.simplemde.js(1).download"></script>      



<script>
var simplemde_jd = new SimpleMDE({ element: document.getElementById("jd") });
//simplemde_jd.togglePreview();
</script> 

<script>
var simplemde_jq = new SimpleMDE({ element: document.getElementById("jq") });
</script>

<script>
var simplemde_companyabout = new SimpleMDE({ element: document.getElementById("companydesc") });
</script>


<script>
var simplemde_post = new SimpleMDE({ element: document.getElementById("postcontent") });
//simplemde_post.togglePreview();
</script>

<!--
 
 <script>
var simplemde1 = new SimpleMDE({ element: $("#jd")[0] });
</script>

<script>
var simplemde2 = new SimpleMDE({ element: $("#jq")[0] });
</script>
-->


<!--
<script src="https://www.jqueryscript.net/demo/Simple-Flexible-jQuery-Alert-Notification-Plugin-notify-js/js/notify.js"></script>
-->
<script src="./Jobs _ QUANTUMHUNTS_files/notify.js.download"></script>

<!-- <script src="https://quantumhunts.com/user/assets/js/custom/notyf.min.js1"></script> 
 <script src="https://quantumhunts.com/user/assets/js/custom/notify.js"></script> -->
  
 <script src="./Jobs _ QUANTUMHUNTS_files/typed.min.js.download">
      
</script>

<script id="rendered-js">

$(function () {
    
  $(".superlative").typed({
    strings: ["are QuantumHunts","Help Jobseekers","Train Professionals","are Trusted HR Partners"],
    // Optionally use an HTML element to grab strings from (must wrap each string in a <p>)
    stringsElement: null,
    // typing speed
    typeSpeed: 10,
    // time before typing starts
    startDelay: 300,
    // backspacing speed
    backSpeed: 20,
    // time before backspacing
    backDelay: 300,
    // loop
    loop: true,
    // false = infinite
    //loopCount: 5,
    // show cursor
    showCursor: true,
    // character for cursor
    cursorChar: "|",
    // attribute to type (null == text)
    attr: null,
    // either html or text
    contentType: 'html',
    // call when done callback function
    callback: function () {},
    // starting callback function before each string
    preStringTyped: function () {},
    //callback for every typed string
    onStringTyped: function () {},
    // callback for reset
    resetCallback: function () {} });
    
    
    

});

</script>



<!-- Analytics -->
<script async="" src="./Jobs _ QUANTUMHUNTS_files/js"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-908Z83GP55');
</script>
  





        
    

<svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;"><defs id="SvgjsDefs1002"></defs><polyline id="SvgjsPolyline1003" points="0,0"></polyline><path id="SvgjsPath1004" d="M0 0 "></path></svg></body></html>