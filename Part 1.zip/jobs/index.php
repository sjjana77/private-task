<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$jobb_comapny=[];
$jobb_title=[];
$jobb_location=[];
$jobb_id=[];
$sql8 = "SELECT * FROM vj_jobs";
$result8 = $conn->query($sql8);
if ($result8->num_rows > 0) {
    while($row8 = $result8->fetch_assoc()) {
        array_push($jobb_comapny,$row8['job_company']);
        array_push($jobb_location,$row8['job_location']);
        array_push($jobb_id,$row8['job_id']);
        array_push($jobb_title,$row8['job_title']);
    }
    }

?>
<!DOCTYPE html>
<!-- saved from url=(0030)http://localhost/jobs/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Jobs | VJA</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Search &amp; Apply for Jobs with VJA, India&#39;s No 1 job agency for startups &amp; corporates" name="description">
        <meta content="VJA" name="author">

        <!-- end Topbar -->
        
        <?php
      include($root."/jobs/header.php");

        ?>


        
        
        

        
<!--
<p>&nbsp;</p>        
    -->    
        
        


        <!-- Start Content-->
        <div class="container-fluid">

            <!-- Begin page -->
            <div class="wrapper">

                <!-- ========== Left Sidebar Start ========== -->

                               
                                
<div class="left-side-menu left-side-menu-detached mm-active shadow1" style="background-color:transparent;background1:#fafbfe;margin-top:0px;">
    
    <div class="leftbar-user1 border1">


	

                        <a href="javascript: void(0);">
                            <!--<img src="assets/images/users/avatar-1.jpg" alt="user-image" height="42" class="rounded-circle shadow-sm">-->
                            <span class="leftbar-user-name"></span>
                        </a>




                    </div>

<!-- <div class="card-header bg-primary text-light">    QuantumHunts   </div>    -->
    
                    <ul class="metismenu side-nav mm-show">

                        <!--<li class="side-nav-title side-nav-item text-info">Navigation</li>-->

<!--
                        <li class="side-nav-item">
                            <a href="http://localhost/jobs/home/" class="side-nav-link">
                                <i class="uil-home-alt text-dark"></i>
                                <span> Home </span>
                            </a>
                        </li>
-->                        


    
<li class="side-nav-item">
<div class="cta-box overflow-hidden">

<div class="card-body">
<?php 
    if(!isset($_SESSION['candidate_id']) || (!isset($_SESSION['recruiter_id']))){                ?>                          
<div class="text-center">                                        

<div class="row">
<div class="col-3">
</div>
<div class="col-6">                                        
    <img class="img-fluid" src="./Jobs _ QUANTUMHUNTS_files/3237472.svg">
</div>    
<div class="col-3">
</div>
</div>

<div class="row pt-2">
<div class="col-1">
</div>
<div class="col-10">  
<strong class="text-primary text-uppercase blogmini font-12 font-weight-bold">Create Account</strong>
<p class="font-14 text-dark">Find your next work adventure. Create your profile and get instantly matched to jobs at the World’s most exciting companies.</p>
<a class="btn bg-secondary-two btn-sm font-weight-bold text-dark" href="http://localhost/signup">Create Account</a>
</div>    
<div class="col-1">
</div>
</div>

</div><?php  }  ?>


                                    </div>
                                    <!-- end card-body -->
                                </div>    
    <hr>

</li>

	
	
                    <!--- Sidemenu -->


            
                                            <!--

                            <li class="side-nav-item">
                            <a href="http://localhost/user/post/company/" class="side-nav-link  mb-0 pb-0">
                                <i class="uil uil-bag-alt"></i> 
                                <span> Create a Company </span> 
                            </a>
                        </li>
                        -->

                                    

                       
                        
    	 
    	    
    

<p>&nbsp;</p>

                            
                        

                       

        
                    </ul>

                    <!-- Help Box 
                    <div class="help-box text-center">
                        <a href="javascript: void(0);" class="float-right close-btn text-body">
                            <i class="mdi mdi-close"></i>
                        </a>
                        <img src="https://coderthemes.com/hyper/modern/assets/images/help-icon.svg" height="90" alt="Helper Icon Image">
                        <h5 class="mt-3">Unlimited Access</h5>
                        <p class="mb-3">Upgrade to plan to get access to unlimited reports</p>
                        <a href="javascript: void(0);" class="btn btn-outline-primary btn-sm">Upgrade</a>
                    </div>
                    end Help Box -->
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>
                    <!-- Sidebar -left -->

                </div>
                <!-- Left Sidebar End -->




<div class="content-page text-dark">
<div class="content">

<div class="row">   
                
                




<div class="col-xl-8 col-lg-8">
    

<div class="card border shadow mb-2" style="background-color: #E1E7ED  !important;">
<div class="pl-2 p-1 pb-1">
<h5 class="text-left">Your dream job is just a search away</h5>

<form1 autocomplete="none-off">
    <div class="form-row align-items-center app-search">
        <div class="col-5">
                        <div class="input-group">
                            <input type="text" id="skills" class="typeahead form-controlx form-control" placeholder="Search jobs by roles skills" style="border: 1.0px solid #bbc7cd!important;" onkeydown="searchFilter()" autocomplete="none-off">
                          
                        
                        </div>
        </div>        
        <div class="col-5">
                        <div class="input-group">
                            <input type="text" id="location" class="typeahead form-controlx form-control" placeholder="Location" style="border: 1.0px solid #bbc7cd!important;" onkeydown="searchFilter()" autocomplete="none-off">
                        </div>
        </div>
        <div class="col-2">
                            <div class="input-group-append" style="overflow:hidden;">
                                <button class="btn btn-primary btn-sm" type="submit" onclick="searchFilter();" id="go">Go</button>
                            </div>
            
        </div>            
    </div>
</form1>

<p class="pb-0 mb-0 pr-3 text-right"><a class="text-muted" data-toggle="collapse" aria-expanded="false" aria-controls="collapseExample"> Advanced </a></p>



</div>
</div>





<div class="collapse hide card border shadow mb-2" id="collapseExample" style="background-color: #E1E7ED  !important;">
<div class="p-2">
<!--    <div class="float-right"><a href="#" data-toggle="collapse" href="#collapseExample" aria-expanded="false"  aria-controls="collapseExample"><i class="mdi mdi-close"></i></a></div> -->
    <div class="form-row align-items-center app-search">
        <div class="col-3">
            <div class="input-group">
            <select class="form-control form-control-sm" id="sort">
            <option value="">Sort by</option>                
            <option value="new">Newest</option>
            <option value="old">Oldest</option>
            </select>
            <!--<span class="mdi mdi-desk-lamp"></span>-->
            </div>
        </div>        
        <div class="col-3">
            <div class="input-group">
<select class="form-control form-control-sm" id="jobtype">
    <option value="">Select job type
    </option>    
    <option value="Full-Time">Full-time
    </option>
    <option value="Part-Time">Part-time
    </option>
    <option value="Contract">Contract
    </option>
    <option value="Temporary">Temporary 
    </option>
    <option value="Volunteer">Volunteer 
    </option>
    <option value="Internship">Internship 
    </option>
  </select>     
            <!--<span class="mdi mdi-desk-lamp"></span>-->
            </div>
        </div>                
        <div class="col-4">
                        <div class="input-group">
                            <input type="text" id="company" class="typeahead form-control form-control-sm" onkeydown="searchFilter()" placeholder="Company" style="border: 1.0px solid #bbc7cd!important;">
                            <!--<span class="mdi mdi-desk-lamp"></span>-->
                        </div>
        </div>
        <div class="col-3">

        </div>            
    </div>
</div>
</div>

<!--
<div class="alert alert-dark shadow">
Millions of employees are working from home for the first time, as the world tackles Covid-19.
While you sit back and relax at home, enjoy the beta version of our website. So apply to the jobs that interest you.
</div>
-->


<script>
    $(document).ready(function () {
        $('#location').typeahead({
            source: function (query, result) {
                $.ajax({
                    url: "http://localhost/user/get/locations/",
					data: 'query=' + query,            
                    dataType: "json",
                    type: "POST",
                    success: function (data) {
						result($.map(data, function (item) {
							return item;
                        }));
                    }
                });
            }
        });
    });
</script>


























<!--
                
<div class="card border shadow"  style="padding-top:0px;"> -->  
<div class="card-body1 p-2 pt-0 " style="margin-top:0px;padding-top">
    
                          
                            
                            
                            
 


                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
           <div class="row">                 

                            <div class="col-xl-12 col-lg-12">
                                

  <!-- include Google hosted jQuery Library -->
<script src="./Jobs _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

<!--<h5 class="text-uppercase font-8 mb-0 text-secondary">Search Jobs</h5>-->

                                                    




<script>
function searchFilter(page_num) 
{
    //alert("hello");
    page_num = page_num?page_num:0;
    var skills = $('#skills').val();
    var location=$('#location').val();    
    var sort = $('#sort').val();
    var jobtype = $('#jobtype').val();    
    var company = $('#company').val();    
    
    $.ajax({
        type: 'POST',
        url: 'http://localhost/user/get/jobs/',
        data:'page='+page_num+'&skills='+skills+'&sortBy='+sort+'&location='+location+'&jobtype='+jobtype+'&company='+company,
        beforeSend: function () 
        {
            $('.loading-overlay').show();
            //$('.loading-overlay').hide();
            
        },
        success: function (html) 
        {
            //alert("Results are displayed");
            $('#posts_content').html(html);
            $('.loading-overlay').fadeOut("slow");
            $('body,html').animate({scrollTop: 0}, 600);
        }
    });
}
</script>


	   
		
		
 


<style>

.loading-overlay 
{
display: none;
}
    
</style>

<div id="posts_content">

   
  
<div class="row p-0">   
        
        
    
    
    <!--   <div class="pagination"><nav><ul class="pagination">&nbsp;<li class="page-item"><a class=" item page-link text-light bg-primary">1</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(10)">2</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(20)">3</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(30)">4</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(10)">&gt;</a></li>&nbsp;&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(210)">Last &rsaquo;</a></li></ul></nav></div> -->
    
    


    





        






<script>
    function myjob(a){
        var aa=a;
    $.ajax({
type:"POST",
url:"http://localhost/login/session.php",
dataType:"json",
data:{a:aa},
success:function(data){
if(data.code=='200'){
  window.location.href = "http://localhost/view-job/";
//alert(data.msg);
}

}
});
    }
</script>


        
<?php for($x=0;$x<count($jobb_id);$x++){ ?>
                                            <div id="<?php echo $jobb_id[$x]; ?>" onclick="myjob(this.id)" class="col-sm-6 m-0 border shadow ribbon-box p-2 pt-0 jobcard" style="padding-top:0px;">
                                  <!--<a target="_blank" href="http://localhost/jobs/view/quality-manager-ask-automotive-pvt-ltd-haridwar-india-20210721141318/321">-->
                                  <a>
                                  <div class="grid-container text-dark ribbon-box">
                                                      
                                                        <strong class="text-dark"><?php echo $jobb_title[$x]; ?></strong><br>
                                                       <span class="text-muted"><?php echo $jobb_comapny[$x]; ?></span><br>
                                                       <span class="text-muted"><?php echo $jobb_location[$x]; ?></span><br><br>
                                                     
                                            </div>
                                    </a>
                                            </div>
        

                                            <?php } ?>


                                            <div class="col-sm-12 m-0 border shadow ribbon-box p-2 pt-0 jobcard" style="padding-top:0px;background:white;">
                                                <div class="row">
                                                    <div class="col-5">    
                                                            <div data-setup="{}" fluid="true" preload="true" class="video-js vjs-tech vjs-theme-city vjs-big-play-centered bg-light vjs-paused my-video-dimensions vjs-fluid vjs-controls-enabled vjs-workinghover vjs-v7 vjs-user-active" id="my-video" tabindex="-1" role="region" lang="en" aria-label="Video Player"><video id="my-video_html5_api" class="vjs-tech" preload="true" fluid="true" data-setup="{}" tabindex="-1" role="application">
                                                                <source src="http://localhost/7d7425d993b8450cb78525d3c95f821c.mp4" type="video/mp4">
                                                                <!--<source src="MY_VIDEO.webm" type="video/webm" />-->
                                                                <p class="vjs-no-js">
                                                                  To view this video please enable JavaScript, and consider upgrading to a
                                                                  web browser that
                                                                  
                                                                  <a href="" target="_blank" class="vjs-hidden" hidden="hidden">supports HTML5 video</a>
                                                                </p>
                                                              </video><div class="vjs-poster vjs-hidden" aria-disabled="false"></div><div class="vjs-text-track-display" aria-live="off" aria-atomic="true"></div><div class="vjs-loading-spinner" dir="ltr"><span class="vjs-control-text">Video Player is loading.</span></div><button class="vjs-big-play-button" type="button" title="Play Video" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Play Video</span></button><div class="vjs-control-bar" dir="ltr"><button class="vjs-play-control vjs-control vjs-button" type="button" title="Play" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Play</span></button><div class="vjs-volume-panel vjs-control vjs-volume-panel-horizontal"><button class="vjs-mute-control vjs-control vjs-button vjs-vol-3" type="button" title="Mute" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Mute</span></button><div class="vjs-volume-control vjs-control vjs-volume-horizontal"><div tabindex="0" class="vjs-volume-bar vjs-slider-bar vjs-slider vjs-slider-horizontal" role="slider" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" aria-label="Volume Level" aria-live="polite" aria-valuetext="100%"><div class="vjs-volume-level"><span class="vjs-control-text"></span></div></div></div></div><div class="vjs-current-time vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Current Time&nbsp;</span><span class="vjs-current-time-display" aria-live="off" role="presentation">0:00</span></div><div class="vjs-time-control vjs-time-divider" aria-hidden="true"><div><span>/</span></div></div><div class="vjs-duration vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Duration&nbsp;</span><span class="vjs-duration-display" aria-live="off" role="presentation">0:35</span></div><div class="vjs-progress-control vjs-control"><div tabindex="0" class="vjs-progress-holder vjs-slider vjs-slider-horizontal" role="slider" aria-valuenow="0.00" aria-valuemin="0" aria-valuemax="100" aria-label="Progress Bar" aria-valuetext="0:00 of 0:35"><div class="vjs-load-progress"><span class="vjs-control-text"><span>Loaded</span>: <span class="vjs-control-text-loaded-percentage">0%</span></span></div><div class="vjs-mouse-display"><div class="vjs-time-tooltip" aria-hidden="true"></div></div><div class="vjs-play-progress vjs-slider-bar" aria-hidden="true" style="width: 0%;"><div class="vjs-time-tooltip" aria-hidden="true" style="right: 0px;">0:00</div></div></div></div><div class="vjs-live-control vjs-control vjs-hidden"><div class="vjs-live-display" aria-live="off"><span class="vjs-control-text">Stream Type&nbsp;</span>LIVE</div></div><button class="vjs-seek-to-live-control vjs-control" type="button" title="Seek to live, currently behind live" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Seek to live, currently behind live</span><span class="vjs-seek-to-live-text" aria-hidden="true">LIVE</span></button><div class="vjs-remaining-time vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Remaining Time&nbsp;</span><span aria-hidden="true">-</span><span class="vjs-remaining-time-display" aria-live="off" role="presentation">0:35</span></div><div class="vjs-custom-control-spacer vjs-spacer ">&nbsp;</div><div class="vjs-playback-rate vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><div class="vjs-playback-rate-value">1x</div><button class="vjs-playback-rate vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Playback Rate" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Playback Rate</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"></ul></div></div><div class="vjs-chapters-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-chapters-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Chapters" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Chapters</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-title">Chapters</li></ul></div></div><div class="vjs-descriptions-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-descriptions-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Descriptions" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Descriptions</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-item vjs-selected" role="menuitemradio" aria-disabled="false" tabindex="-1" aria-checked="true"><span class="vjs-menu-item-text">descriptions off</span><span class="vjs-control-text" aria-live="polite">, selected</span></li></ul></div></div><div class="vjs-subs-caps-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-subs-caps-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Captions" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Captions</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-item vjs-texttrack-settings" role="menuitem" aria-disabled="false" tabindex="-1"><span class="vjs-menu-item-text">captions settings</span><span class="vjs-control-text" aria-live="polite">, opens captions settings dialog</span></li><li class="vjs-menu-item vjs-selected" role="menuitemradio" aria-disabled="false" tabindex="-1" aria-checked="true"><span class="vjs-menu-item-text">captions off</span><span class="vjs-control-text" aria-live="polite">, selected</span></li></ul></div></div><div class="vjs-audio-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-audio-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Audio Track" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Audio Track</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"></ul></div></div><button class="vjs-picture-in-picture-control vjs-control vjs-button" type="button" title="Picture-in-Picture" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Picture-in-Picture</span></button><button class="vjs-fullscreen-control vjs-control vjs-button" type="button" title="Fullscreen" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Fullscreen</span></button></div><div class="vjs-error-display vjs-modal-dialog vjs-hidden " aria-describedby="my-video_component_368_description" aria-hidden="true" aria-label="Modal Window" role="dialog"><p class="vjs-modal-dialog-description vjs-control-text" id="my-video_component_368_description">This is a modal window.</p><div class="vjs-modal-dialog-content" role="document"></div></div><div class="vjs-modal-dialog vjs-hidden  vjs-text-track-settings" aria-describedby="my-video_component_373_description" aria-hidden="true" aria-label="Caption Settings Dialog" role="dialog"><p class="vjs-modal-dialog-description vjs-control-text" id="my-video_component_373_description">Beginning of dialog window. Escape will cancel and close the window.</p><div class="vjs-modal-dialog-content" role="document"><div class="vjs-track-settings-colors"><fieldset class="vjs-fg-color vjs-track-setting"><legend id="captions-text-legend-my-video_component_373">Text</legend><label id="captions-foreground-color-my-video_component_373" class="vjs-label">Color</label><select aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-color-my-video_component_373"><option id="captions-foreground-color-my-video_component_373-White" value="#FFF" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-color-my-video_component_373 captions-foreground-color-my-video_component_373-White">White</option><option id="captions-foreground-color-my-video_component_373-Black" value="#000" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-color-my-video_component_373 captions-foreground-color-my-video_component_373-Black">Black</option><option id="captions-foreground-color-my-video_component_373-Red" value="#F00" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-color-my-video_component_373 captions-foreground-color-my-video_component_373-Red">Red</option><option id="captions-foreground-color-my-video_component_373-Green" value="#0F0" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-color-my-video_component_373 captions-foreground-color-my-video_component_373-Green">Green</option><option id="captions-foreground-color-my-video_component_373-Blue" value="#00F" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-color-my-video_component_373 captions-foreground-color-my-video_component_373-Blue">Blue</option><option id="captions-foreground-color-my-video_component_373-Yellow" value="#FF0" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-color-my-video_component_373 captions-foreground-color-my-video_component_373-Yellow">Yellow</option><option id="captions-foreground-color-my-video_component_373-Magenta" value="#F0F" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-color-my-video_component_373 captions-foreground-color-my-video_component_373-Magenta">Magenta</option><option id="captions-foreground-color-my-video_component_373-Cyan" value="#0FF" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-color-my-video_component_373 captions-foreground-color-my-video_component_373-Cyan">Cyan</option></select><span class="vjs-text-opacity vjs-opacity"><label id="captions-foreground-opacity-my-video_component_373" class="vjs-label">Transparency</label><select aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-opacity-my-video_component_373"><option id="captions-foreground-opacity-my-video_component_373-Opaque" value="1" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-opacity-my-video_component_373 captions-foreground-opacity-my-video_component_373-Opaque">Opaque</option><option id="captions-foreground-opacity-my-video_component_373-SemiTransparent" value="0.5" aria-labelledby="captions-text-legend-my-video_component_373 captions-foreground-opacity-my-video_component_373 captions-foreground-opacity-my-video_component_373-SemiTransparent">Semi-Transparent</option></select></span></fieldset><fieldset class="vjs-bg-color vjs-track-setting"><legend id="captions-background-my-video_component_373">Background</legend><label id="captions-background-color-my-video_component_373" class="vjs-label">Color</label><select aria-labelledby="captions-background-my-video_component_373 captions-background-color-my-video_component_373"><option id="captions-background-color-my-video_component_373-Black" value="#000" aria-labelledby="captions-background-my-video_component_373 captions-background-color-my-video_component_373 captions-background-color-my-video_component_373-Black">Black</option><option id="captions-background-color-my-video_component_373-White" value="#FFF" aria-labelledby="captions-background-my-video_component_373 captions-background-color-my-video_component_373 captions-background-color-my-video_component_373-White">White</option><option id="captions-background-color-my-video_component_373-Red" value="#F00" aria-labelledby="captions-background-my-video_component_373 captions-background-color-my-video_component_373 captions-background-color-my-video_component_373-Red">Red</option><option id="captions-background-color-my-video_component_373-Green" value="#0F0" aria-labelledby="captions-background-my-video_component_373 captions-background-color-my-video_component_373 captions-background-color-my-video_component_373-Green">Green</option><option id="captions-background-color-my-video_component_373-Blue" value="#00F" aria-labelledby="captions-background-my-video_component_373 captions-background-color-my-video_component_373 captions-background-color-my-video_component_373-Blue">Blue</option><option id="captions-background-color-my-video_component_373-Yellow" value="#FF0" aria-labelledby="captions-background-my-video_component_373 captions-background-color-my-video_component_373 captions-background-color-my-video_component_373-Yellow">Yellow</option><option id="captions-background-color-my-video_component_373-Magenta" value="#F0F" aria-labelledby="captions-background-my-video_component_373 captions-background-color-my-video_component_373 captions-background-color-my-video_component_373-Magenta">Magenta</option><option id="captions-background-color-my-video_component_373-Cyan" value="#0FF" aria-labelledby="captions-background-my-video_component_373 captions-background-color-my-video_component_373 captions-background-color-my-video_component_373-Cyan">Cyan</option></select><span class="vjs-bg-opacity vjs-opacity"><label id="captions-background-opacity-my-video_component_373" class="vjs-label">Transparency</label><select aria-labelledby="captions-background-my-video_component_373 captions-background-opacity-my-video_component_373"><option id="captions-background-opacity-my-video_component_373-Opaque" value="1" aria-labelledby="captions-background-my-video_component_373 captions-background-opacity-my-video_component_373 captions-background-opacity-my-video_component_373-Opaque">Opaque</option><option id="captions-background-opacity-my-video_component_373-SemiTransparent" value="0.5" aria-labelledby="captions-background-my-video_component_373 captions-background-opacity-my-video_component_373 captions-background-opacity-my-video_component_373-SemiTransparent">Semi-Transparent</option><option id="captions-background-opacity-my-video_component_373-Transparent" value="0" aria-labelledby="captions-background-my-video_component_373 captions-background-opacity-my-video_component_373 captions-background-opacity-my-video_component_373-Transparent">Transparent</option></select></span></fieldset><fieldset class="vjs-window-color vjs-track-setting"><legend id="captions-window-my-video_component_373">Window</legend><label id="captions-window-color-my-video_component_373" class="vjs-label">Color</label><select aria-labelledby="captions-window-my-video_component_373 captions-window-color-my-video_component_373"><option id="captions-window-color-my-video_component_373-Black" value="#000" aria-labelledby="captions-window-my-video_component_373 captions-window-color-my-video_component_373 captions-window-color-my-video_component_373-Black">Black</option><option id="captions-window-color-my-video_component_373-White" value="#FFF" aria-labelledby="captions-window-my-video_component_373 captions-window-color-my-video_component_373 captions-window-color-my-video_component_373-White">White</option><option id="captions-window-color-my-video_component_373-Red" value="#F00" aria-labelledby="captions-window-my-video_component_373 captions-window-color-my-video_component_373 captions-window-color-my-video_component_373-Red">Red</option><option id="captions-window-color-my-video_component_373-Green" value="#0F0" aria-labelledby="captions-window-my-video_component_373 captions-window-color-my-video_component_373 captions-window-color-my-video_component_373-Green">Green</option><option id="captions-window-color-my-video_component_373-Blue" value="#00F" aria-labelledby="captions-window-my-video_component_373 captions-window-color-my-video_component_373 captions-window-color-my-video_component_373-Blue">Blue</option><option id="captions-window-color-my-video_component_373-Yellow" value="#FF0" aria-labelledby="captions-window-my-video_component_373 captions-window-color-my-video_component_373 captions-window-color-my-video_component_373-Yellow">Yellow</option><option id="captions-window-color-my-video_component_373-Magenta" value="#F0F" aria-labelledby="captions-window-my-video_component_373 captions-window-color-my-video_component_373 captions-window-color-my-video_component_373-Magenta">Magenta</option><option id="captions-window-color-my-video_component_373-Cyan" value="#0FF" aria-labelledby="captions-window-my-video_component_373 captions-window-color-my-video_component_373 captions-window-color-my-video_component_373-Cyan">Cyan</option></select><span class="vjs-window-opacity vjs-opacity"><label id="captions-window-opacity-my-video_component_373" class="vjs-label">Transparency</label><select aria-labelledby="captions-window-my-video_component_373 captions-window-opacity-my-video_component_373"><option id="captions-window-opacity-my-video_component_373-Transparent" value="0" aria-labelledby="captions-window-my-video_component_373 captions-window-opacity-my-video_component_373 captions-window-opacity-my-video_component_373-Transparent">Transparent</option><option id="captions-window-opacity-my-video_component_373-SemiTransparent" value="0.5" aria-labelledby="captions-window-my-video_component_373 captions-window-opacity-my-video_component_373 captions-window-opacity-my-video_component_373-SemiTransparent">Semi-Transparent</option><option id="captions-window-opacity-my-video_component_373-Opaque" value="1" aria-labelledby="captions-window-my-video_component_373 captions-window-opacity-my-video_component_373 captions-window-opacity-my-video_component_373-Opaque">Opaque</option></select></span></fieldset></div><div class="vjs-track-settings-font"><fieldset class="vjs-font-percent vjs-track-setting"><legend id="captions-font-size-my-video_component_373" class="">Font Size</legend><select aria-labelledby="captions-font-size-my-video_component_373"><option id="captions-font-size-my-video_component_373-50" value="0.50" aria-labelledby="captions-font-size-my-video_component_373 captions-font-size-my-video_component_373-50">50%</option><option id="captions-font-size-my-video_component_373-75" value="0.75" aria-labelledby="captions-font-size-my-video_component_373 captions-font-size-my-video_component_373-75">75%</option><option id="captions-font-size-my-video_component_373-100" value="1.00" aria-labelledby="captions-font-size-my-video_component_373 captions-font-size-my-video_component_373-100">100%</option><option id="captions-font-size-my-video_component_373-125" value="1.25" aria-labelledby="captions-font-size-my-video_component_373 captions-font-size-my-video_component_373-125">125%</option><option id="captions-font-size-my-video_component_373-150" value="1.50" aria-labelledby="captions-font-size-my-video_component_373 captions-font-size-my-video_component_373-150">150%</option><option id="captions-font-size-my-video_component_373-175" value="1.75" aria-labelledby="captions-font-size-my-video_component_373 captions-font-size-my-video_component_373-175">175%</option><option id="captions-font-size-my-video_component_373-200" value="2.00" aria-labelledby="captions-font-size-my-video_component_373 captions-font-size-my-video_component_373-200">200%</option><option id="captions-font-size-my-video_component_373-300" value="3.00" aria-labelledby="captions-font-size-my-video_component_373 captions-font-size-my-video_component_373-300">300%</option><option id="captions-font-size-my-video_component_373-400" value="4.00" aria-labelledby="captions-font-size-my-video_component_373 captions-font-size-my-video_component_373-400">400%</option></select></fieldset><fieldset class="vjs-edge-style vjs-track-setting"><legend id="my-video_component_373" class="">Text Edge Style</legend><select aria-labelledby="my-video_component_373"><option id="my-video_component_373-None" value="none" aria-labelledby="my-video_component_373 my-video_component_373-None">None</option><option id="my-video_component_373-Raised" value="raised" aria-labelledby="my-video_component_373 my-video_component_373-Raised">Raised</option><option id="my-video_component_373-Depressed" value="depressed" aria-labelledby="my-video_component_373 my-video_component_373-Depressed">Depressed</option><option id="my-video_component_373-Uniform" value="uniform" aria-labelledby="my-video_component_373 my-video_component_373-Uniform">Uniform</option><option id="my-video_component_373-Dropshadow" value="dropshadow" aria-labelledby="my-video_component_373 my-video_component_373-Dropshadow">Dropshadow</option></select></fieldset><fieldset class="vjs-font-family vjs-track-setting"><legend id="captions-font-family-my-video_component_373" class="">Font Family</legend><select aria-labelledby="captions-font-family-my-video_component_373"><option id="captions-font-family-my-video_component_373-ProportionalSansSerif" value="proportionalSansSerif" aria-labelledby="captions-font-family-my-video_component_373 captions-font-family-my-video_component_373-ProportionalSansSerif">Proportional Sans-Serif</option><option id="captions-font-family-my-video_component_373-MonospaceSansSerif" value="monospaceSansSerif" aria-labelledby="captions-font-family-my-video_component_373 captions-font-family-my-video_component_373-MonospaceSansSerif">Monospace Sans-Serif</option><option id="captions-font-family-my-video_component_373-ProportionalSerif" value="proportionalSerif" aria-labelledby="captions-font-family-my-video_component_373 captions-font-family-my-video_component_373-ProportionalSerif">Proportional Serif</option><option id="captions-font-family-my-video_component_373-MonospaceSerif" value="monospaceSerif" aria-labelledby="captions-font-family-my-video_component_373 captions-font-family-my-video_component_373-MonospaceSerif">Monospace Serif</option><option id="captions-font-family-my-video_component_373-Casual" value="casual" aria-labelledby="captions-font-family-my-video_component_373 captions-font-family-my-video_component_373-Casual">Casual</option><option id="captions-font-family-my-video_component_373-Script" value="script" aria-labelledby="captions-font-family-my-video_component_373 captions-font-family-my-video_component_373-Script">Script</option><option id="captions-font-family-my-video_component_373-SmallCaps" value="small-caps" aria-labelledby="captions-font-family-my-video_component_373 captions-font-family-my-video_component_373-SmallCaps">Small Caps</option></select></fieldset></div><div class="vjs-track-settings-controls"><button type="button" class="vjs-default-button" title="restore all settings to the default values">Reset<span class="vjs-control-text"> restore all settings to the default values</span></button><button type="button" class="vjs-done-button">Done</button></div></div><button class="vjs-close-button vjs-control vjs-button" type="button" aria-disabled="false" title="Close Modal Dialog"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Close Modal Dialog</span></button><p class="vjs-control-text">End of dialog window.</p></div></div>
                                                    </div>
                                                <div class="col-7">
                                                    <a href="http://localhost/course/HR-training-bootcamp-fasttrack" class="text-dark">
                                                        <div class="help-box1 text-left">
                                                            <h3 class="text-left font-weight-normal mb-0">HR Training FastTrack - 2021</h3>
                                                            <p class="text-left mb-1">Join our virtual HR Training Bootcamp course curated for aspiring Freshers, HRs  &amp; Recruiters. Please enroll before we close the registration each Saturday.</p>
                                                            <span class="btn btn-warning font-weight-bold text-dark btn-xs mr-2">Enroll</span> <span></span>    
                                                            <br><br>
                                    
                                                        </div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
       
    
            
            
            
            
            
            
            
            
            
            
    
        
</div>        
       
<p>&nbsp;</p>   
    
     
    <div class="pagination"><nav><ul class="pagination">&nbsp;<li class="page-item"><a class=" item page-link text-light bg-primary">1</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" onclick="searchFilter(10)">2</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" onclick="searchFilter(20)">3</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" onclick="searchFilter(30)">4</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" onclick="searchFilter(10)">&gt;</a></li>&nbsp;&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" onclick="searchFilter(210)">Last ›</a></li></ul></nav></div>    

	
	
	
	
	

</div>	
 

<p>&nbsp;</p>   




 <!-- Display pagination links 
            <div class="pagination"><nav><ul class="pagination">&nbsp;<li class="page-item"><a class=" item page-link text-light bg-primary">1</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(10)">2</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(20)">3</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(30)">4</a></li>&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(10)">&gt;</a></li>&nbsp;&nbsp;<li class="page-item"><a class="item page-link" href="javascript:void(0);" 
                onclick="searchFilter(210)">Last &rsaquo;</a></li></ul></nav></div>            -->
            
            
            
<!--
<nav>
    <ul class="pagination">
        <li class="page-item">
            <a class="page-link" href="javascript: void(0);" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
            </a>
        </li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">1</a></li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">2</a></li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">3</a></li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">4</a></li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">5</a></li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">6</a></li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">7</a></li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">8</a></li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">9</a></li>
        <li class="page-item"><a class="page-link" href="javascript: void(0);">10</a></li>        
        <li class="page-item">
            <a class="page-link" href="javascript: void(0);" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
            </a>
        </li>
    </ul>
</nav>
 
 -->                                                   

</div>
</div>





<!--
                </div> -->
                </div>
                            
    
    
    
<div class="row">                 
<div class="col-xl-12 col-lg-12">
 

<div class="card border shadow">
<div id="posts_content1">

<div class="row p-0">
                                            <div class="col-7">
                                            <div class="help-box1 card-body text-left">


                                    <h2 class="m-0 font-weight-normal cta-box-title text-left">Get Alerts</h2>    
                                    <p class="text-left">Get special offers on the latest developments from our VJA Bytes.</p>
                                    <div class="form-group text-left" id="horizontalsubsform">

                                    <input class="form-control form-control-sm mt-1" name="horizontalsubsemail" id="horizontalsubsemail">
                                    <button type="button" class="btn btn-sm btn-primary mt-2" id="horizontal-btn-subscribe">Subscribe</button>
                                    </div>
                                    <div class="display-error  alert alert-danger horizontal-subs-error" style="display: none">
                                    </div>
                                    <div class="display-success  alert alert-info horizontal-subs-success" style="display: none">
                                    </div> 



                                                        </div>
                                                    </div>
                                                    <div class="col-5">    
                                                        <div class="help-box1 d-flex align-items-center justify-content-center h-100 text-center">    
                                                    <img src="./Jobs _ QUANTUMHUNTS_files/mail_qh.png" class="img-fluid">
                                                        </div>
                                                    </div>
                                                    
                                                </div>
</div>
</div>

</div>
</div>









  <!-- include Google hosted jQuery Library -->
<script src="./Jobs _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#horizontal-btn-subscribe').click(function(e){
        e.preventDefault();

        var horizontalsubsemail = $("#horizontalsubsemail").val();
        //alert(subsemail);
        
        $.ajax({
            type: "POST",
            url: "http://localhost/user/set/subscribe/",
            dataType: "json",
            data: {email:horizontalsubsemail},            
            success : function(data){
                if (data.code == "200")
                {
                    $(".horizontal-subs-success").show(); 
                    $(".horizontal-subs-error").hide(); 
                    $("#horizontalsubsform").hide();
                    $(".subs-success").html(""+data.msg+"");
                    $(".subs-success").css("display","block");
                } 
                else {
                    //alert("Success: " +data.msg);
                    $(".horizontal-subs-error").html(""+data.msg+"");
                    $(".horizontal-subs-error").css("display","block");
                }
            }
        });


      });
  });
</script>


    
    
    
    
    
    
    
    
                                       
                                    
                            </div> <!-- end col -->
                            <div class="col-xl-4 col-lg-4">

                     

<?php

if(isset($_SESSION['candidate_id'])){             
include($root."/jobs/fetch_interview.php");
}
?>



</div>


                               



<div class="card border cta-box" onclick="window.location.href = &#39;http://localhost/virtual-mentor&#39;;" style="cursor:pointer;">
                                    <div class="card-body">
                                     <div class="text-center"> <!--<i class="h2 mdi mdi-email-outline text-dark text-primary"></i>-->
                                    <!-- <img src="https://www.flaticon.com/svg/static/icons/svg/3424/3424786.svg" height="48">-->
                                    <h5 class="m-0 font-weight-bold cta-box-title text-left mt-2 text-uppercase blogmini font-14 mb-1 mt-1 text-dark">Find a Mentor</h5>    
                                    <p class="text-left text-dark font-14"><span class="">Hello .</span> VJA CEO, Founder and an accomplished HR Leader <span class="text-dark blogmini font-weight-bold text-uppercase">JANA</span> is conducting a two week virtual Mentorship program for Students to grab the best job offer and for professionals to revist their career path. Join this program to shape your career path. </p>
                                    <div class="form-group text-left">

                                    <a class="btn btn-sm btn-primary mt-2" id="btn-subscribe"> Learn More</a>
                                     
                                    </div>

                                    </div>
                                    </div>
</div>




                                <div class="card border cta-box">
                                    <div class="card-body">

                                     <div class="text-center mb-3">
                                     <img src="./Jobs _ QUANTUMHUNTS_files/2910803.svg" height="40">
                                     </div>
                                        
                                    <h5 class="m-0 mb-2 font-weight-bold cta-box-title1 text-left text-dark text-uppercase blogmini">Upskill yourself</h5>    
                                    <p class="">If you are looking for skill development or resume upgrade, please click below. We'll connect you to <span class="text-dark text-uppercase font-weight-bold font-12">VJA</span> HR Buddies.</p>
                                    <button type="button" class="btn btn-sm btn-outline-primary" data-toggle="modal" data-target="#help-modal">Contact </button>

                                    </div>
                                </div>    


<div class="card border cta-box">
                                    <div class="card-body">
                                     <div class="text-center"> <!--<i class="h2 mdi mdi-email-outline text-dark text-primary"></i>-->
                                     <img src="./Jobs _ QUANTUMHUNTS_files/mail_qh.png" height="64">
                                    <h5 class="m-0 font-weight-bold cta-box-title1 text-left text-dark text-uppercase mb-2 blogmini">Subscribe to Bytes</h5>    
                                    <p class="text-left">Get special offers on the latest developments from our QUANTUM-Bytes.</p>
                                    <div class="form-group text-left" id="subsform">

                                    <input class="form-control form-control-sm mt-1" name="subsemail" id="subsemail">
                                    <button type="button" class="btn btn-sm btn-outline-primary mt-2" id="btn-subscribe"> Subscribe</button>
                                     
                                    </div>
                                    <div class="display-error  alert alert-danger subs-error" style="display: none">
                                    </div>
                                    <div class="display-success  alert alert-info subs-success" style="display: none">
                                    </div>                                    

                                    </div>
                                    </div>
</div>







  <!-- include Google hosted jQuery Library -->
<script src="./Jobs _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#btn-subscribe').click(function(e){
        e.preventDefault();

        var subsemail = $("#subsemail").val();
        //alert(subsemail);
        
        $.ajax({
            type: "POST",
            url: "http://localhost/user/set/subscribe/",
            dataType: "json",
            data: {email:subsemail},            
            success : function(data){
                if (data.code == "200")
                {
                    $(".subs-success").show(); 
                    $(".subs-error").hide(); 
                    $("#subsform").hide();
                    $(".subs-success").html(""+data.msg+"");
                    $(".subs-success").css("display","block");
                } 
                else {
                    //alert("Success: " +data.msg);
                    $(".subs-error").html(""+data.msg+"");
                    $(".subs-error").css("display","block");
                }
            }
        });


      });
  });
</script>













                                <div class="card border cta-box overflow-hidden">
                                    <div class="card-body ribbon-box">
                                        <!--<span class="badge badge-primary">Top Jobs</span>-->
                                        <h5 class="mb-0 font-weight-bold mb-1 text-left text-uppercase text-primary purpletitle">Top Jobs</h5>
                                        <p>&nbsp;</p>
                                        <!--<div class="ribbon-two ribbon-two-primary"><span>Top Jobs</span></div>-->



                                    <!--
<div class="text-center cta-box1">
<img src="http://localhost/user/assets/images/hero/mail_qh.png" height="64">
</div>

<h3 class="m-0 mb-3 font-weight-bold cta-box-title text-left">Popular Jobs</h3>
-->




<div class="media mt-2 mb-2">
    <a href="http://localhost/job/anti-money-laundering-lead-sensiple-india-pvt-ltd-chennai">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/anti-money-laundering-lead-sensiple-india-pvt-ltd-chennai">  
                                                     
                                                        <strong class="text-dark hoverzoom">Anti Money Laundering Lead</strong><br>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span>,
                                                       <span class="text-muted">Chennai, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/anti-money-laundering-lead-sensiple-india-pvt-ltd-chennai">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Anti Money Laundering Lead</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/anti-money-laundering-lead-chennai--india/1">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Anti Money Laundering Lead</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/anti-money-laundering-lead-chennai--india/1">Anti Money Laundering Lead</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Sensiple India Pvt Ltd                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Chennai, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job1').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid1").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job1").html('Saved');
                    $("#job1").removeClass('btn-primary');
                    $("#job1").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 2 Software company <BR/>
                                        Anti Money Laundering Lead <BR/>
                                        Chennai, India <BR/>
                                        Permanent  <BR/>
                                        Finance  <BR/>
                                          <BR/>
                                        We are a New Jersey corporation, established in 1999. Our footprints around the globe help us to ensure that we consistently maintain our delivery standards. We deliver IT products and services in the areas of BFSI, Customer Experience, Digital & Enterprise Transformation, Infrastructure and Independent Testing from ideation to execution, giving our clients an edge to outperform the competition. We do also provide Consulting and Staffing services in these areas. We are an ISO and CMMI 3 certification. <BR/>
                                        B.E/B.Tech <BR/>
                                        5,00,000 <BR/>
                                        7,00,000 <BR/>
                                        INR <BR/>
                                        AML, Finance, Business Analyst <BR/>
                                        5 <BR/>
                                        26/02/2020 <BR/>
                                        26/03/2020 <BR/>
                                        26/02/2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="http://localhost/job/senior-business-automation-associate-soroco-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/senior-business-automation-associate-soroco-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Senior Business Automation Associate</strong><br>
                                                       <span class="text-muted">Soroco</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/senior-business-automation-associate-soroco-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Senior Business Automation Associate</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/senior-business-automation-associate-bangalore--india/2">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Senior Business Automation Associate</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/senior-business-automation-associate-bangalore--india/2">Senior Business Automation Associate</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Soroco                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job2').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid2").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job2").html('Saved');
                    $("#job2").removeClass('btn-primary');
                    $("#job2").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Leading Artificial Intelligence Startup <BR/>
                                        Senior Business Automation Associate <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        DeepTech  <BR/>
                                          <BR/>
                                        We are a US-based Leading Software company providing AI based solutions to their clients. Their goal is to make work place smarter and provides support to top clients across various industries such as Retail/E-commerce, Banking, Financial, Healthcare and Airlines.
 <BR/>
                                        B.E/B.Tech <BR/>
                                        10,00,000 <BR/>
                                        12,00,000 <BR/>
                                        INR <BR/>
                                        Artificial Intelligence, Machine Learning <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="http://localhost/job/full-stack-developer-infosys-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/full-stack-developer-infosys-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Full Stack Developer</strong><br>
                                                       <span class="text-muted">Infosys</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/full-stack-developer-infosys-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">Infosys</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/full-stack-developer-bangalore--india/3">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">Infosys</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/full-stack-developer-bangalore--india/3">Full Stack Developer</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Infosys                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job3').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid3").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job3").html('Saved');
                    $("#job3").removeClass('btn-primary');
                    $("#job3").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Full Stack Developer <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        Leading provider of next generation consulting, technology and outsourcing solutions. Ranks as one among the top 100 most innovative companies in Forbes.
 <BR/>
                                        B.E <BR/>
                                        5,00,000 <BR/>
                                        8,00,000 <BR/>
                                        INR <BR/>
                                        Java , Full stack <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="http://localhost/job/associate-consultant-fresher-tcs-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/associate-consultant-fresher-tcs-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Associate Consultant- Fresher</strong><br>
                                                       <span class="text-muted">TCS</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/associate-consultant-fresher-tcs-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Associate Consultant- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/associate-consultant--fresher-bangalore--india/6">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Associate Consultant- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/associate-consultant--fresher-bangalore--india/6">Associate Consultant- Fresher</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        TCS                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job6').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid6").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job6").html('Saved');
                    $("#job6").removeClass('btn-primary');
                    $("#job6").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Associate Consultant- Fresher <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        (Nasdaq-100 listed) is one of the world’s leading professional services companies, transforming clients’ business, operating and technology models for the digital era.  

 <BR/>
                                        B.E/B.Tech <BR/>
                                        4,00,000 <BR/>
                                        6,00,000 <BR/>
                                        INR <BR/>
                                        Fresher <BR/>
                                        20 <BR/>
                                        26-02-2020 <BR/>
                                        21-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="http://localhost/job/data-scientist-lead-soroco-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/data-scientist-lead-soroco-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Data Scientist Lead</strong><br>
                                                       <span class="text-muted">Soroco</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/data-scientist-lead-soroco-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Data Scientist Lead</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/data-scientist-lead-bangalore--india/7">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Data Scientist Lead</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/data-scientist-lead-bangalore--india/7">Data Scientist Lead</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Soroco                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job7').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid7").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job7").html('Saved');
                    $("#job7").removeClass('btn-primary');
                    $("#job7").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Leading Artificial Intelligence Startup <BR/>
                                        Data Scientist Lead <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        DeepTech  <BR/>
                                          <BR/>
                                        We are a US-based Leading Software company providing AI based solutions to their clients. Their goal is to make work place smarter and provides support to top clients across various industries such as Retail/E-commerce, Banking, Financial, Healthcare and Airlines.
 <BR/>
                                        B.E/B.tech/M.tech <BR/>
                                        6,00,000 <BR/>
                                        10,00.000 <BR/>
                                        INR <BR/>
                                        Artificial Intelligence, Machine Learning, Data Science <BR/>
                                        5 <BR/>
                                        21/02/2020 <BR/>
                                        21/03/2020 <BR/>
                                        21/02/2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="http://localhost/job/software-test-analyst-fresher-tcs-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/software-test-analyst-fresher-tcs-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Software Test Analyst- Fresher</strong><br>
                                                       <span class="text-muted">TCS</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/software-test-analyst-fresher-tcs-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Software Test Analyst- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/software-test-analyst--fresher-bangalore--india/9">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Software Test Analyst- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/software-test-analyst--fresher-bangalore--india/9">Software Test Analyst- Fresher</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        TCS                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job9').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid9").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job9").html('Saved');
                    $("#job9").removeClass('btn-primary');
                    $("#job9").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Software Test Analyst- Fresher <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        (Nasdaq-100 listed) is one of the world’s leading professional services companies, transforming clients’ business, operating and technology models for the digital era.  

 <BR/>
                                        B.E/B.Tech <BR/>
                                        4,00,000 <BR/>
                                        6,00,000 <BR/>
                                        INR <BR/>
                                        Fresher <BR/>
                                        20 <BR/>
                                        26-02-2020 <BR/>
                                        21-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="http://localhost/job/chartered-accountant-corporate-consultant-sensiple-chennai">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/chartered-accountant-corporate-consultant-sensiple-chennai">  
                                                     
                                                        <strong class="text-dark hoverzoom">Chartered Accountant Corporate Consultant</strong><br>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span>,
                                                       <span class="text-muted">Chennai, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/chartered-accountant-corporate-consultant-sensiple-chennai">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Chartered Accountant Corporate Consultant</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/chartered-accountant-corporate-consultant-chennai--india/12">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Chartered Accountant Corporate Consultant</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/chartered-accountant-corporate-consultant-chennai--india/12">Chartered Accountant Corporate Consultant</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Sensiple India Pvt Ltd                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Chennai, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job12').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid12").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job12").html('Saved');
                    $("#job12").removeClass('btn-primary');
                    $("#job12").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Leading Tier 2 Software company <BR/>
                                        Chartered Accountant Corporate Consultant <BR/>
                                        Chennai, India <BR/>
                                        Permanent  <BR/>
                                        Finance  <BR/>
                                          <BR/>
                                        ISO and CMMI 3 certified IT Software company. <BR/>
                                        Completion of CA Finals <BR/>
                                        7,00,000 <BR/>
                                        10,00,000 <BR/>
                                        INR <BR/>
                                        CA, Finance,  <BR/>
                                         <BR/>
                                        26/02/2020 <BR/>
                                        26/03/2020 <BR/>
                                        26/02/2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="http://localhost/job/hr-fresher-tcs-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/hr-fresher-tcs-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">HR- Fresher</strong><br>
                                                       <span class="text-muted">TCS</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/hr-fresher-tcs-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">HR- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/hr--fresher-bangalore--india/10">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">HR- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/hr--fresher-bangalore--india/10">HR- Fresher</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        TCS                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job10').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid10").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job10").html('Saved');
                    $("#job10").removeClass('btn-primary');
                    $("#job10").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        HR- Fresher <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        (Nasdaq-100 listed) is one of the world’s leading professional services companies, transforming clients’ business, operating and technology models for the digital era.  

 <BR/>
                                        B.E/B.Tech/B.sc and MBA HR_2020 Graduates <BR/>
                                        4,00,000 <BR/>
                                        6,00,000 <BR/>
                                        INR <BR/>
                                        Fresher <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        21-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="http://localhost/job/full-stack-developer-hcl-ncr">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/full-stack-developer-hcl-ncr">  
                                                     
                                                        <strong class="text-dark hoverzoom">Full Stack Developer</strong><br>
                                                       <span class="text-muted">HCL</span>,
                                                       <span class="text-muted">NCR,India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/full-stack-developer-hcl-ncr">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">HCL</span><BR/>
                                                       <span class="text-muted">NCR,India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/full-stack-developer-ncr-india/13">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">HCL</span><BR/>
                                                       <span class="text-muted">NCR,India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/full-stack-developer-ncr-india/13">Full Stack Developer</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        HCL                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        NCR,India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job13').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid13").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job13").html('Saved');
                    $("#job13").removeClass('btn-primary');
                    $("#job13").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Full Stack Developer <BR/>
                                        NCR,India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        Leading provider of next generation consulting, technology and outsourcing solutions. Ranks as one among the top 100 most innovative companies in Forbes.
 <BR/>
                                        B.E <BR/>
                                        5,00,000 <BR/>
                                        8,00,000 <BR/>
                                        INR <BR/>
                                        Java , Full stack <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="http://localhost/job/golang-developer-engineer-babu-indore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="http://localhost/job/golang-developer-engineer-babu-indore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Golang Developer</strong><br>
                                                       <span class="text-muted">Engineer Babu</span>,
                                                       <span class="text-muted">Indore,India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="http://localhost/job/golang-developer-engineer-babu-indore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Golang Developer</Strong><BR/>
                                                       <span class="text-muted">Engineer Babu</span><BR/>
                                                       <span class="text-muted">Indore,India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="http://localhost/jobs/view/golang-developer-indore-india/14">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Golang Developer</Strong><BR/>
                                                       <span class="text-muted">Engineer Babu</span><BR/>
                                                       <span class="text-muted">Indore,India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="http://localhost/jobs/view/golang-developer-indore-india/14">Golang Developer</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Engineer Babu                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Indore,India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job14').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid14").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "http://localhost/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job14").html('Saved');
                    $("#job14").removeClass('btn-primary');
                    $("#job14").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Vibrant and Enthusiastic Startup <BR/>
                                        Golang Developer <BR/>
                                        Indore,India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        Leading provider of next generation technology and software solutions from Indore to worldwide.
 <BR/>
                                        B.E <BR/>
                                        5,00,000 <BR/>
                                        9,00,000 <BR/>
                                        INR <BR/>
                                        Java , Full stack <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->



                                    </div>
                                    <!-- end card-body -->
                                </div>   
                                
                                

                                
                                
                            </div>    
                            
                        </div>
                        <!-- end row-->
                        
                    </div> <!-- End Content -->


                 
                

            </div> <!-- end wrapper-->
        </div>
        <!-- END Container -->


<!-- Signup modal-->

<div id="help-modal" class="modal fade" tabindex="1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="background-image1: radial-gradient( circle farthest-corner at 18.7% 37.8%,  rgba(250,250,250,1) 0%, rgba(225,234,238,1) 90% );">

            <div class="modal-body">
                <div class="text-center mt-2 mb-0">
                    
                    <span class="text-success">
                        <span><img src="./Jobs _ QUANTUMHUNTS_files/square1_qh.png" alt="" height="32" width="32"></span>
                    </span>
                </div>
                
                <div class="card-body text-center">

                    <strong class="text-center text-primary blogmini">QUANTUMHUNTS</strong>
                    <span class="d-block text-center mb-2"> Help &amp; Support</span>

                <div class="row auto-mx float-center text-center"> 
                <div class="col-2">
                </div>
                <div class="col-8">
                <p class="text-center mb-2">Use the below form to reach us for any request or enquires. Average response time less than 24 hours.</p>
                </div>
                <div class="col-2">
                </div>
                </div>

                </div>

                <form class="pl-3 pr-3" id="callbackform" action="http://localhost/jobs/#">
                    
                    
                    
<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input class="form-control form-control-sm" type="name" id="name" required="" placeholder="" value=" ">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="company">Company</label>
                        <input class="form-control form-control-sm" type="text" id="companyname" required="" placeholder="">
                    </div>
</div> <!-- end col -->
</div>                    


<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input class="form-control form-control-sm" type="phone" required="" id="phone" value=" ">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">E-Mail</label>
                        <input class="form-control form-control-sm" type="email" required="" id="email" placeholder="" value="">
                    </div>
</div> <!-- end col -->
</div>                    
                    
                    



<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="reason">Subject</label>
                        <select class="form-control form-control-sm" id="reason">
                        <option value="Mentorship">Career development</option>  
                        <option value="Courses">Courses</option>              
                        <option value="Business">Business Enquiry</option>
                        <option value="QH-RECRUITER">Premium Plans</option>                 
                        <option value="Help">Help</option>                
                        <option value="AccountIssues">My QH account</option>                        
                        <option value="Issues">Issues &amp; Complaints</option>                                                
                        </select>                        
                    </div>                    

</div>
</div>          





<div class="row">
<div class="col-md-12">
                    <div class="form-group">
                        <label for="comments">Comments</label>
                        <textarea class="form-control" id="comments" placeholder=""></textarea>
                    </div>                    
</div> <!-- end col -->
</div>          





                    


    
                    <div class="form-group text-left">
                                <div class="display-callback-error  alert alert-danger" style="display: none">
                                </div>

                        <button class="btn btn-primary" type="submit" id="callbacksubmit">Submit </button>
                        <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                    </div>
                    
                    
                    <small>By clicking "Submit" I agree to be contacted at the number provided with more information or offers about <span class="text-uppercase text-primary">QuantumHunts</span>. I understand these calls or texts may use computer-assisted dialing or pre-recorded messages.</small>

                </form>
                
                <div class="form-group">  
                                <div class="display-callback-success  alert alert-info" style="display: none">
                                   
                                </div>
                </div>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->









  <!-- include Google hosted jQuery Library -->
<script src="./Jobs _ QUANTUMHUNTS_files/jquery.min.js(1).download"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#callbacksubmit').click(function(e){
        e.preventDefault();

    var usertype = $('input[name=customRadio1]:checked').val();
        //alert(usertype);

        var pageurl="http://localhost/jobs/";
        var email = $("#email").val();
        var phone = $("#phone").val();        
        var name = $("#name").val();
        var company = $("#companyname").val();
        var reason =$('#reason option:selected').val();
        var comments = $("#comments").val(); 
        //var comments = "";
        
        //alert(email+name+phone+reason+comments+company);
        
        $.ajax({
            type: "POST",
            url: "http://localhost/user/set/callbacks/",
            dataType: "json",
            data: {name:name,email:email,phone:phone,company:company,reason:reason,comments:comments,pageurl:pageurl},            
            success : function(data){
                if (data.code == "200")
                {
                    $(".display-callback-success").show(); 
                    $(".display-callback-error").hide(); 
                    $("#callbackform").hide();
                    $(".display-callback-success").html(""+data.msg+"");
                    $(".display-callback-success").css("display","block");
                } 
                else {
                    //alert("Success: " +data.msg);
                    $(".display-callback-error").html(""+data.msg+"");
                    $(".display-callback-error").css("display","block");
                }
            }
        });


      });
  });
</script>



</div>


    <div id="ReferModal" class="modal " tabindex="-1" role="dialog">
      <div class="modal" tabindex="-1" role="dialog" style="padding-right: 16px; display: block;overflow-y: scroll;" aria-modal="true">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
          <div class="modal-content border-5">
            <div class="modal-body" style="overflow-y: auto;"><div class="card-body">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
              <div class="rounded mb-1 pt-0 mt-0">
		<center> <h5 class="d-block  mt-0 mb-3 text-primary text-uppercase  blogmini">📢 Invite Your Friends
                </h5></center>
		<ul class="nav nav-tabs tab-grad mt-3">
						
						<li class="nav-item "> <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" data-toggle="tab" href="http://localhost/jobs/#profile1">Invite via Mail  </a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="http://localhost/jobs/#home1"> Share via link</a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="http://localhost/jobs/#referrals"> My Rewards</a> </li>						
					</ul>
	

<div class="tab-content">
    <div class="tab-pane show active" id="profile1">
	<br>
        <p>You can now invite your friends through mail so that they join world's 1st video centric job platform. You would get rewarded when your friends create their account with us.</p>
                <div class="media-body">
                  <!--<strong class="d-block  mt-2 text-primary text-uppercase purpletitle">Invite via Mail
                  </strong> -->
                 
                <div class="row">
                  
                  <div class="col-lg-12 col-12">
                      
                      <div class="row">
                      <div class="col-6">
                      
                    <span class="media-body mt-2">
                      <div class="form-group">
                        <label for="inputName">Name
                        </label>
                        <input type="text" class="form-control form-control-sm" id="inputName" required="" placeholder="Enter your Friend&#39;s name..">
                      </div> 
                      <div id="div1">
                      </div> 
                      <div class="alert alert-primary" id="invitenamemsg" style="display:none;">Please Enter Your Friend's Name
                      </div>
                      <div class="form-group">
                        <label for="inputEmail">Email
                        </label>
                        <input type="email" class="form-control form-control-sm" id="inputEmail" required="" placeholder="Enter your Friend&#39;s mail..">
                      </div> 
                      <div id="div2">
                      </div> 
                      <div class="alert alert-primary" id="inviteemailmsg" style="display:none;">Please Enter Your Email Id
                      </div>
                      <div class="alert alert-primary" id="invitevalidemailmsg" style="display:none;">Please Enter a Valid Email Id
                      </div>
                      <button class="btn btn-primary btn-sm" id="submit">Submit 
                      </button>
                    </span>
                    
                    </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="alert text-primary" id="invitesuccessmsg" style="display:none;">Success. Your friend will receive an email very soon.</div>
                			<div class="alert text-danger " id="invitefailuremsg" style="display:none;">Please try again. </div><p></p><br>
                            <div class="alert text-danger " id="inviteloginmsg" style="display:none;">Please login To invite your friends.
                      </div>
                        </div>
                    </div>                
                    
                    
                </div>
<div class="col-3 col-lg-4">
                  </div>
                <div class="col-3">
                </div>
                <div class="col-12">
                </div>
                </div>
            </div>
    </div>
     <div class="tab-pane" id="home1"><br>
        <p>Share this link with your friends so that they join World's 1st video resume platform. You would get rewarded when your friends create their video resume with us.</p>
	                <div class="row mt-3 mx-0">

                  <div class="col-12 col-md-5  my-auto mx-auto">
                        <div class="input-group input-group-merge">
                      <input class="form-control" type="text" value="http://localhost/?ref=" id="copybox">
                    <div class="input-group-append">
                      <button class="btn btn-primary-two btn-sm font-weight-bold text-dark" onclick="copyfunction()">Copy my link
                      </button>
                        </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-2 text-center my-auto mx-auto">
                    <p style="text-center font-size:20;">or
                    </p>
                  </div>
                  <div class="col-12 col-md-5  my-auto mx-auto">
                    <ul class="share-buttons">
                      
                      
                      <a class="mr-1" href="https://www.facebook.com/sharer/sharer.php?u=http://localhost/?ref=;" title="Share on Facebook" target="_blank" onclick="window.open(&#39;https://www.facebook.com/sharer/sharer.php?u=&#39; + http://localhost/signup/?ref=  Create a Professional Login+ &#39;&amp;quote=Apply for this opportunity&#39; ); return false;">
                        <img alt="Share on Facebook" src="./Jobs _ QUANTUMHUNTS_files/facebook.png">
                      </a>            
                      
                      
                      <a class="mr-1" href="https://twitter.com/intent/tweet?text=http://localhost/?ref=%20Create%20a%20Professional%20Login" title="Click to share this post on Twitter" "="" target="_blank" onclick="window.open(&#39;https://twitter.com/intent/tweet?text=&#39; + http://localhost/job/ + &#39;:%20&#39;  + Apply for this opportunity); return false;">
                      <img alt="Tweet" src="./Jobs _ QUANTUMHUNTS_files/twitter.png">
                      </a>

                    <a class="mr-1" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=http://localhost/?ref=;title=&amp;summary=&amp;source=" target="_blank" title="Share on LinkedIn">
			<img alt="Share on LinkedIn" src="./Jobs _ QUANTUMHUNTS_files/linkedin.png">
                      </a> 
                    </ul>
                </div>
              </div>
    
 	<div class="mt-1 mb-1">
              <br>  <br>
              </div>
              
              <div class="row mt-2 mx-0">

                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row ">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-link text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 1 
                        </h5>    
                        <p class="text-secondary font-13 mb-0 mt-0 pb-0 pt-0 px-0">Share Link with your friends   
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
              
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-user-group text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 2
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">Ask your friends to create video resume  
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mt-n3 ">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-trophy text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 3 
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">We will reward your account 
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div></div>
              
              
    <div class="tab-pane" id="referrals">
        <p class="mt-3">Here is the stats of the valid users who have signed up based on your referral. Better your own numbers by speaking about our platform to your friends and acquaintance. share your referral link today.</p>
        <div class="row">
        <div class="col-4 col-xs-12 col-sm-12 col-md-4">



<div class="card tilebox-one shadow">
                                    <div class="card-body">
                                        <i class="uil uil-users-alt float-right"></i>
                                        <h6 class="text-uppercase mt-0 blogmini text-primary">Verified Users</h6>
                                        <h2 class="my-2" id="active-users-count"></h2>
                                        <p class="mb-0 text-muted">
                                            <span class="text-nowrap">Since signup</span>  
                                        </p>
                                    </div> <!-- end card-body-->
                                </div>



        </div>
        </div>

    </div>
              
</div>



</div>
    </div>
        </div>
      </div>
    </div>
    </div>
  <br>
  <br>
  <br>
  <br>
  <br>
  </div>
<script src="./Jobs _ QUANTUMHUNTS_files/jquery.min.js(1).download">
</script>
<script>
  function copyfunction() {
    var copyText = document.getElementById("copybox");
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
  }
  $(document).ready(function(){
    $('#submit').click(function(){
      var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
      var name = $('#inputName').val();
      var email = $('#inputEmail').val();
      if(name.trim()=='')
      {
        //document.getElementById("div1").innerHTML="Enter a value";
        //document.getElementById("div1").style.color="Red";
        $('#inputName').focus();
      }
      else if(email.trim() == '' ){
        //document.getElementById("div2").innerHTML="Enter the correct email address";
        //document.getElementById("div2").style.color="Red";
        $('#inputEmail').focus();
      }
      else if(email.trim() != '' && !reg.test(email)){
        //$("#invitevalidemailmsg").css("display","block");
        $('#inputEmail').focus();
      }
      else{
        
        $.ajax({
          type:"POST",
          url:"http://localhost/invite/send/",
          dataType: "json",
          data:{
            name:name,email:email},
          success:function(data){
            if(data.status == 'ok'){
               $("#invitesuccessmsg").css("display","block");
		$("#inviteloginmsg").hide();
		$("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitesuccessmsg").hide();
              }, 4000);              
            }
            else{ if(data.status=='error'){
             $("#inviteloginmsg").css("display","block");
	     $("#invitesuccessmsg").hide();
	     $("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitevalidemailmsg").hide();
              }, 4000);                            
              }
		else{
              $("#invitefailuremsg").css("display","block");
		$("#invitesuccessmsg").hide();
	     $("#inviteloginmsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitefailuremsg").hide();
              }, 4000);                            
            }
	 }
          }
        }
              );
      }
    }
                      );
  }
                   );
</script>

<?php
      include($root."/jobs/footer.php");

        ?>


