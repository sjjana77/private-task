<div id="meet" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-left">


                        <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold">Interview Details</h5> 
                        
                        <p class="text-left ">You can now attend tour interview publish to recruiters.</p>
                        <div class="card">
   <div class="card-body border">
   <div id="interviewid_meet"></div>
   <div id="interviewcompanym"></div>
   <div id="interviewjobm"></div>
   <div id="type"></div>
   <div id="interviewendm"></div>
   <div id="sstime"></div>
   <div id="eetime"></div>
   <div id="locationm"></div>
   <div id="interviewlink"></div>

    </div>
   </div>


                        <p class="text-center mt-3">
                        <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button>    	                                                           
                        </p>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->