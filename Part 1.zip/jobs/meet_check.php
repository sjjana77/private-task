<?php
session_start();
$flow="1";


 $code=200;
 $meet_id = $_POST["interview_id2"];
 
    $db_servername='localhost';
    $db_username='root';
    $db_password='';
    $db_dbname='project';

$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
   $sql2 = "SELECT * FROM vj_interviews WHERE interview_id='$meet_id'";
    $result2 = $conn->query($sql2);
    if ($result2->num_rows > 0) {
        // output data of each row
      
        while($row = $result2->fetch_assoc()) {
            $type=$row['interview_type'];
                $application_id2 = $row["interview_appid"];
                  $company_title=$row["interview_company"];
                  $job_title=$row["interview_job"];      
                $location = $row['interview_ref'];
                $end = $row['interview_schedule_end_date'];
                $stime=$row['interview_ms'];
                $etime=$row['interview_me'];
            
        }
    }        


    echo json_encode(['code'=>200, 'location'=>$location, 'end'=>$end, 'company'=>$company_title, 'job'=>$job_title, 'type'=>$type,'sstime'=>$stime,'eetime'=>$etime]);
   //echo json_encode(['code'=>200]);
    $conn->close(); 
    exit;



?>



