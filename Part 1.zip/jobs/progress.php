<!-- Signup modal-->

<div id="resume-record2" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-left">


                        <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold">Progress</h5> 
                        
                        <p class="text-left hidee">Your previous interview is in progress.
                        <br>
                        Please finish previous interview and then take this interview orelse click clear button to clear all pending interviews.
                        </p>
                        <div class="text-left" id="inff"></div>


                        <p class="text-center mt-3">
                        <button class="clear btn btn-sm btn-outline-primary  mr-2 mt-3">Clear</button>    
                        <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button> 	                                                           
                        </p>



            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script type="text/javascript">
$(document).ready(function(){
  $(".clear").click(function(){    
      $.ajax({
          url: "http://localhost/jobs/clear.php",
          dataType: "json",
          success : function(data){
          
              if (data.code == "200")
              {
                  $(".hidee").css("display","none");
                  document.getElementById("inff").innerHTML="Interviews are cleared successfully";
              }
          }
        });
    });
});
</script>
      











