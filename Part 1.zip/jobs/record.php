

<div id="testing"></div>
<script type="text/javascript">
            function textToAudio(msg) {
                
                let speech = new SpeechSynthesisUtterance();
                speech.lang = "en-US";
                
                speech.text = msg;
                speech.volume = 1;
                speech.rate = 1;
                speech.pitch = 1;
                
                window.speechSynthesis.speak(speech);
            }
		</script>
<script type="text/javascript">
 //checking
var question_set;

let userAgentString =  
              navigator.userAgent; 
        
          // Detect Chrome 
          let chromeAgent =  
              userAgentString.indexOf("Chrome") > -1; 
        
          // Detect Internet Explorer 
          let IExplorerAgent =  
              userAgentString.indexOf("MSIE") > -1 ||  
              userAgentString.indexOf("rv:") > -1; 
        
          // Detect Firefox 
          let firefoxAgent =  
              userAgentString.indexOf("Firefox") > -1; 
        
          // Detect Safari 
          let safariAgent =  
              userAgentString.indexOf("Safari") > -1; 
                
          // Discard Safari since it also matches Chrome 
          if ((chromeAgent) && (safariAgent))  
              safariAgent = false; 
                      if(safariAgent==true){
                      
                      }
                      else{
                    /*    
*/

$(document).ready(function(){
  $("#startButton").click(function(e){
    e.preventDefault();
    navigator.getMedia = ( navigator.getUserMedia || // use the proper vendor prefix
                       navigator.webkitGetUserMedia ||
                       navigator.mozGetUserMedia ||
                       navigator.msGetUserMedia);

navigator.getMedia({video: true}, function() {
    /*
    for(let h=1; h<=3; h++){
      alert(h);
      if(lastclick==h){
        
      }
      else{
        st = "startt"+h;
        document.getElementById(st).disabled = true;
      }

    }
    */
  var setno = set_no;

  var datte = starting_date;
  $.ajax({
          url: "http://localhost/jobs/response.php",
          type: "POST",
          dataType: "json",
          data: {setno:setno, setid:sett_id, today2:datte},
          success : function(data){
              if (data.code == "200")
              {
                lk = 1;
                var tym=0;
                var question;
                var lenn=data.msg.length;
                main();
                async function task(i) 
{ // 3
  await timer(i);
  console.log(`Task ${i} done!`);
}

function timer(ms) { return new Promise(res => setTimeout(res, ms)); }
   


async function main() 
{
  
  let tt=0;
  for(let i = 0; i < lenn; i+=2) 
  {
   /* 
    if(i==0){
      let aa="Hi Janardh, start your interview by clicking attend button";
      textToAudio(aa);
      
      await task(4);
    } 
    */ 
       question=data.msg[i];
       if(data.set_audible=="1"){
       textToAudio(question);
       }
       document.getElementById('course-apply-success').innerHTML = question;
       for(tt=(data.msg[i+1]*60); tt>0; tt--){
         
         let uio=1000;
         
         document.getElementById('course-apply-success2').innerHTML = Math.floor(tt)+" seconds left to answer";
         
         await task(uio);
         
       }
  
       
  }

}

              }
          }
        });  
      }, function() {
        $("#startButton").show(); 
      document.getElementById('course-apply-success').innerHTML = "Permission for camera is denied!";
    });     
});
});
/*
        
            */
                      } 
  
  </script>

<script type="text/javascript">

      function sendVideoToAPI2 (blob, visiparam) {
    //alert("Api");
    
    let fd = new FormData();
    let vfile = new File([blob], 'recording');

    
    fd.append('data', vfile);
    console.log(fd); // test to see if appending form data would work, it didn't this is completely empty. 


    let vform = new FormData();

    vform.append("file",vfile);
    
   
   
    vform.append("visibilityoption",visiparam);
    vform.append("interview_id",sett_id);
    vform.append("time",starting_date);
   
    
        $.ajax({
   contentType: false,
         cache: false,
            type: "POST",
            
            url: "http://localhost/jobs/upload.php",
            processData: false,            
            data:vform,            
            success : function(data)
            {
                var response = JSON.parse(data);
                $("#storeButton").hide();
                $("#displayButton").hide();
                $("#completeButton").show();
                $("#recordingcontainer").hide();
                    
            }
        });
      }    
</script>

  <button id="startButton" onclick="recording()" class="btn btn-primary btn-sm mr-1">
Begin Interview</button>
  <div id="progress" style="display: none;">Your interview is in progress</div>
  <div class="row" id="ins">
  <div class="col-6">
  
  <div class="card">
   <div class="card-body border">
   Instructions to be followed <br>
   1. Start the interview <br>
   2. Grant permission for camera <br>
   3. Time left is for each question <br>
    </div>
   </div>
   </div>
   <div class="col-6">
   <div class="card">
   <div class="card-body border">
   <div id="interviewid"></div>
   <div id="interviewcompany"></div>
   <div id="interviewjob"></div>
   <div id="interviewend"></div>
   <div id="interviewsubject"></div>
   
    </div>
   </div>

   </div>
  </div>
  

  <button id="stopButton" class=" btn btn-primary-two text-dark font-weight-bold btn-sm" style="display:none"><i class="mdi mdi-square text-danger mr-1 font-11"></i>  Stop</button>

  <button id="storeButton" class=" btn btn-primary btn-sm mr-1" style="display:none"><i class="mdi mdi-check-circle text-light mr-1 font-11"></i>  Upload</button>
  <div id="displayButton" style="display:none"><br> 
  <p class="text-center align-middle align-center">
  <span class="lead bg-primary text-white">One step to complete your interview <br>
  wait for few seconds</span> <br>
    <img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/ab79a231234507.564a1d23814ef.gif" style="height:24px;width:24px;" class="text-center align-middle align-center">
    </p>
  </div>
  <div id="completeButton" style="display:none"> <span class="lead bg-primary text-white" id="complete">
  Your interview is successfully completed!</span> <br>
  <a href="#" data-toggle="modal" data-target="#help-modal">Help and Support</a>
  </div>
  <div id="completeButton2" style="display:none"> <span class="lead bg-primary text-white" id="complete2">
  You already completed this interview!</span>
  </div>
<div class="row mt-3">
<div class="col-12 border" id="previewcontainer">

  
<h5>Preview</h5>
<!-- tj-->
<section>
<!-- tj-->
<div class="row lead no-gutters">

<div class="card col-8 col-xs-12 col-sm-6 col-md-6 col-lg-8 mb-0 coursecard bg-primary" style="color: white;">

<div id="course-apply-success" class="lead pl-1">

Hi <?php echo $_SESSION['candidate_fname']." ".$_SESSION['candidate_lname'];
?>, brace up for your interview</div>
</div>
<div class="card col-4 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 coursecard bg-warning">
<div id="course-apply-success2" class="lead pl-1">Time left</div>
</div>
</div>
</section>
  <!-- tj-->
  <video  class="video-js video-tech" id="preview" autoplay muted style="width:100%;height:400px;"
    preload="true"
    fluid ="true"  
    width="640"
    height="400"    
  
  ></video>
  
  <!-- tj-->
  <script type="text/javascript">




</script>
<script>

    </script>
<!-- tj-->
</div>
</div>
<div class="row" id="wait">
<div class="col-12 mt-3 mb-3" id="recordingwait" style="display:none">
    <div class="row">
    <div class="col-2"></div>
    <div class="align-middle align-center col-8 align-center text-center">
       <p class="mt-2">Please wait for your video to be rendered. It usually takes a while, but we will make it awesome for you.</p>
    </div>
    <div class="col-2"></div>    
    </div>
    <p class="text-center align-middle align-center">
    <img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/ab79a231234507.564a1d23814ef.gif" style="height:24px;width:24px;" class="text-center align-middle align-center">
    </p>
</div>    
<div class="col-12 mt-3 mb-3" id="recordingcontainer" style="display:none">

  <video  id="my-video" class="d-none video-js vjs-tech vjs-theme-city vjs-big-play-centered bg-light" style="width:100%;height:400px;"  controls
    preload="true"
    fluid ="true"  
      height="400"  
  ></video>
 
 <a id="downloadButton" class="button" style="display:none;">Download </a>
 
</div>
</div>
<div class="bottom">
  <pre id="log"></pre>
</div>


<script>
 
let preview = document.getElementById("preview");
let recording = document.getElementById("my-video");
//let my-video=document.getElementById("recording");
let startButton = document.getElementById("startButton");
let stopButton = document.getElementById("stopButton");
let downloadButton = document.getElementById("downloadButton");
let logElement = document.getElementById("log");
let recordingTimeMS =3000;


function log(msg) 
{
    //alert("1");
  //logElement.innerHTML += msg + "\n";
}
function wait(delayInMS) 
{
    //alert("2");    
  return new Promise(resolve => setTimeout(resolve, delayInMS));

}
function startRecording(stream, lengthInMS) {

    //alert("3");
  let recorder = new MediaRecorder(stream);
  let data = [];
 
  recorder.ondataavailable = event => data.push(event.data);
  recorder.start();
  
  log(recorder.state + " for " + (lengthInMS/1000) + " seconds...");
 
  let stopped = new Promise((resolve, reject) => {
    recorder.onstop = resolve;
    recorder.onerror = event => reject(event.name);
        //alert("4");
  });

let recorded = wait(lengthInMS).then(
    () => recorder.state == "recording" && recorder.stop() && $("#stopButton").hide() && alert("5")
);
 
  return Promise.all([
    stopped,
    recorded
  ])
  .then(() => data);
      //alert("6");
}
function stop(stream) 
{
        //alert("7");
 stream.getTracks().forEach(track => track.stop());
 $("#stopButton").hide();  
 $("#startButton").show();    
 $("#previewcontainer").hide();     
 $("#recordingwait").show();    
    
}
//checking
checkBrowser2();
function checkBrowser2() { 
          
          // Get the user-agent string 
          let userAgentString =  
              navigator.userAgent; 
        
          // Detect Chrome 
          let chromeAgent =  
              userAgentString.indexOf("Chrome") > -1; 
        
          // Detect Internet Explorer 
          let IExplorerAgent =  
              userAgentString.indexOf("MSIE") > -1 ||  
              userAgentString.indexOf("rv:") > -1; 
        
          // Detect Firefox 
          let firefoxAgent =  
              userAgentString.indexOf("Firefox") > -1; 
        
          // Detect Safari 
          let safariAgent =  
              userAgentString.indexOf("Safari") > -1; 
                
          // Discard Safari since it also matches Chrome 
          if ((chromeAgent) && (safariAgent))  
              safariAgent = false; 
        
  
                      if(safariAgent==true){
                      
                      }
                      else{
startButton.addEventListener("click", function() 
{
        //alert("8");
 $("#startButton").hide(); 
 $("#stopButton").hide();
 $("#previewcontainer").show();     
 $("#recordingcontainer").hide();  
 $("#storeButton").hide();
 $("#displayButton").hide();

  
 
  navigator.mediaDevices.getUserMedia({
    video: true,
    audio: true
  }).then(stream => {
    preview.srcObject = stream;
    downloadButton.href = stream;
    preview.captureStream = preview.captureStream || preview.mozCaptureStream;
    return new Promise(resolve => preview.onplaying = resolve);
  }).then(() => startRecording(preview.captureStream(), total))
  .then (recordedChunks => {
    let recordedBlob = new Blob(recordedChunks, { type: "video/webm" });
    recording.src = URL.createObjectURL(recordedBlob);
//    my-video.src = URL.createObjectURL(recordedBlob);    
    downloadButton.href = recording.src;
    downloadButton.download = "RecordedVideo.webm";

 $("#previewcontainer").hide();         
 $("#startButton").hide(); 
 $("#stopButton").hide();
 $("#storeButton").hide();
 $("#displayButton").show();
 $("#recordingwait").hide();     
 $("#recordingcontainer").show(); 

        var visitag = $("#visibletag").val();
        //alert(visitag); 
      sendVideoToAPI2(recordedBlob,visitag); 
      

    //alert("9");    
    log("Successfully recorded " + recordedBlob.size + " bytes of " +
        recordedBlob.type + " media.");
  })
  .catch(log);
}, false);stopButton.addEventListener("click", function() {
  stop(preview.srcObject);
  var visitag = $("#visibletag").val();
        //alert(visitag); 
      sendVideoToAPI2(recordedBlob,visitag); 
}, false);   
}   
}
</script>