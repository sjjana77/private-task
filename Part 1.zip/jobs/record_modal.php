<!-- Signup modal-->

<div id="resume-record" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-left">


                        <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold">Interview</h5> 
                        
                        <p class="text-left ">You can now attend tour interview publish to recruiters.</p>
<?php
include ($root."/jobs/record.php");
?>

                        <p class="text-center mt-3">
                        <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button>    	                                                           
                        </p>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->














