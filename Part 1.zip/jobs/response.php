<?php
session_start();
$flow="1";
 $code=200;
 $db_servername='localhost';
 $db_username='root';
 $db_password='';
 $db_dbname='project';
 $time=$_POST["today2"];
$question="";
$empty=array();
$cc=$_POST["setno"];
$id = $_POST["setid"];
$set_audible=0;
if($flow=="1")
{   
    $root=$_SERVER["DOCUMENT_ROOT"];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql8 = "SELECT set_audible FROM vj_question_set WHERE set_id='$cc'";
$result8 = $conn->query($sql8);
if ($result8->num_rows > 0) {
    while($row8 = $result8->fetch_assoc()) {
        if($row8['set_audible']=="Yes" || $row8['set_audible']=="yes" || $row8['set_audible']=="YES"){
            $set_audible = 1;
        }
    }
}

$sql = "SELECT question_question, question_time FROM vj_questions WHERE question_set_id='$cc'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $statuss="success";
    $org=$result->num_rows;
// output data of each row
while($row = $result->fetch_assoc()) {
    array_push($empty, $row['question_question'], $row['question_time']);
    $question=$question.$row['question_question']."|".$row['question_time']."
    ";
    
}
}

$sql1= "UPDATE vj_interviews SET interview_actual_start_date='$time', interview_questions_playback='$question' WHERE interview_id='$id'";
if ($conn->query($sql1) === TRUE) {
   
  }


    	
        echo json_encode(['code'=>200, 'msg'=>$empty, 'set_audible'=>$set_audible]);
        $conn->close(); 
    	exit;
}







?>



