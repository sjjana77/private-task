<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$jana='1';
$conn = new mysqli($db_servername, $db_username, $db_password, $db_dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$time=$_POST['time'];
$visibilityoption=$_POST['visibilityoption'];
$interview_idd=$_POST['interview_id'];
$code=200;
if(isset($_FILES['file']))
{
   if($jana != NULL)
   {
                            $filepresent="true";
                            $img = $_FILES['file']['name'];
                            $tmp = $_FILES['file']['tmp_name'];
                            //$tmp = $tmp.".webm";
                        
                            $imgSize = $_FILES['file']['size'];    

                            $img = str_replace(' ', '-', $img);
                            $img = preg_replace('/[^A-Za-z0-9.\-]/', '', $img);


                            // get uploaded file's extension
                            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
                        
                            // can upload same image using rand function
                            $final_image = rand(1000,1000000)."-".$img;
                            

                            $current_time = new DateTime();
                            $today_folder=date_format($current_time,"Y-m-d-H-i-s");

                            $newpath=$root."/dev/video-message/2/interview/".'1'."/".$today_folder."/";

                            //if (!file_exists('path/to/directory'))
                            if (!file_exists($newpath))
                            {
                                    mkdir($newpath, 0777, true);
                            }
                            $path=$newpath;
                            $vdpath = $path;
                            $path = $path.strtolower($final_image); 
                            $vdpath=$vdpath.$final_image;
                            $today = Date("F j, Y, g:i a");
                            
                                    if(move_uploaded_file($tmp,$path)) 
                                    {
                                        $api_user='1';//hardcode $_SESSION['user_id']
                                        $path=$root.'/dev/video-message/2'.'1'.'/'.'/'.$final_image;
                                        $path = strtolower($path); 
                                        
                                        
                                        $path=substr($path,14);
                                        
                                        $path="https://".$path;
                                        
                                        $sql1= "UPDATE vj_interviews SET interview_actual_end_date='$time', interview_path='$vdpath' WHERE interview_id='$interview_idd'";
                                        if ($conn->query($sql1) === TRUE) {
                                                }
                                        
                                    }
   }
}
echo json_encode(['code'=>200]);
exit;
?>
