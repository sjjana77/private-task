<?php
if(!isset($_SESSION['recruiter_id']) || $_SESSION['recruiter_id']==''){
  //header("Location:http://localhost/jobs/");
}
?>
<style class="vjs-styles-defaults">
      .video-js {
        width: 300px;
        height: 150px;
      }

      .vjs-fluid {
        padding-top: 56.25%
      }
    </style>
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

        <link rel="icon" href="http://localhost/view-job/Jobs%20_%20QUANTUMHUNTS_files/square1_qh.png" type="image/icon type">
<!-- App favicon -->
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<link rel="shortcut icon" href="http://localhost/user/assets/favicon/favicon.ico">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!--
<link rel="shortcut icon" sizes="16x16 24x24 32x32 48x48 64x64" href="http://localhost/user/assets/favicon/favicon.ico">
<link rel="apple-touch-icon" sizes="57x57" href="http://localhost/user/assets/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="http://localhost/user/assets/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="72x72" href="http://localhost/user/assets/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="http://localhost/user/assets/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="http://localhost/user/assets/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="http://localhost/user/assets/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="http://localhost/user/assets/favicon/apple-icon-152x152.png">
<meta name="application-name" content="QuantumHunts QuantumHunts QuantumHunts">
<meta name="msapplication-TileImage" content="http://localhost/user/assets/favicon/apple-icon-144x144.png">
<meta name="msapplication-TileColor" content="#2A2A2A">
-->



<!--Test relative CSS -->
        <link href="./Post a Job _ QUANTUMHUNTS_files/icons.min.css" rel="stylesheet" type="text/css">
        <link href="./Post a Job _ QUANTUMHUNTS_files/app-modern.min.css" rel="stylesheet" type="text/css" id="light-style">


        <!-- App css  - full URL
        <link href="http://localhost/user/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="http://localhost/user/assets/css/app-modern.min.css" rel="stylesheet" type="text/css" id="light-style" />-->
 
        <!--<link href="http://localhost/user/assets/css/app-modern-dark.min.css" rel="stylesheet" type="text/css" id="dark-style" />-->

  <!-- Css Files-->
<!--  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
<!--  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css"> -->
  <link rel="stylesheet" type="text/css" href="./Post a Job _ QUANTUMHUNTS_files/bootstrap-tokenfield.min.css">

<!---->

  <script src="./Post a Job _ QUANTUMHUNTS_files/jquery.min.js.download"></script>
  <script src="./Post a Job _ QUANTUMHUNTS_files/jquery-ui.min.js.download"></script>
  <script src="./Post a Job _ QUANTUMHUNTS_files/bootstrap-tokenfield.js.download"></script>

        
    <!-- Summernote css -->
    <link href="./Post a Job _ QUANTUMHUNTS_files/summernote-bs4.css" rel="stylesheet" type="text/css">
        
    <link href="./Post a Job _ QUANTUMHUNTS_files/simplemde.min.css" rel="stylesheet" type="text/css">        



<link rel="stylesheet" href="./Post a Job _ QUANTUMHUNTS_files/dzsparallaxer.css">
<link rel="stylesheet" href="./Post a Job _ QUANTUMHUNTS_files/dzsparallaxer.scss">

<link rel="stylesheet" href="./Post a Job _ QUANTUMHUNTS_files/slick.css">


<link href="./Post a Job _ QUANTUMHUNTS_files/video-js.css" rel="stylesheet">
 
 <!-- City -->
<link href="./Post a Job _ QUANTUMHUNTS_files/index.css" rel="stylesheet">

<link rel="stylesheet" href="./Post a Job _ QUANTUMHUNTS_files/animate.css">

    <link href="./Post a Job _ QUANTUMHUNTS_files/custom.css" rel="stylesheet" type="text/css"> 

  <style>

    
body
{
    //background-color:#eaeaea !important;
    //background-color:whitesmoke !important;
    //background-color:white !important;
   //background-image: radial-gradient( circle 343px at 46.3% 47.5%,  rgba(242,242,242,1) 0%, rgba(241,241,241,1) 72.9% );
}


   
   </style>
   
   
   <!-- Load Facebook SDK for JavaScript 
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v6.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

     
     
      <div class="fb-customerchat"
        attribution=setup_tool
        page_id="616766792169119"
  theme_color="#0073b1">
      </div>
      -->
      


   
<script src="./Post a Job _ QUANTUMHUNTS_files/n32mn51c1zeijlmqlcuboiwezwsdufmk.js.download" async=""></script>

    <style type="text/css">.apexcharts-canvas {
  position: relative;
  user-select: none;
  /* cannot give overflow: hidden as it will crop tooltips which overflow outside chart area */
}

/* scrollbar is not visible by default for legend, hence forcing the visibility */
.apexcharts-canvas ::-webkit-scrollbar {
  -webkit-appearance: none;
  width: 6px;
}
.apexcharts-canvas ::-webkit-scrollbar-thumb {
  border-radius: 4px;
  background-color: rgba(0,0,0,.5);
  box-shadow: 0 0 1px rgba(255,255,255,.5);
  -webkit-box-shadow: 0 0 1px rgba(255,255,255,.5);
}
.apexcharts-canvas.dark {
  background: #343F57;
}

.apexcharts-inner {
  position: relative;
}

.legend-mouseover-inactive {
  transition: 0.15s ease all;
  opacity: 0.20;
}

.apexcharts-series-collapsed {
  opacity: 0;
}

.apexcharts-gridline, .apexcharts-text {
  pointer-events: none;
}

.apexcharts-tooltip {
  border-radius: 5px;
  box-shadow: 2px 2px 6px -4px #999;
  cursor: default;
  font-size: 14px;
  left: 62px;
  opacity: 0;
  pointer-events: none;
  position: absolute;
  top: 20px;
  overflow: hidden;
  white-space: nowrap;
  z-index: 12;
  transition: 0.15s ease all;
}
.apexcharts-tooltip.light {
  border: 1px solid #e3e3e3;
  background: rgba(255, 255, 255, 0.96);
}
.apexcharts-tooltip.dark {
  color: #fff;
  background: rgba(30,30,30, 0.8);
}
.apexcharts-tooltip * {
  font-family: inherit;
}

.apexcharts-tooltip .apexcharts-marker,
.apexcharts-area-series .apexcharts-area,
.apexcharts-line {
  pointer-events: none;
}

.apexcharts-tooltip.active {
  opacity: 1;
  transition: 0.15s ease all;
}

.apexcharts-tooltip-title {
  padding: 6px;
  font-size: 15px;
  margin-bottom: 4px;
}
.apexcharts-tooltip.light .apexcharts-tooltip-title {
  background: #ECEFF1;
  border-bottom: 1px solid #ddd;
}
.apexcharts-tooltip.dark .apexcharts-tooltip-title {
  background: rgba(0, 0, 0, 0.7);
  border-bottom: 1px solid #333;
}

.apexcharts-tooltip-text-value,
.apexcharts-tooltip-text-z-value {
  display: inline-block;
  font-weight: 600;
  margin-left: 5px;
}

.apexcharts-tooltip-text-z-label:empty,
.apexcharts-tooltip-text-z-value:empty {
  display: none;
}

.apexcharts-tooltip-text-value,
.apexcharts-tooltip-text-z-value {
  font-weight: 600;
}

.apexcharts-tooltip-marker {
  width: 12px;
  height: 12px;
  position: relative;
  top: 0px;
  margin-right: 10px;
  border-radius: 50%;
}

.apexcharts-tooltip-series-group {
  padding: 0 10px;
  display: none;
  text-align: left;
  justify-content: left;
  align-items: center;
}

.apexcharts-tooltip-series-group.active .apexcharts-tooltip-marker {
  opacity: 1;
}
.apexcharts-tooltip-series-group.active, .apexcharts-tooltip-series-group:last-child {
  padding-bottom: 4px;
}
.apexcharts-tooltip-series-group-hidden {
  opacity: 0;
  height: 0;
  line-height: 0;
  padding: 0 !important;
}
.apexcharts-tooltip-y-group {
  padding: 6px 0 5px;
}
.apexcharts-tooltip-candlestick {
  padding: 4px 8px;
}
.apexcharts-tooltip-candlestick > div {
  margin: 4px 0;
}
.apexcharts-tooltip-candlestick span.value {
  font-weight: bold;
}

.apexcharts-tooltip-rangebar {
  padding: 5px 8px;
}

.apexcharts-tooltip-rangebar .category {
  font-weight: 600;
  color: #777;
}

.apexcharts-tooltip-rangebar .series-name {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
}

.apexcharts-xaxistooltip {
  opacity: 0;
  padding: 9px 10px;
  pointer-events: none;
  color: #373d3f;
  font-size: 13px;
  text-align: center;
  border-radius: 2px;
  position: absolute;
  z-index: 10;
  background: #ECEFF1;
  border: 1px solid #90A4AE;
  transition: 0.15s ease all;
}

.apexcharts-xaxistooltip.dark {
  background: rgba(0, 0, 0, 0.7);
  border: 1px solid rgba(0, 0, 0, 0.5);
  color: #fff;
}

.apexcharts-xaxistooltip:after, .apexcharts-xaxistooltip:before {
  left: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}

.apexcharts-xaxistooltip:after {
  border-color: rgba(236, 239, 241, 0);
  border-width: 6px;
  margin-left: -6px;
}
.apexcharts-xaxistooltip:before {
  border-color: rgba(144, 164, 174, 0);
  border-width: 7px;
  margin-left: -7px;
}

.apexcharts-xaxistooltip-bottom:after, .apexcharts-xaxistooltip-bottom:before {
  bottom: 100%;
}

.apexcharts-xaxistooltip-top:after, .apexcharts-xaxistooltip-top:before {
  top: 100%;
}

.apexcharts-xaxistooltip-bottom:after {
  border-bottom-color: #ECEFF1;
}
.apexcharts-xaxistooltip-bottom:before {
  border-bottom-color: #90A4AE;
}

.apexcharts-xaxistooltip-bottom.dark:after {
  border-bottom-color: rgba(0, 0, 0, 0.5);
}
.apexcharts-xaxistooltip-bottom.dark:before {
  border-bottom-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-xaxistooltip-top:after {
  border-top-color:#ECEFF1
}
.apexcharts-xaxistooltip-top:before {
  border-top-color: #90A4AE;
}
.apexcharts-xaxistooltip-top.dark:after {
  border-top-color:rgba(0, 0, 0, 0.5);
}
.apexcharts-xaxistooltip-top.dark:before {
  border-top-color: rgba(0, 0, 0, 0.5);
}


.apexcharts-xaxistooltip.active {
  opacity: 1;
  transition: 0.15s ease all;
}

.apexcharts-yaxistooltip {
  opacity: 0;
  padding: 4px 10px;
  pointer-events: none;
  color: #373d3f;
  font-size: 13px;
  text-align: center;
  border-radius: 2px;
  position: absolute;
  z-index: 10;
  background: #ECEFF1;
  border: 1px solid #90A4AE;
}

.apexcharts-yaxistooltip.dark {
  background: rgba(0, 0, 0, 0.7);
  border: 1px solid rgba(0, 0, 0, 0.5);
  color: #fff;
}

.apexcharts-yaxistooltip:after, .apexcharts-yaxistooltip:before {
  top: 50%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}
.apexcharts-yaxistooltip:after {
  border-color: rgba(236, 239, 241, 0);
  border-width: 6px;
  margin-top: -6px;
}
.apexcharts-yaxistooltip:before {
  border-color: rgba(144, 164, 174, 0);
  border-width: 7px;
  margin-top: -7px;
}

.apexcharts-yaxistooltip-left:after, .apexcharts-yaxistooltip-left:before {
  left: 100%;
}

.apexcharts-yaxistooltip-right:after, .apexcharts-yaxistooltip-right:before {
  right: 100%;
}

.apexcharts-yaxistooltip-left:after {
  border-left-color: #ECEFF1;
}
.apexcharts-yaxistooltip-left:before {
  border-left-color: #90A4AE;
}
.apexcharts-yaxistooltip-left.dark:after {
  border-left-color: rgba(0, 0, 0, 0.5);
}
.apexcharts-yaxistooltip-left.dark:before {
  border-left-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-yaxistooltip-right:after {
  border-right-color: #ECEFF1;
}
.apexcharts-yaxistooltip-right:before {
  border-right-color: #90A4AE;
}
.apexcharts-yaxistooltip-right.dark:after {
  border-right-color: rgba(0, 0, 0, 0.5);
}
.apexcharts-yaxistooltip-right.dark:before {
  border-right-color: rgba(0, 0, 0, 0.5);
}

.apexcharts-yaxistooltip.active {
  opacity: 1;
}
.apexcharts-yaxistooltip-hidden {
  display: none;
}

.apexcharts-xcrosshairs, .apexcharts-ycrosshairs {
  pointer-events: none;
  opacity: 0;
  transition: 0.15s ease all;
}

.apexcharts-xcrosshairs.active, .apexcharts-ycrosshairs.active {
  opacity: 1;
  transition: 0.15s ease all;
}

.apexcharts-ycrosshairs-hidden {
  opacity: 0;
}

.apexcharts-zoom-rect {
  pointer-events: none;
}
.apexcharts-selection-rect {
  cursor: move;
}

.svg_select_points, .svg_select_points_rot {
  opacity: 0;
  visibility: hidden;
}
.svg_select_points_l, .svg_select_points_r {
  cursor: ew-resize;
  opacity: 1;
  visibility: visible;
  fill: #888;
}
.apexcharts-canvas.zoomable .hovering-zoom {
  cursor: crosshair
}
.apexcharts-canvas.zoomable .hovering-pan {
  cursor: move
}

.apexcharts-xaxis,
.apexcharts-yaxis {
  pointer-events: none;
}

.apexcharts-zoom-icon,
.apexcharts-zoom-in-icon,
.apexcharts-zoom-out-icon,
.apexcharts-reset-zoom-icon,
.apexcharts-pan-icon,
.apexcharts-selection-icon,
.apexcharts-menu-icon,
.apexcharts-toolbar-custom-icon {
  cursor: pointer;
  width: 20px;
  height: 20px;
  line-height: 24px;
  color: #6E8192;
  text-align: center;
}


.apexcharts-zoom-icon svg,
.apexcharts-zoom-in-icon svg,
.apexcharts-zoom-out-icon svg,
.apexcharts-reset-zoom-icon svg,
.apexcharts-menu-icon svg {
  fill: #6E8192;
}
.apexcharts-selection-icon svg {
  fill: #444;
  transform: scale(0.76)
}

.dark .apexcharts-zoom-icon svg,
.dark .apexcharts-zoom-in-icon svg,
.dark .apexcharts-zoom-out-icon svg,
.dark .apexcharts-reset-zoom-icon svg,
.dark .apexcharts-pan-icon svg,
.dark .apexcharts-selection-icon svg,
.dark .apexcharts-menu-icon svg,
.dark .apexcharts-toolbar-custom-icon svg{
  fill: #f3f4f5;
}

.apexcharts-canvas .apexcharts-zoom-icon.selected svg,
.apexcharts-canvas .apexcharts-selection-icon.selected svg,
.apexcharts-canvas .apexcharts-reset-zoom-icon.selected svg {
  fill: #008FFB;
}
.light .apexcharts-selection-icon:not(.selected):hover svg,
.light .apexcharts-zoom-icon:not(.selected):hover svg,
.light .apexcharts-zoom-in-icon:hover svg,
.light .apexcharts-zoom-out-icon:hover svg,
.light .apexcharts-reset-zoom-icon:hover svg,
.light .apexcharts-menu-icon:hover svg {
  fill: #333;
}

.apexcharts-selection-icon, .apexcharts-menu-icon {
  position: relative;
}
.apexcharts-reset-zoom-icon {
  margin-left: 5px;
}
.apexcharts-zoom-icon, .apexcharts-reset-zoom-icon, .apexcharts-menu-icon {
  transform: scale(0.85);
}

.apexcharts-zoom-in-icon, .apexcharts-zoom-out-icon {
  transform: scale(0.7)
}

.apexcharts-zoom-out-icon {
  margin-right: 3px;
}

.apexcharts-pan-icon {
  transform: scale(0.62);
  position: relative;
  left: 1px;
  top: 0px;
}
.apexcharts-pan-icon svg {
  fill: #fff;
  stroke: #6E8192;
  stroke-width: 2;
}
.apexcharts-pan-icon.selected svg {
  stroke: #008FFB;
}
.apexcharts-pan-icon:not(.selected):hover svg {
  stroke: #333;
}

.apexcharts-toolbar {
  position: absolute;
  z-index: 11;
  top: 0px;
  right: 3px;
  max-width: 176px;
  text-align: right;
  border-radius: 3px;
  padding: 0px 6px 2px 6px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.apexcharts-toolbar svg {
  pointer-events: none;
}

.apexcharts-menu {
  background: #fff;
  position: absolute;
  top: 100%;
  border: 1px solid #ddd;
  border-radius: 3px;
  padding: 3px;
  right: 10px;
  opacity: 0;
  min-width: 110px;
  transition: 0.15s ease all;
  pointer-events: none;
}

.apexcharts-menu.open {
  opacity: 1;
  pointer-events: all;
  transition: 0.15s ease all;
}

.apexcharts-menu-item {
  padding: 6px 7px;
  font-size: 12px;
  cursor: pointer;
}
.light .apexcharts-menu-item:hover {
  background: #eee;
}
.dark .apexcharts-menu {
  background: rgba(0, 0, 0, 0.7);
  color: #fff;
}

@media screen and (min-width: 768px) {
  .apexcharts-toolbar {
    /*opacity: 0;*/
  }

  .apexcharts-canvas:hover .apexcharts-toolbar {
    opacity: 1;
  }
}

.apexcharts-datalabel.hidden {
  opacity: 0;
}

.apexcharts-pie-label,
.apexcharts-datalabel, .apexcharts-datalabel-label, .apexcharts-datalabel-value {
  cursor: default;
  pointer-events: none;
}

.apexcharts-pie-label-delay {
  opacity: 0;
  animation-name: opaque;
  animation-duration: 0.3s;
  animation-fill-mode: forwards;
  animation-timing-function: ease;
}

.apexcharts-canvas .hidden {
  opacity: 0;
}

.apexcharts-hide .apexcharts-series-points {
  opacity: 0;
}

.apexcharts-area-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,
.apexcharts-line-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events, .apexcharts-radar-series path, .apexcharts-radar-series polygon {
  pointer-events: none;
}

/* markers */

.apexcharts-marker {
  transition: 0.15s ease all;
}

@keyframes opaque {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

/* Resize generated styles */
@keyframes resizeanim {
  from {
    opacity: 0;
  }
  to {
    opacity: 0;
  }
}

.resize-triggers {
  animation: 1ms resizeanim;
  visibility: hidden;
  opacity: 0;
}

.resize-triggers, .resize-triggers > div, .contract-trigger:before {
  content: " ";
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  overflow: hidden;
}

.resize-triggers > div {
  background: #eee;
  overflow: auto;
}

.contract-trigger:before {
  width: 200%;
  height: 200%;
}
</style><link rel="stylesheet" href="./Post a Job _ QUANTUMHUNTS_files/font-awesome.min.css"></head>

    <body data-layout="detached" class="" data-leftbar-theme="dark" cz-shortcut-listen="true">


   <!-- Pre-loader -->
        <div id="preloader" style="display: none;">
            <div id="status" style="width: 80%; display: none;">
                <span class="text-secondary"></span>
            </div>
            <div id="status">
                <div class="bouncing-loader"><div></div><div></div><div></div></div>
            </div>
        </div>
        <!-- End Preloader-->

        <!--
        <div style="background:#234099;background-image1: radial-gradient( circle farthest-corner at 10% 20%,  rgba(226,240,254,1) 0%, rgba(255,247,228,1) 90% ); background-color1: #E1E7ED  !important;min-height:10px;max-height:30px;height:auto;" class=" m-0 p-0 pl-2 pt-1 pb-1 navbar-custom topnav-navbar text-light bg-primary1 topnav-navbar-primary" style="background1: black1;"><marquee1><Strong><i class="uil uil-shield-exclamation font-weight-bold"></i> Covid-19 Support: </Strong> We are ready to help with your job search. Sign up today.</marquee1></div> 
        -->



        
        <!-- Topbar Start -->
        <div class="navbar-custom topnav-navbar topnav-navbar-dark bg-grad-two1  navbar-default navbar-fixed-top" style="background: slateblue;">
            <div class="container-fluid">


                        
                <!-- LOGO -->
                <a href="http://localhost/jobs/" class="topnav-logo test-dark"> 
                    <span class="topnav-logo-lg text-white text-weight-bold text-uppercase"> 
<!--  
<li class="list-unstyled dropdown notification-list">                               
<i class="dripicons-briefcase noti-icon "></i>
</li>   
-->
<img src="./Post a Job _ QUANTUMHUNTS_files/square1_qh.png" alt="" class="logox">

<!--<Strong>QUANTUMHUNTS</Strong>-->

<!--<img src="http://localhost/user/assets/images/logo/logo.png" alt="" height="48"> -->
                    </span>
                    <span class="topnav-logo-sm">
                        <img src="./Post a Job _ QUANTUMHUNTS_files/square1_qh.png" alt="" height="34">
                        <!--<i class="dripicons-briefcase noti-icon"></i>-->
                    </span>
                </a>

                <ul class="list-unstyled topbar-right-menu float-right mb-0">


              	








              	                           
                <li class="dropdown notification-list mr-md-2  mr-xs-0  d-sm-bloc d-xs-inline-block">
                        <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" role="button" aria-haspopup="false" aria-expanded="false">
                            <i class="fas noti-icon text-light" style="font-size:15px;">&#xf559;</i> <span class="icon-text text-light">Courses</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated dropdown-lg p-0 pt-3 pb-3" style="">
    
                            <div class="p-2">
                                
                                <strong class="font-12 text-dark font-weight-bold pl-2 text-uppercase mt-3 pt-3 blogmini">Course List</strong>
                                <div class="row no-gutters p-0">
                                    <div class="col-xs-6 col-sm-6 col-md-4">
                                        <a class="dropdown-icon-item">
                                            <img class="mygray1 sidebaricon" src="./Post a Job _ QUANTUMHUNTS_files/images" alt="AI &amp; ML with Python" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="2122 learners showed interest on this">
                                            <span class="font-12 mb-0" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="2122 learners showed interest on this">AI and ML</span>
                                        </a>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-4">
                                        <a class="dropdown-icon-item">
                                            <img class="mygray1 sidebaricon" src="./Post a Job _ QUANTUMHUNTS_files/images" alt="Java Programming" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="202 learners showed interest on this">
                                            <span class="font-12" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="202 learners showed interest on this">Full Stack</span>
                                        </a>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-4">
                                        <a class="dropdown-icon-item">
                                            <img class="mygray1 sidebaricon" src="./Post a Job _ QUANTUMHUNTS_files/images" alt="UI &amp; UI" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="285 learners showed interest on this">
                                            <span class="font-12" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="285 learners showed interest on this">UI &amp; UX </span>
                                        </a>
                                    </div>
                
                                </div>
                                
                                
<!--                                <HR/>
                                
                                <Strong class="font-12 text-dark font-weight-bold pl-2 text-uppercase mt-1 pt-1 blogmini">Management</Strong>
-->                                
                                <div class="row no-gutters p-0">
                                    <div class="col-xs-6 col-sm-6 col-md-4">
                                        <a class="dropdown-icon-item">
                                            <img class="mygray1 sidebaricon" src="./Post a Job _ QUANTUMHUNTS_files/2748889.png" alt="Human Resource Management (HRM) Bootcamp" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1507 learners showed interest on this">
                                            <span class="font-12" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="1507 learners showed interest on this">HR Bootcamp</span>
                                        </a>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-4">
                                        <a class="dropdown-icon-item">
                                            <img class="mygray1 sidebaricon" src="./Post a Job _ QUANTUMHUNTS_files/2748889.png" alt="Digital Marketing">
                                            <span class="font-12" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="511 learners showed interest on this">Digi Marketing</span>
                                        </a>
                                    </div>
                                    
                                    <div class="col-xs-6 col-sm-6 col-md-4">
                                        <a class="dropdown-icon-item">
                                            <img class="mygray1 sidebaricon" src="./Post a Job _ QUANTUMHUNTS_files/2748889.png" alt="Human Resource Management (HRM) Bootcamp Fast Track" data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" learners showed interest on this">
                                            <span class="font-12" data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" learners showed interest on this">HR (Fast-track)</span>
                                        </a>
                                    </div>
                
                                </div>
                                
<!--                                
                                <HR/>
                                
                                <Strong class="font-12 text-dark font-weight-bold pl-2 text-uppercase mt-1 pt-1 blogmini">Arts</Strong>
-->
                                <div class="row no-gutters p-0">
                                    <div class="col-xs-6 col-sm-6 col-md-4">
                                        <a class="dropdown-icon-item">
                                            <img class="mygray1 sidebaricon" src="./Post a Job _ QUANTUMHUNTS_files/3658813.png" alt="Content Writing Workshop" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="287 learners showed interest on this">
                                            <span class="font-12" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="287 learners showed interest on this">Content Writing</span>
                                        </a>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-4">
                                        <a class="dropdown-icon-item">
                                            <img class="mygray1 sidebaricon" src="./Post a Job _ QUANTUMHUNTS_files/3658813.png" alt="Business English" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="217 learners showed interest on this">
                                            <span class="font-12" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="217 learners showed interest on this">Spoken English</span>
                                        </a>
                                    </div>

                                    <div class="col-xs-6 col-sm-6 col-md-4">
                                        <a class="dropdown-icon-item">
                                            <img class="mygray1 sidebaricon" src="./Post a Job _ QUANTUMHUNTS_files/3658813.png" alt="Sanskrit for Beginners" data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" learners showed interest on this">
                                            <span class="font-12" data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" learners showed interest on this">Sanskrit</span>
                                        </a>
                                    </div>                                    

                                </div>                                

                                
                                
                                
                            </div>
    
                        </div>
                    </li>                
                
                        


                <!--
                <li class="dropdown notification-list mr-md-2  mr-xs-0 d-none d-sm-block" style="list-style-type:none;">
                        <a class="nav-link" href="http://localhost/course/python-learning-certification">
                           <i class="dripicons-graduation noti-icon text-light" style="font-size:15px;" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Learn"></i><span class="icon-text text-light">Courses</span>
                        </a>
                </li>
                -->

                <li class="dropdown notification-list mr-md-2  mr-xs-0" style="list-style-type:none;">
                        <a class="nav-link">
                           <i class="fas noti-icon  text-light" style="font-size:15px;" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="People">&#xf505;</i><span class="icon-text text-light">People</span>
                        </a>
                </li>                    


                
                <li class="dropdown notification-list mr-md-2  mr-xs-0 d-none d-sm-block" style="list-style-type:none;">
                        <a class="nav-link" href="http://localhost/employer/">
                           <i class="material-icons noti-icon text-light" style="font-size:17px;" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Recruitment product">&#xe7fb;</i><span class="icon-text text-light">Recruit</span>
                        </a>
                </li>           
                
                
                
        
                
                
                
                
                
                


              	                <li class="dropdown notification-list mr-md-2  mr-xs-0  d-none" style="list-style-type:none;">
                        <a class="nav-link" href="http://localhost/post-job">
                           <i class="noti-icon  text-light" style="font-size:15px;">&#xf369;</i><span class="icon-text text-light">Post a Job</span>
                        </a>
                </li>                    
                

              	
                <li class="dropdown notification-list inline-block mr-md-2  mr-xs-0" style="list-style-type:none;">
                        <a class="nav-link" href="http://localhost/jobs/">
                        <i class="noti-icon fas text-light" style="font-size:15px;" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Jobs">&#xf0b1;</i><span class="icon-text text-light">Jobs</span>
                        
                          </a>
                    </li>                    

                    
                    
                    <!--
                    <li class="dropdown notification-list topbar-dropdown d-none d-lg-block">
                        <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" id="topbar-languagedrop" href="#"
                            role="button" aria-haspopup="true" aria-expanded="false">
                            <img src="https://coderthemes.com/hyper/modern/assets/images/flags/us.jpg" alt="user-image" class="mr-1" height="12"> <span
                                class="align-middle">English</span> <i class="mdi mdi-chevron-down"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated topbar-dropdown-menu"
                            aria-labelledby="topbar-languagedrop">

                            

                        </div>
                    </li>
                    -->


	
	
                    <li class="dropdown notification-list mr-md-1 mr-xs-0 d-none d-md-block" style="list-style-type:none;">
                        </li>
	
	      
    	
	
  	
            
                    <li class="dropdown notification-list mr-0">
                        <a class="nav-link dropdown-toggle nav-user arrow-none mr-0" data-toggle="dropdown" id="topbar-userdrop" href="http://localhost/employer/post/jobs/#" role="button" aria-haspopup="true" aria-expanded="false">
                            <span class="account-user-avatar">
                                <img src="./Post a Job _ QUANTUMHUNTS_files/default-avatar.png" alt="user-image" class="rounded-circle">
                            </span>
                            <!--<span>
                                <span class="account-user-name">Test Employer</span>
                                <span class="account-position">Test Employer</span>
                            </span> -->
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated topbar-dropdown-menu profile-dropdown" aria-labelledby="topbar-userdrop">
                          
                            <!-- item-->
                          


                            <!-- item-->
                            <a href="http://localhost/login/logout.php" class="dropdown-item notify-item">
                                <span>Logout</span>
                            </a>

                        </div>
                    </li>
                    
    
                </ul>
                <a class="button-menu-mobile disable-btn">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
                <div class="app-search">
                    <form autocomplete="off-none">
                        <div class="input-group">
                            <input type="text" class="form-control genericsearch" id="search-box" placeholder="Jobs, People, Courses" autocomplete="off">
                          
                            <div class="input-group-append">
                                <button class="btn btn-warning text-dark font-weight-bold" type="submit">Search</button>
                            </div>
                        </div>
                        <div id="suggesstion-box" class="w-45" style="padding-top: 5px; position: absolute; z-index: 1002; max-width: 400px; width: 400px; overflow-wrap: break-word; display: none;">
                        </div>

                    </form>
                    
                    
                <script>  


                

	    //To select country name
        function selectCountry(val, country, latitude, longitude) 
        {
            $("#search-box").val(val);
            //$("#latitude").val(val);
            document.getElementById("longitude").innerHTML = longitude;
            document.getElementById("latitude").innerHTML = latitude;            
            //$("#longitude").val(val);
            $("#suggesstion-box").hide();
        }
    

        

$(document).ready(function()
{
    


$(document).mouseup(function(e) 
{
    //alert("mouse uo");
    var container = $(".suggesstion-box");

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {
        //alert("mouse out");
        
        //$(".suggesstion-box").hide();
        $("#suggesstion-box").hide();
    }
});
    
    
    
    
    /* old search */
    	$("#search-box").keydown(function()
    	{
    	   //document.getElementById("longitude").empty();
            //document.getElementById("latitude").empty();       
    	    
    	    //alert("Hello");
    	    var searchkey=$("#search-box").val();
    	    //alert(searchkey);
    	    
		    $.ajax(
		    {
		        type: "POST",
		        url: "http://localhost/user/get/generic-search/",
		        //data:'keyword='+$(this).val(),
		        data:'keyword='+searchkey,
		        beforeSend: function()
		        {
                    //$("#search-box").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
		        },
		        success: function(data)
		        {
			        $("#suggesstion-box").show();
			        $("#suggesstion-box").html(data);
			        //$("#search-box").css("background","#FFF");
		        }
		    });
	    });
});	    


             </script>

                    
                    
                    
                    
                    
                </div>
            </div>
        </div>
        <!-- end Topbar -->
        <script>
          function back(){
            window.history.back();
          }
        </script>