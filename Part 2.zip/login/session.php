<?php
session_start();
$a=$_POST['a'];
$_SESSION['job_id']=$a;
echo json_encode(['code'=>200, 'msg'=>$a]);
exit;
?>