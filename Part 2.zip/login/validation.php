<?php
session_start();
$_SESSION['candidate_id']='';
$_SESSION['candidate_fname']='';
$_SESSION['candidate_email']='';
$_SESSION['candidate_lname']='';
$_SESSION['candidate_phone']='';
$_SESSION['candidate_img_url']='';
$_SESSION['recruiter_id']='';
$_SESSION['recruiter_fname']='';
$_SESSION['recruiter_email']='';
$_SESSION['recruiter_lname']='';
$_SESSION['recruiter_phone']='';
$flow="1";
$code=200;
$username=$_POST['email'];
$password=$_POST['password'];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
$f='';
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql8 = "SELECT * FROM vj_candidate WHERE candidate_email='$username'";
$result8 = $conn->query($sql8);
if ($result8->num_rows > 0) {
    while($row8 = $result8->fetch_assoc()) {
        if($row8['candidate_password']==$password){
            $f='candidate';
            $_SESSION['candidate_id']=$row8['candidate_id'];
            $_SESSION['candidate_fname']=$row8['candidate_fname'];
            $_SESSION['candidate_email']=$row8['candidate_email'];
            $_SESSION['candidate_lname']=$row8['candidate_lname'];
            $_SESSION['candidate_phone']=$row8['candidate_phone'];
            $_SESSION['candidate_img_url']=$row8['candidate_img_url'];
            $msg='Loggined Successfully';
            echo json_encode(['code'=>200, 'msg'=>$msg]);
            $conn->close(); 
            exit;
        }
        else{
            
            $msg='Incorrect Password';
            echo json_encode(['code'=>201, 'msg'=>$msg]);
            $conn->close(); 
            exit;
        }
        }
    }

    $sql81 = "SELECT * FROM vj_recruiter WHERE recruiter_email='$username'";
    $result81 = $conn->query($sql81);
    if ($result81->num_rows > 0) {
        while($row81 = $result81->fetch_assoc()) {
            if($row81['recruiter_password']==$password){
                $_SESSION['recruiter_id']=$row81['recruiter_id'];
                $_SESSION['recruiter_fname']=$row81['recruiter_fname'];
                $_SESSION['recruiter_email']=$row81['recruiter_email'];
                $_SESSION['recruiter_lname']=$row81['recruiter_lname'];
                $_SESSION['recruiter_phone']=$row81['recruiter_phone'];
                $_SESSION['recruiter_img_url']=$row81['recruiter_img_url'];
                $msg='Loggined Successfully';
                echo json_encode(['code'=>400, 'msg'=>$msg]);
                $conn->close(); 
                exit;
            }
            else{
                $msg='Incorrect Password';
            echo json_encode(['code'=>201, 'msg'=>$msg]);
            $conn->close(); 
            exit;
            }
        }
    }
    else{
        $msg="This username does not match in registered account";
        echo json_encode(['code'=>202, 'msg'=>$msg]);
        $conn->close(); 
        exit;
    }


?>