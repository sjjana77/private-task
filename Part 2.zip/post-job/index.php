<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
?>
<!DOCTYPE html>
<!-- saved from url=(0044)http://localhost/employer/post/jobs/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>VJA | Post a Job</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Post a job on QUANTUMHUNTS platform for your startup, corporate and organization" name="description">
        <meta content="QUANTUMHUNTS" name="author">
        <?php
      include("C:/xampp/htdocs/header_employer.php");

        ?>
        
        




        
        
        

        
<!--
<p>&nbsp;</p>        
    -->    
        
        


        <!-- Start Content-->
        <div class="container-fluid">

            <!-- Begin page -->
            <div class="wrapper">

                <!-- ========== Left Sidebar Start ========== -->


                <!-- Left Sidebar End -->

                <div class="content-page">
                    <div class="content">
                        <!-- <p>&nbsp;</p>
                         start page title 
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Hyper</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Pages</a></li>
                                            <li class="breadcrumb-item active">Profile 2</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title"></h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 



<div class="row">   

<div class="col-xl-8 col-lg-8">
<div class="card border shadow1 pb-2 mandate" style="border-bottom: 1px solid rgb(200, 208, 214); position: relative; z-index: 0; background-image: none;"> 
<h5 class="pl-3 m-0 pt-3 font-weight-normal cta-box-title mb-1 purpletitle text-primary text-uppercase"><b>Video Job Platform</b></h5>
<h4 class="pl-3 pt-0 pb-0 text-dark mb-1 mt-0 font-weight-normal">Post a Job</h4>                
<p class="pl-3 pt-0 mt-0 mt-0 text-dark">Access diverse set of job seekers with every post on VJA. Post your job on the world’s largest professional network and get matched with the most qualified candidates for your role. </p>  







<!--

<div class="row p-3">
          <div class="col-12 col-md-4 aos-init aos-animate" data-aos="fade-up">


            <div class="icon text-info mb-3">
             <i class="h2 uil uil-bill"></i>
            </div>


            <h5 class="text-white">
              Post Jobs for FREE
            </h5>


            <p class="text-white mb-6 mb-md-0">
              Landkit is built to make your life easier. Variables, build tooling, documentation, and reusable components.
            </p>

          </div>
          <div class="col-12 col-md-4 aos-init aos-animate" data-aos="fade-up" data-aos-delay="50">


            <div class="icon text-info mb-3">
             <i class="h2 uil uil-puzzle-piece"></i>
            </div>


            <h5 class="text-white">
              Suited for HRs & Consultants
            </h5>


            <p class="text-white mb-6 mb-md-0">
              Designed with the latest design trends in mind. Landkit feels modern, minimal, and beautiful.
            </p>

          </div>
          <div class="col-12 col-md-4 aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">


            <div class="icon text-info mb-3">
             <i class="h2 uil uil-chart-line"></i>
            </div>



            <h5 class="text-white">
              Flexible dashboard
            </h5>


            <p class="text-white mb-0">
              We've written extensive documentation for components and tools, so you never have to reverse engineer anything.
            </p>

          </div>
        </div>

-->




<div class="backstretch" style="left: 0px; top: 0px; overflow: hidden; margin: 0px; padding: 0px; height: 141px; width: 798.359px; z-index: -999998; position: absolute;"><div class="backstretch-item" style="position: absolute; margin: 0px; padding: 0px; border: none; width: 100%; height: 100%; z-index: -999999;"><img alt="" src="./Post a Job _ QUANTUMHUNTS_files/mild-white-wave.jpg" style="position: absolute; margin: 0px; padding: 0px; border: none; width: 798.359px; height: 399.18px; max-width: none; inset: -129.09px auto auto 0px;"></div></div></div>


        <!--

  <div class="card border shadow1 mb-2 mt-0" style="background-color1: #E1E7ED  !important;"> 
  <div class="card-body">

-->

      <!--
<div class="row">
<div class="col-xl-12 col-lg-12">
-->
          <!--<label class="d-block mb-3" for="who">Who Will Manage this Job?</label>-->


 <!-- end col
      <form id="companyform" autocomplete="off-false">
        <div class="row">

            
 

<div class="col-12 d-none">
 <div class="form-group text-left">
<div class="custom-control custom-radio custom-control-inline d-block">      
<label for="user"> 
<input type="radio" id="customRadio4" name="customRadio1" class="form-control1 custom-control-input1" vale="2"  checked>
I will manage this job</label>
</div>    
</div>
</div>
              
 
 
<div class="col-6 d-none">
<div class="form-group text-left">      
<div class="custom-control custom-radio custom-control-inline d-block">
<label for="user">    <input type="radio" id="customRadio3" name="customRadio1" class="form-control1 custom-control-input1" vale="1" checked=""> 
    My Company </label>   
              <select class="form-control form-control-sm" id="companyid">
                <br />
<b>Warning</b>:  count(): Parameter must be an array or an object that implements Countable in <b>/home3/anands/quantumhunts.com/employer/post/jobs/form.php</b> on line <b>66</b><br />
  
              </select>
              

</div>  
</div>    
</div>



            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        </div>
    </form>    
    -->
        
        <!--
        </div>
        </div>
        
        -->
        
        
        <div class="card border shadow1 mb-2 mt-0"> 
        <div class="card-body">

        
        <div class="row">

            <div class="col-xl-12">
            <div class="form-group">
              <label for="title">Company Name:
              </label>
              <input type="text" id="companyname" class="form-control form-control-sm">
               State the payroll company name<br><hr>
            </div>
            </div>

            <div class="col-xl-6">
            <div class="form-group">
              <label for="title">Job Title
              </label>
              <input type="text" id="title" class="form-control form-control-sm">
            </div>
            </div>
            <div class="col-xl-6">
            <div class="form-group">
              <label for="min">Salary Range (min/max)
              </label>
              


    <div class="row">
      <div class="col-4">
              <input type="text" id="min" class="form-control form-control-sm">
      </div>
      <div class="col-4">
                <input type="text" id="max" class="form-control form-control-sm">
      </div>
   <div class="col-4">
 <select class="form-control form-control-sm" id="cur">
                <option value="AED">AED
                </option> 
              <option value="AFN">AFN
              </option> 
            <option value="ALL">ALL
            </option> 
          <option value="AMD">AMD
          </option> 
        <option value="ANG">ANG
        </option> 
      <option value="AOA">AOA
      </option> 
    <option value="ARS">ARS
    </option> 
  <option value="EURO">EURO
  </option> 
<option value="AUD">AUD
</option> 
<option value="AWG">AWG
</option> 
<option value="AZN">AZN
</option> 
<option value="BAM">BAM
</option> 
<option value="BBD">BBD
</option> 
<option value="BDT">BDT
</option> 
<option value="BGN">BGN
</option> 
<option value="BHD">BHD
</option> 
<option value="BIF">BIF
</option> 
<option value="BMD">BMD
</option> 
<option value="BND">BND
</option> 
<option value="BOB">BOB
</option> 
<option value="BRL">BRL
</option> 
<option value="BSD">BSD
</option> 
<option value="BTN">BTN
</option> 
<option value="BWP">BWP
</option> 
<option value="BYR">BYR
</option> 
<option value="BZD">BZD
</option> 
<option value="CAD">CAD
</option> 
<option value="GBP">GBP
</option> 
<option value="CDF">CDF
</option> 
<option value="CHF">CHF
</option> 
<option value="CLP">CLP
</option> 
<option value="CNY">CNY
</option> 
<option value="COP">COP
</option> 
<option value="CRC">CRC
</option> 
<option value="CUC">CUC
</option> 
<option value="CUP">CUP
</option> 
<option value="CVE">CVE
</option> 
<option value="CZK">CZK
</option> 
<option value="DJF">DJF
</option> 
<option value="DKK">DKK
</option> 
<option value="DOP">DOP
</option> 
<option value="DZD">DZD
</option> 
<option value="EGP">EGP
</option> 
<option value="ETB">ETB
</option> 
<option value="EUR">EUR
</option> 
<option value="FJD">FJD
</option> 
<option value="FKP">FKP
</option> 
<option value="GEL">GEL
</option> 
<option value="GHS">GHS
</option> 
<option value="GIP">GIP
</option> 
<option value="GMD">GMD
</option> 
<option value="GNF">GNF
</option> 
<option value="GTQ">GTQ
</option> 
<option value="GYD">GYD
</option> 
<option value="HKD">HKD
</option> 
<option value="HNL">HNL
</option> 
<option value="HRK">HRK
</option> 
<option value="HTG">HTG
</option> 
<option value="HUF">HUF
</option> 
<option value="IDR">IDR
</option> 
<option value="ILS">ILS
</option> 

<option value="INR" selected="">INR
</option> 

<option value="IQD">IQD
</option> 
<option value="IRR">IRR
</option> 
<option value="ISK">ISK
</option> 
<option value="JMD">JMD
</option> 
<option value="JOD">JOD
</option> 
<option value="JPY">JPY
</option> 
<option value="KES">KES
</option> 
<option value="KGS">KGS
</option> 
<option value="KHR">KHR
</option> 
<option value="KMF">KMF
</option> 
<option value="KPW">KPW
</option> 
<option value="KRW">KRW
</option> 
<option value="KWD">KWD
</option> 
<option value="KYD">KYD
</option> 
<option value="KZT">KZT
</option> 
<option value="LAK">LAK
</option> 
<option value="LBP">LBP
</option> 
<option value="LKR">LKR
</option> 
<option value="LRD">LRD
</option> 
<option value="LSL">LSL
</option> 
<option value="LYD">LYD
</option> 
<option value="MAD">MAD
</option> 
<option value="MDL">MDL
</option> 
<option value="MGA">MGA
</option> 
<option value="MKD">MKD
</option> 
<option value="MMK">MMK
</option> 
<option value="MNT">MNT
</option> 
<option value="MOP">MOP
</option> 
<option value="MRO">MRO
</option> 
<option value="MUR">MUR
</option> 
<option value="MVR">MVR
</option> 
<option value="MWK">MWK
</option> 
<option value="MXN">MXN
</option> 
<option value="MYR">MYR
</option> 
<option value="MZN">MZN
</option> 
<option value="NAD">NAD
</option> 
<option value="NGN">NGN
</option> 
<option value="NIO">NIO
</option> 
<option value="NOK">NOK
</option> 
<option value="NPR">NPR
</option> 
<option value="NZD">NZD
</option> 
<option value="OMR">OMR
</option> 
<option value="PAB">PAB
</option> 
<option value="PEN">PEN
</option> 
<option value="PGK">PGK
</option> 
<option value="PHP">PHP
</option> 
<option value="PKR">PKR
</option> 
<option value="PLN">PLN
</option> 
<option value="PYG">PYG
</option> 
<option value="QAR">QAR
</option> 
<option value="RON">RON
</option> 
<option value="RSD">RSD
</option> 
<option value="RUB">RUB
</option> 
<option value="RWF">RWF
</option> 
<option value="SAR">SAR
</option> 
<option value="SBD">SBD
</option> 
<option value="SCR">SCR
</option> 
<option value="SDG">SDG
</option> 
<option value="SEK">SEK
</option> 
<option value="SGD">SGD
</option> 
<option value="SHP">SHP
</option> 
<option value="SLL">SLL
</option> 
<option value="SOS">SOS
</option> 
<option value="SRD">SRD
</option> 
<option value="STD">STD
</option> 
<option value="SVC">SVC
</option> 
<option value="SYP">SYP
</option> 
<option value="SZL">SZL
</option> 
<option value="THB">THB
</option> 
<option value="TMM">TMM
</option> 
<option value="TND">TND
</option> 
<option value="TOP">TOP
</option> 
<option value="TRY">TRY
</option> 
<option value="TTD">TTD
</option> 
<option value="TWD">TWD
</option> 
<option value="TZS">TZS
</option> 
<option value="UAH">UAH
</option> 
<option value="UGX">UGX
</option> 
<option value="USD">USD
</option> 
<option value="UYU">UYU
</option> 
<option value="VEB">VEB
</option> 
<option value="VND">VND
</option> 
<option value="VUV">VUV
</option> 
<option value="WST">WST
</option> 
<option value="XAF">XAF
</option> 
<option value="XCD">XCD
</option> 
<option value="XOF">XOF
</option> 
<option value="XPF">XPF
</option> 
<option value="YER">YER
</option> 
<option value="ZAR">ZAR
</option> 
<option value="ZMK">ZMK
</option> 
<option value="ZWD">ZWD
</option>          

</select> 
      </div>      
    </div>
            </div>
            </div>
    <div class="col-xl-6">
<div class="form-group">
  <label for="location">Location (City)
  </label>
  <input type="text" id="location" class="form-control form-control-sm">
</div>   
</div>



<script>
    $(document).ready(function () {
        $('#location').typeahead({
            source: function (query, result) {
                $.ajax({
                    url: "http://localhost/user/get/locations/",
					data: 'query=' + query,            
                    dataType: "json",
                    type: "POST",
                    success: function (data) {
						result($.map(data, function (item) {
							return item;
                        }));
                    }
                });
            }
        });
    });
</script>











<div class="col-xl-6">
<div class="form-group">                  
  <label for="location">Employment Type
  </label>                                                
  <select class="form-control form-control-sm" id="type">
    <option value="Full-Time">Full-time
    </option>
    <option value="Part-Time">Part-time
    </option>
    <option value="Contract">Contract
    </option>
    <option value="Temporary">Temporary 
    </option>
    <option value="Volunteer">Volunteer 
    </option>
    <option value="Internship">Internship 
    </option>
  </select>                                                
</div>    
</div>

<!-- end col-->
<div class="col-xl-6">
  <div class="form-group">
    <label for="functions">Job Function
    </label>
    <select class="select2 form-control form-control-sm select2-multiple select2-hidden-accessible" id="functions" data-toggle="select2" multiple="" data-placeholder="" style="border: 1px solid #A29F9C !important;" data-select2-id="functions" tabindex="-1" aria-hidden="true">
      <optgroup>
        <option value="Accounting">Accounting
        </option>
        <option value="Administrative">Administrative
        </option>
        <option value="Arts and Design">Arts and Design
        </option>
        <option value="Business Development">Business Development
        </option>
        <option value="Community &amp; Social Services">Community &amp; Social Services
        </option>
        <option value="Consulting">Consulting
        </option>
        <option value="Education">Education
        </option>
        <option value="Engineering">Engineering
        </option>
        <option value="Entrepreneurship">Entrepreneurship
        </option>
        <option value="Finance">Finance
        </option>
        <option value="Healthcare Services">Healthcare Services
        </option>
        <option value="Human Resources">Human Resources
        </option>
        <option value="Information Technology">Information Technology
        </option>
        <option value="Legal">Legal
        </option>
        <option value="Marketing">Marketing
        </option>
        <option value="Media &amp; Communications">Media &amp; Communications
        </option>
        <option value="Military &amp; Protective Services">Military &amp; Protective Services
        </option>
        <option value="Operations">Operations
        </option>
        <option value="Product Management">Product Management
        </option>
        <option value="Program &amp; Product Management">Program &amp; Product Management
        </option>
        <option value="Purchasing">Purchasing
        </option>
        <option value="Quality Assurance">Quality Assurance
        </option>
        <option value="Real Estate">Real Estate
        </option>
        <option value="Rersearch">Research
        </option>
        <option value="Sales">Sales
        </option>
        <option value="Software Development &amp; Maintenance">Software Development &amp; Maintenance
        </option>
        <option value="Support">Support
        </option>
        <option value="Others">Others
        </option>
      </optgroup>
    </select><span class="select2 select2-container select2-container--default" dir="ltr" data-select2-id="1" style="width: 750.359px;"><span class="selection"><span class="select2-selection select2-selection--multiple" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1" aria-disabled="false"><ul class="select2-selection__rendered"><li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="0" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" role="searchbox" aria-autocomplete="list" placeholder="" style="width: 0.75em;"></li></ul></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
  </div>
  </div>
  
  

  
  <div class="col-xl-6">
  <div class="form-group">
    <label for="seniority">Role Type
    </label>
    <select class="form-control form-control-sm" id="seniority">
      <option value="Internship">Internship
      </option>
      <option value="Entry-level">Entry level
      </option>
      <option value="Associate">Associate
      </option>
      <option value="Mid-Senior-level">Mid-Senior level
      </option>
      <option value="Director">Director
      </option>
      <option value="Executive">Executive
      </option>
      <option value="Others">Others
      </option>
    </select>
  </div>  
  </div>
  


  <div class="col-xl-6">
  <div class="form-group">
    <label>Positions
    </label>
    <input id="positions" class="form-control form-control-sm" type="number" value="1">
  </div>
  </div>
  <div class="col-xl-6">
  </div>        
  
  <div class="col-xl-12">&nbsp;
  </div>
  
  <div class="col-xl-6">
  <div class="form-group">
    <label for="experience">Experience Level (in years)
    </label>
    <div class="row">
      <div class="col-6">
        <label for="seniority">Min</label>
        <select class="form-control form-control-sm" id="experience_min">
                    <option value="0">
            0 
          </option>
                    <option value="1">
            1 
          </option>
                    <option value="2">
            2 
          </option>
                    <option value="3">
            3 
          </option>
                    <option value="4">
            4 
          </option>
                    <option value="5">
            5 
          </option>
                    <option value="6">
            6 
          </option>
                    <option value="7">
            7 
          </option>
                    <option value="8">
            8 
          </option>
                    <option value="9">
            9 
          </option>
                    <option value="10">
            10 
          </option>
                    <option value="11">
            11 
          </option>
                    <option value="12">
            12 
          </option>
                    <option value="13">
            13 
          </option>
                    <option value="14">
            14 
          </option>
                    <option value="15">
            15 
          </option>
                    <option value="16">
            16 
          </option>
                    <option value="17">
            17 
          </option>
                    <option value="18">
            18 
          </option>
                    <option value="19">
            19 
          </option>
                    <option value="20">
            20 
          </option>
                    <option value="21">
            21 
          </option>
                    <option value="22">
            22 
          </option>
                    <option value="23">
            23 
          </option>
                    <option value="24">
            24 
          </option>
                    <option value="25">
            25 
          </option>
                    <option value="26">
            26 
          </option>
                    <option value="27">
            27 
          </option>
                    <option value="28">
            28 
          </option>
                    <option value="29">
            29 
          </option>
                    <option value="30">
            30 
          </option>
                    <option value="31">
            31 
          </option>
                    <option value="32">
            32 
          </option>
                    <option value="33">
            33 
          </option>
                    <option value="34">
            34 
          </option>
                    <option value="35">
            35 
          </option>
                  </select>
      </div>
      <div class="col-6">
        <label for="seniority">Max</label>          
        <select class="form-control form-control-sm" id="experience_max">
                    <option value="0">
            0          </option>
                    <option value="1">
            1          </option>
                    <option value="2">
            2          </option>
                    <option value="3">
            3          </option>
                    <option value="4">
            4          </option>
                    <option value="5">
            5          </option>
                    <option value="6">
            6          </option>
                    <option value="7">
            7          </option>
                    <option value="8">
            8          </option>
                    <option value="9">
            9          </option>
                    <option value="10">
            10          </option>
                    <option value="11">
            11          </option>
                    <option value="12">
            12          </option>
                    <option value="13">
            13          </option>
                    <option value="14">
            14          </option>
                    <option value="15">
            15          </option>
                    <option value="16">
            16          </option>
                    <option value="17">
            17          </option>
                    <option value="18">
            18          </option>
                    <option value="19">
            19          </option>
                    <option value="20">
            20          </option>
                    <option value="21">
            21          </option>
                    <option value="22">
            22          </option>
                    <option value="23">
            23          </option>
                    <option value="24">
            24          </option>
                    <option value="25">
            25          </option>
                    <option value="26">
            26          </option>
                    <option value="27">
            27          </option>
                    <option value="28">
            28          </option>
                    <option value="29">
            29          </option>
                    <option value="30">
            30          </option>
                    <option value="31">
            31          </option>
                    <option value="32">
            32          </option>
                    <option value="33">
            33          </option>
                    <option value="34">
            34          </option>
                    <option value="35">
            35          </option>
                  </select>
      </div>
    </div>
  </div>  
  </div>
  
  <div class="col-xl-6">
  </div>        

  <div class="col-xl-12">&nbsp;
  </div>
  
  
  <div class="col-xl-6">
  <div class="form-group">
    <label for="datestoapply">Dates to Apply
    </label>      
    <div class="row">
    <div class="col-6">
    <label>Start Date
    </label>
        
    <input type="text" id="start" class="form-control form-control-sm" data-provide="datepicker" data-date-format="d-M-yyyy" data-date-autoclose="true">
    </div>
    <div class="col-6">
    <label>Expiry Date</label>        
            <input type="text" id="expiry" class="form-control form-control-sm" data-provide="datepicker" data-date-format="d-M-yyyy" data-date-autoclose="true">
    </div>
    </div>
    
  </div>
  </div>
  
  <div class="col-xl-6">
  </div>        
  
 
  
  
 </div>
 </div>
 </div>
 
 
 
   <link rel="stylesheet" type="text/css" href="./Post a Job _ QUANTUMHUNTS_files/jquery-ui.min.css"> 
  <link rel="stylesheet" type="text/css" href="./Post a Job _ QUANTUMHUNTS_files/bootstrap-tokenfield.min.css">


  <script src="./Post a Job _ QUANTUMHUNTS_files/jquery-ui.min.js.download"></script>
  <script src="./Post a Job _ QUANTUMHUNTS_files/bootstrap-tokenfield.js.download"></script>


  <div class="card border shadow1"> 
  <div class="card-body">  
  
  <div class="row">
       
   <div class="col-xl-12">
  <div class="form-group">
    <label for="keywords-tokenfield">Skills
    </label>
    <div class="tokenfield form-control"><textarea class="form-control form-control-sm" id="keywords" rows="3" tabindex="-1" style="position: absolute; left: -10000px;"></textarea><input type="text" tabindex="-1" style="position: absolute; left: -10000px;"><input type="text" class="token-input ui-autocomplete-input" autocomplete="off" placeholder="" id="keywords-tokenfield" tabindex="0" style="min-width: 60px; width: 722.6px;"></div>
  </div>
</div>  


   <script type="text/javascript">
  $('#keywords').tokenfield({
    autocomplete: {
      source: function (request, response) {
          jQuery.get("http://localhost/user/manage/profile/skills/", {
              query: request.term
          }, function (data) {
              data = $.parseJSON(data);
              response(data);
          });
      },
      delay: 100
    },
    showAutocompleteOnFocus: true
  });
</script> 
  
  

  
<div class="col-xl-12">
<div class="form-group">
  <label for="jd">Job Description
  </label>
  <textarea class="form-control form-control-sm" id="jd" rows="5" name="simplemde1" style="display: none;"></textarea><div class="editor-preview-side"></div><div class="editor-statusbar"><span class="autosave"></span><span class="lines">1</span><span class="words">0</span><span class="cursor">0:0</span></div>
</div>
</div>

<div class="col-xl-12">
<div class="form-group">
  <label for="jq">Educational &amp; Job Qualification
  </label>
  <textarea class="form-control form-control-sm" id="jq" name="simplemde2" rows="3" style="display: none;"></textarea><div class="editor-preview-side"></div><div class="editor-statusbar"><span class="autosave"></span><span class="lines">1</span><span class="words">0</span><span class="cursor">0:0</span></div>
</div>
</div> 


<div class="col-xl-12">
<div class="form-group">
  <label for="companydesc">About Company
  </label>
  <textarea class="form-control form-control-sm" id="companydesc" name="simplemde3" rows="3" style="display: none;"></textarea><div class="editor-preview-side"></div><div class="editor-statusbar"><span class="autosave"></span><span class="lines">1</span><span class="words">0</span><span class="cursor">0:0</span></div>
</div>
</div> 


<div class="col-xl-12">
<div class="form-group">
<label for="project-budget">Industry</label>
<select class="select2 form-control select2-multiple select2-hidden-accessible" id="industry" data-toggle="select2" multiple="" data-placeholder="" data-select2-id="industry" tabindex="-1" aria-hidden="true">
<optgroup>
<option value="Accounting">Accounting</option>
<option value="Airlines/Aviation">Airlines/Aviation</option>
<option value="Alternative Dispute Resolution">Alternative Dispute Resolution</option>
<option value="Alternative Medicine">Alternative Medicine</option>
<option value="Animation">Animation</option>
<option value="Apparel &amp; Fashion">Apparel &amp; Fashion</option>
<option value="Architecture &amp; Planning">Architecture &amp; Planning</option>
<option value="Arts and Crafts">Arts and Crafts</option>
<option value="Automotive">Automotive</option>
<option value="Aviation &amp; Aerospace">Aviation &amp; Aerospace</option>
<option value="Banking">Banking</option>
<option value="Biotechnology">Biotechnology</option>
<option value="Broadcast Media">Broadcast Media</option>
<option value="Building Materials">Building Materials</option>
<option value="Business Supplies and Equipment">Business Supplies and Equipment</option>
<option value="Capital Markets">Capital Markets</option>
<option value="Chemicals">Chemicals</option>
<option value="Civic &amp; Social Organization">Civic &amp; Social Organization</option>
<option value="Civil Engineering">Civil Engineering</option>
<option value="Commercial Real Estate">Commercial Real Estate</option>
<option value="Computer &amp; Network Security">Computer &amp; Network Security</option>
<option value="Computer Games">Computer Games</option>
<option value="Computer Hardware">Computer Hardware</option>
<option value="Computer Networking">Computer Networking</option>
<option value="Computer Software">Computer Software</option>
<option value="Construction">Construction</option>
<option value="Consumer Electronics">Consumer Electronics</option>
<option value="Consumer Goods">Consumer Goods</option>
<option value="Consumer Services">Consumer Services</option>
<option value="Cosmetics">Cosmetics</option>
<option value="Dairy">Dairy</option>
<option value="Defense &amp; Space">Defense &amp; Space</option>
<option value="Design">Design</option>
<option value="Education Management">Education Management</option>
<option value="E-Learning">E-Learning</option>
<option value="Electrical/Electronic Manufacturing">Electrical/Electronic Manufacturing</option>
<option value="Entertainment">Entertainment</option>
<option value="Environmental Services">Environmental Services</option>
<option value="Events Services">Events Services</option>
<option value="Executive Office">Executive Office</option>
<option value="Facilities Services">Facilities Services</option>
<option value="Farming">Farming</option>
<option value="Financial Services">Financial Services</option>
<option value="Fine Art">Fine Art</option>
<option value="Fishery">Fishery</option>
<option value="Food &amp; Beverages">Food &amp; Beverages</option>
<option value="Food Production">Food Production</option>
<option value="Fund-Raising">Fund-Raising</option>
<option value="Furniture">Furniture</option>
<option value="Gambling &amp; Casinos">Gambling &amp; Casinos</option>
<option value="Glass, Ceramics &amp; Concrete">Glass, Ceramics &amp; Concrete</option>
<option value="Government Administration">Government Administration</option>
<option value="Government Relations">Government Relations</option>
<option value="Graphic Design">Graphic Design</option>
<option value="Health, Wellness and Fitness">Health, Wellness and Fitness</option>
<option value="Higher Education">Higher Education</option>
<option value="Hospital &amp; Health Care">Hospital &amp; Health Care</option>
<option value="Hospitality">Hospitality</option>
<option value="Human Resources">Human Resources</option>
<option value="Import and Export">Import and Export</option>
<option value="Individual &amp; Family Services">Individual &amp; Family Services</option>
<option value="Industrial Automation">Industrial Automation</option>
<option value="Information Services">Information Services</option>
<option value="Information Technology and Services">Information Technology and Services</option>
<option value="Insurance">Insurance</option>
<option value="International Affairs">International Affairs</option>
<option value="International Trade and Development">International Trade and Development</option>
<option value="Internet">Internet</option>
<option value="Investment Banking">Investment Banking</option>
<option value="Investment Management">Investment Management</option>
<option value="Judiciary">Judiciary</option>
<option value="Law Enforcement">Law Enforcement</option>
<option value="Law Practice">Law Practice</option>
<option value="Legal Services">Legal Services</option>
<option value="Legislative Office">Legislative Office</option>
<option value="Leisure, Travel &amp; Tourism">Leisure, Travel &amp; Tourism</option>
<option value="Libraries">Libraries</option>
<option value="Logistics and Supply Chain">Logistics and Supply Chain</option>
<option value="Luxury Goods &amp; Jewelry">Luxury Goods &amp; Jewelry</option>
<option value="Machinery">Machinery</option>
<option value="Management Consulting">Management Consulting</option>
<option value="Maritime">Maritime</option>
<option value="Market Research">Market Research</option>
<option value="Marketing and Advertising">Marketing and Advertising</option>
<option value="Mechanical or Industrial Engineering">Mechanical or Industrial Engineering</option>
<option value="Media Production">Media Production</option>
<option value="Medical Devices">Medical Devices</option>
<option value="Medical Practice">Medical Practice</option>
<option value="Mental Health Care">Mental Health Care</option>
<option value="Military">Military</option>
<option value="Mining &amp; Metals">Mining &amp; Metals</option>
<option value="Motion Pictures and Film">Motion Pictures and Film</option>
<option value="Museums and Institutions">Museums and Institutions</option>
<option value="Music">Music</option>
<option value="Nanotechnology">Nanotechnology</option>
<option value="Newspapers">Newspapers</option>
<option value="Non-Profit Organization Management">Non-Profit Organization Management</option>
<option value="Oil &amp; Energy">Oil &amp; Energy</option>
<option value="Online Media">Online Media</option>
<option value="Outsourcing/Offshoring">Outsourcing/Offshoring</option>
<option value="Package/Freight Delivery">Package/Freight Delivery</option>
<option value="Packaging and Containers">Packaging and Containers</option>
<option value="Paper &amp; Forest Products">Paper &amp; Forest Products</option>
<option value="Performing Arts">Performing Arts</option>
<option value="Pharmaceuticals">Pharmaceuticals</option>
<option value="Philanthropy">Philanthropy</option>
<option value="Photography">Photography</option>
<option value="Plastics">Plastics</option>
<option value="Political Organization">Political Organization</option>
<option value="Primary/Secondary Education">Primary/Secondary Education</option>
<option value="Printing">Printing</option>
<option value="Professional Training &amp; Coaching">Professional Training &amp; Coaching</option>
<option value="Program Development">Program Development</option>
<option value="Public Policy">Public Policy</option>
<option value="Public Relations and Communications">Public Relations and Communications</option>
<option value="Public Safety">Public Safety</option>
<option value="Publishing">Publishing</option>
<option value="Railroad Manufacture">Railroad Manufacture</option>
<option value="Ranching">Ranching</option>
<option value="Real Estate">Real Estate</option>
<option value="Recreational Facilities and Services">Recreational Facilities and Services</option>
<option value="Religious Institutions">Religious Institutions</option>
<option value="Renewables &amp; Environment">Renewables &amp; Environment</option>
<option value="Research">Research</option>
<option value="Restaurants">Restaurants</option>
<option value="Retail">Retail</option>
<option value="Security and Investigations">Security and Investigations</option>
<option value="Semiconductors">Semiconductors</option>
<option value="Shipbuilding">Shipbuilding</option>
<option value="Sporting Goods">Sporting Goods</option>
<option value="Sports">Sports</option>
<option value="Staffing and Recruiting">Staffing and Recruiting</option>
<option value="Supermarkets">Supermarkets</option>
<option value="Telecommunications">Telecommunications</option>
<option value="Textiles">Textiles</option>
<option value="Think Tanks">Think Tanks</option>
<option value="Tobacco">Tobacco</option>
<option value="Translation and Localization">Translation and Localization</option>
<option value="Transportation/Trucking/Railroad">Transportation/Trucking/Railroad</option>
<option value="Utilities">Utilities</option>
<option value="Venture Capital &amp; Private Equity">Venture Capital &amp; Private Equity</option>
<option value="Veterinary">Veterinary</option>
<option value="Warehousing">Warehousing</option>
<option value="Wholesale">Wholesale</option>
<option value="Wine and Spirits">Wine and Spirits</option>
<option value="Wireless">Wireless</option>
<option value="Writing and Editing">Writing and Editing</option>
<option value="Others">Others</option>
</optgroup>
</select><span class="select2 select2-container select2-container--default" dir="ltr" data-select2-id="2" style="width: 750.359px;"><span class="selection"><span class="select2-selection select2-selection--multiple" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1" aria-disabled="false"><ul class="select2-selection__rendered"><li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="0" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" role="searchbox" aria-autocomplete="list" placeholder="" style="width: 0.75em;"></li></ul></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
</div>
</div>



  <link rel="stylesheet" type="text/css" href="./Post a Job _ QUANTUMHUNTS_files/jquery-ui.min.css"> 
  <link rel="stylesheet" type="text/css" href="./Post a Job _ QUANTUMHUNTS_files/bootstrap-tokenfield.min.css">


  <script src="./Post a Job _ QUANTUMHUNTS_files/jquery-ui.min.js.download"></script>
  <script src="./Post a Job _ QUANTUMHUNTS_files/bootstrap-tokenfield.js.download"></script>




<div class="col-xl-6 mt-2">
<div class="form-group">                  
  <label for="visibility">Visibility
  </label>                                                
  <select class="form-control form-control-sm" id="visibility">
    <option value="Public" selected="">Public</option>
    <option value="Hidden">Hidden</option>
  </select>                                                
</div>    
</div>

<div class="col-xl-6 mt-2">
<div class="form-group">                  
  <label for="screening">Preferred Screening 
  <a tabindex="0" data-toggle="popover" data-trigger="hover" title="" data-content="Recruiters can indicate to potential candidate what kind of resumes they expect from the candidate when they apply. It can be text, video or both." data-original-title="Screening Option"><i class="dripicons-information"></i></a>
  </label>                                                
  <select class="form-control form-control-sm" id="screening">
    <option value="Video" selected="">Video Resume </option>
    <option value="Text">Text Resume</option>
    <option value="Both">Both Text &amp; Video Resume</option>    
  </select>                                                
</div>    
</div>






<div class="col-xl-12">
  <div class="form-group">
      <div class="display-error alert alert-danger" style="display:none;" id="resulting1">
      </div>      
  </div>
  <div class="form-group">
    <button type="button" id="create" class="btn btn-primary font-weight-bold">Create 

    </button>
    <a href="http://localhost/employer/post/jobs/" id="clear1" class="btn btn-primary-two text-dark font-weight-bold">Clear 
    
    </a>    
  </div>
</div>    
</div>
<!--1form-->
<div class="row">
  <div class="col-xl-12">
    <div class="form-group">
      <div class="display-success alert alert-success" style="display:none;" id="resulting">
          The job has been posted successfully. <a href="http://localhost/employer/post/jobs/">Click here</a> to post a new job.
      </div>
    </div>
  </div>
</div>
<!-- include Google hosted jQuery Library -->
<script src="./Post a Job _ QUANTUMHUNTS_files/jquery.min.js(1).download">
</script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#create').click(function(e){
      e.preventDefault();
      
    //var submitcompany = $('input[id=customRadio3]:checked').val();
        //alert(submitcompany);

    var usertype;    
        
        /*
        if(submitcompany===undefined)
        {
            usertype="self";
        }
        else
        {
            usertype="team";   
        }
        */
      //alert("User is "+usertype);
      
      
      usertype="self";
     var companyid="0";
      /*
      var companyid=$("#companyid option:selected").val();
     

      if(companyid>0)
      {
          usertype="team";     
      }
      else
      {
           usertype="self";      
      }
      */
      //alert("User is "+usertype);
      //alert("Company"+companyid);
      
      var companyname=$("#companyname").val();
      var title=$("#title").val();
      $("#title").val('');
      var min=$("#min").val();
      //alert(min);
      var max=$("#max").val();
      var currency=$("#cur option:selected").val();
      var location=$("#location").val();
      var emptype=$("#type option:selected").val();
      var visibility=$("#visibility option:selected").val();  
      var screening=$("#screening option:selected").val();        
      //var jd=$("#jd").val();
      var jd=simplemde_jd.value();
      //var jd=$("input[name=jd]")
      //var jq=$("#jq").val();
      var jq=simplemde_jq.value();      
      //var jd=$("input[name=jq]")      
      //var functions=$("#functions option:selected").val();
      var companyabout=simplemde_companyabout.value(); 
      var industry=$("#industry option:selected").val();
      var functions=$("#functions").val();      
      var start=$("#start").val();
      var expiry=$("#expiry").val();
      var seniority=$("#seniority option:selected").val();
      var experience_min=$("#experience_min option:selected").val();
      var experience_max=$("#experience_max option:selected").val();
      var positions=$("#positions").val();
      var keywords=$("#keywords").val();
      //alert("Job Title is "+title);
      
      //alert(jd.length);
      
      //alert("JD"+jd+jq);
      
      //alert(functions);
      //alert(companyid+title+min+max+currency+location+type+jd+jq+functions+start+expiry+seniority+experience_min+experience_max+positions+keywords);
/*
      alert("Company"+companyid);
      alert("Job Title is "+title);      
      alert("min/max"+min+max);
      alert("Cur "+currency);
      alert("Location "+location);
      alert("Type "+type);
      alert("JD"+jd+jq);
      alert("Functions "+functions);
      alert("Start"+start);
      alert("Expiry"+expiry);
      alert("Seniority"+seniority);
      alert("Experience "+experience_min+experience_max);
      alert("Position & Keywords" +positions+keywords);  
*/      
      
      $.ajax({
        type: "POST",
        url: "http://localhost/post-job/post-job.php",
        dataType: "json",
        data: {companyname:companyname,title:title,min:min,max:max,currency:currency,location:location,seniority:seniority,emptype:emptype,jd:jd,jq:jq,companyabout:companyabout,industry:industry,functions:functions,start:start,expiry:expiry,experience_min:experience_min,experience_max:experience_max,positions:positions,visibility:visibility,screening:screening,keywords:keywords},            
        success : function(data){
          //alert(data.code);
          //alert(data.msg);
        if (data.code == "200")
        {
          window.location.href = "http://localhost/employer";

            /*hiding temporarily */
            /*
            $(".display-error").hide();
            $("#companyform").hide();
            $("#resulting").show();
            */
        }
        else 
        {
          window.location.href = "http://localhost/employer";
            //alert("Unable to save " +data.msg);
            $(".display-error").html(""+data.msg+"");
            $(".display-error").css("display","block");
        }
        }
    }
            );
    }
                      );
                      
                      
                      
                      
                      
                      
                      
    $('#clear').click(function(f)
    {
      f.preventDefault();
                      
        //$("#companyform").trigger("reset");   
        //$('#companyform')[0].reset();
        $('#companyname').val(' ');
        //alert("clear");
                      
                      
                      
    });                  
                      
                      
  });
  
</script>



<p>
</p>
</div>
</div>


    




</div>
<div class="col-xl-4 col-lg-4">


<a class="" href="http://localhost/employer/jobs">
<div class="card border cta-box">
<div class="card-body">
<div class="float-center text-center">
</div>
<h4 class="text-uppercase font-13 text-dark blogmini">Dashboard</h4>
<p class="text-dark mb-1">Manage your jobs and applicants by visiting the job dashboard.</p>
<h4 onclick="back()" class="text-dark btn btn-warning btn-sm btn-rounded font-weight-bold" data-toggle="popover" data-trigger="hover" title="" data-content="Go back to your employer dashboard to manage your jobs and payment information." data-original-title=""> Back</h4>
</div>
</div>
</a>






<div id="SpecimenModal" class="modal fade">
<div class="modal-dialog">
    <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">Event</h4>
            </div>
            <div class="modal-body modal-body-specimen">
                <p>Loading...</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
    </div>
</div>






<script>
//JS script
$('.ls-modal').on('click', function(e){
  e.preventDefault();
  $('#SpecimenModal').modal('show').find('.modal-body-specimen').load($(this).attr('href'));
});
</script>    





</div>
</div>



                        
                    </div> <!-- End Content -->

                  
                </div> <!-- content-page -->

            </div> <!-- end wrapper-->
        </div>
        <!-- END Container -->




</div><span style="position:absolute; top:-999px; left:0; white-space:pre;"></span><ul id="ui-id-1" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" style="display: none; min-width: 748px;"></ul><div role="status" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div>


    <div id="ReferModal" class="modal " tabindex="-1" role="dialog">
      <div class="modal" tabindex="-1" role="dialog" style="padding-right: 16px; display: block;overflow-y: scroll;" aria-modal="true">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
          <div class="modal-content border-5">
            <div class="modal-body" style="overflow-y: auto;"><div class="card-body">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
              <div class="rounded mb-1 pt-0 mt-0">
		<center> <h5 class="d-block  mt-0 mb-3 text-primary text-uppercase  blogmini">📢 Invite Your Friends
                </h5></center>
		<ul class="nav nav-tabs tab-grad mt-3">
						
						<li class="nav-item "> <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" data-toggle="tab" href="http://localhost/employer/post/jobs/#profile1">Invite via Mail  </a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="http://localhost/employer/post/jobs/#home1"> Share via link</a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="http://localhost/employer/post/jobs/#referrals"> My Rewards</a> </li>						
					</ul>
	

<div class="tab-content">
    <div class="tab-pane show active" id="profile1">
	<br>
        <p>You can now invite your friends through mail so that they join world's 1st video centric job platform. You would get rewarded when your friends create their account with us.</p>
                <div class="media-body">
                  <!--<strong class="d-block  mt-2 text-primary text-uppercase purpletitle">Invite via Mail
                  </strong> -->
                 
                <div class="row">
                  
                  <div class="col-lg-12 col-12">
                      
                      <div class="row">
                      <div class="col-6">
                      
                    <span class="media-body mt-2">
                      <div class="form-group">
                        <label for="inputName">Name
                        </label>
                        <input type="text" class="form-control form-control-sm" id="inputName" required="" placeholder="Enter your Friend&#39;s name..">
                      </div> 
                      <div id="div1">
                      </div> 
                      <div class="alert alert-primary" id="invitenamemsg" style="display:none;">Please Enter Your Friend's Name
                      </div>
                      <div class="form-group">
                        <label for="inputEmail">Email
                        </label>
                        <input type="email" class="form-control form-control-sm" id="inputEmail" required="" placeholder="Enter your Friend&#39;s mail..">
                      </div> 
                      <div id="div2">
                      </div> 
                      <div class="alert alert-primary" id="inviteemailmsg" style="display:none;">Please Enter Your Email Id
                      </div>
                      <div class="alert alert-primary" id="invitevalidemailmsg" style="display:none;">Please Enter a Valid Email Id
                      </div>
                      <button class="btn btn-primary btn-sm" id="submit">Submit 
                      </button>
                    </span>
                    
                    </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="alert text-primary" id="invitesuccessmsg" style="display:none;">Success. Your friend will receive an email very soon.</div>
                			<div class="alert text-danger " id="invitefailuremsg" style="display:none;">Please try again. </div><p></p><br>
                            <div class="alert text-danger " id="inviteloginmsg" style="display:none;">Please login To invite your friends.
                      </div>
                        </div>
                    </div>                
                    
                    
                </div>
<div class="col-3 col-lg-4">
                  </div>
                <div class="col-3">
                </div>
                <div class="col-12">
                </div>
                </div>
            </div>
    </div>
     <div class="tab-pane" id="home1"><br>
        <p>Share this link with your friends so that they join World's 1st video resume platform. You would get rewarded when your friends create their video resume with us.</p>
	                <div class="row mt-3 mx-0">

                  <div class="col-12 col-md-5  my-auto mx-auto">
                        <div class="input-group input-group-merge">
                      <input class="form-control" type="text" value="http://localhost/?ref=tanish-sun-20210108120453" id="copybox">
                    <div class="input-group-append">
                      <button class="btn btn-primary-two btn-sm font-weight-bold text-dark" onclick="copyfunction()">Copy my link
                      </button>
                        </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-2 text-center my-auto mx-auto">
                    <p style="text-center font-size:20;">or
                    </p>
                  </div>
                  <div class="col-12 col-md-5  my-auto mx-auto">
                    <ul class="share-buttons">
                      
                      
                      <a class="mr-1" href="https://www.facebook.com/sharer/sharer.php?u=http://localhost/?ref=tanish-sun-20210108120453;" title="Share on Facebook" target="_blank" onclick="window.open(&#39;https://www.facebook.com/sharer/sharer.php?u=&#39; + http://localhost/signup/?ref=tanish-sun-20210108120453  Create a Professional Login+ &#39;&amp;quote=Apply for this opportunity&#39; ); return false;">
                        <img alt="Share on Facebook" src="./Post a Job _ QUANTUMHUNTS_files/facebook.png">
                      </a>            
                      
                      
                      <a class="mr-1" href="https://twitter.com/intent/tweet?text=http://localhost/?ref=tanish-sun-20210108120453%20Create%20a%20Professional%20Login" title="Click to share this post on Twitter" "="" target="_blank" onclick="window.open(&#39;https://twitter.com/intent/tweet?text=&#39; + http://localhost/job/tanish-sun-20210108120453 + &#39;:%20&#39;  + Apply for this opportunity); return false;">
                      <img alt="Tweet" src="./Post a Job _ QUANTUMHUNTS_files/twitter.png">
                      </a>

                    <a class="mr-1" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=http://localhost/?ref=tanish-sun-20210108120453;title=&amp;summary=&amp;source=" target="_blank" title="Share on LinkedIn">
			<img alt="Share on LinkedIn" src="./Post a Job _ QUANTUMHUNTS_files/linkedin.png">
                      </a> 
                    </ul>
                </div>
              </div>
    
 	<div class="mt-1 mb-1">
              <br>  <br>
              </div>
              
              <div class="row mt-2 mx-0">

                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row ">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-link text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 1 
                        </h5>    
                        <p class="text-secondary font-13 mb-0 mt-0 pb-0 pt-0 px-0">Share Link with your friends   
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
              
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-user-group text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 2
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">Ask your friends to create video resume  
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mt-n3 ">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-trophy text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 3 
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">We will reward your account 
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div></div>
              
              
    <div class="tab-pane" id="referrals">
        <p class="mt-3">Here is the stats of the valid users who have signed up based on your referral. Better your own numbers by speaking about our platform to your friends and acquaintance. share your referral link today.</p>
        <div class="row">
        <div class="col-4 col-xs-12 col-sm-12 col-md-4">



<div class="card tilebox-one shadow">
                                    <div class="card-body">
                                        <i class="uil uil-users-alt float-right"></i>
                                        <h6 class="text-uppercase mt-0 blogmini text-primary">Verified Users</h6>
                                        <h2 class="my-2" id="active-users-count">0</h2>
                                        <p class="mb-0 text-muted">
                                            <span class="text-nowrap">Since signup</span>  
                                        </p>
                                    </div> <!-- end card-body-->
                                </div>



        </div>
        </div>

    </div>
              
</div>



</div>
    </div>
        </div>
      </div>
    </div>
    </div>
  <br>
  <br>
  <br>
  <br>
  <br>
  </div>
<script src="./Post a Job _ QUANTUMHUNTS_files/jquery.min.js(1).download">
</script>
<script>
  function copyfunction() {
    var copyText = document.getElementById("copybox");
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
  }
  $(document).ready(function(){
    $('#submit').click(function(){
      var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
      var name = $('#inputName').val();
      var email = $('#inputEmail').val();
      if(name.trim()=='')
      {
        //document.getElementById("div1").innerHTML="Enter a value";
        //document.getElementById("div1").style.color="Red";
        $('#inputName').focus();
      }
      else if(email.trim() == '' ){
        //document.getElementById("div2").innerHTML="Enter the correct email address";
        //document.getElementById("div2").style.color="Red";
        $('#inputEmail').focus();
      }
      else if(email.trim() != '' && !reg.test(email)){
        //$("#invitevalidemailmsg").css("display","block");
        $('#inputEmail').focus();
      }
      else{
        
        $.ajax({
          type:"POST",
          url:"http://localhost/invite/send/",
          dataType: "json",
          data:{
            name:name,email:email},
          success:function(data){
            if(data.status == 'ok'){
               $("#invitesuccessmsg").css("display","block");
		$("#inviteloginmsg").hide();
		$("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitesuccessmsg").hide();
              }, 4000);              
            }
            else{ if(data.status=='error'){
             $("#inviteloginmsg").css("display","block");
	     $("#invitesuccessmsg").hide();
	     $("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitevalidemailmsg").hide();
              }, 4000);                            
              }
		else{
              $("#invitefailuremsg").css("display","block");
		$("#invitesuccessmsg").hide();
	     $("#inviteloginmsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitefailuremsg").hide();
              }, 4000);                            
            }
	 }
          }
        }
              );
      }
    }
                      );
  }
                   );
</script>



<?php
      include($root."/jobs/footer.php");

        ?>