<?php
session_start();
$flow="1";
$code=200;
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';

$job_title=$_POST['title'];
$job_company=$_POST['companyname'];
$job_start_date=$_POST['start'];
$job_end_date=$_POST['expiry'];
$job_added_by='1';//$_SESSION['recruiter_id'];
$job_location=$_POST['location'];
$job_experience_start=$_POST['experience_min'];
$job_industry=$_POST['industry'];
$job_function_array=$_POST['functions'];
$job_function='a';
foreach($job_function_array as $func)  
   {  
      $job_function .= $func.",";  
   } 
$job_type=$_POST['emptype'];
$job_description=$_POST['jd'];
$job_qualification=$_POST['jq'];
$job_skillsets=$_POST['keywords'];
$job_about_company=$_POST['companyabout'];
$job_experience_end=$_POST['experience_max'];
$job_salary_start=$_POST['min'];
$job_salary_end=$_POST['max'];
$job_position=$_POST['positions']; 
$conn=mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
    $sql8 = "INSERT INTO vj_jobs(job_position,job_title,job_company,job_start_date,job_end_date,job_added_by,job_location,job_experience_start,job_industry,job_function,job_type,job_description,job_qualification,job_skillsets,job_about_company,job_experience_end,job_salary_start,job_salary_end) VALUES('$job_position','$job_title','$job_company','$job_start_date','$job_end_date','$job_added_by','$job_location','$job_experience_start','$job_industry','$job_function','$job_type','$job_description','$job_qualification','$job_skillsets','$job_about_company','$job_experience_end','$job_salary_start','$job_salary_end')";
    if ($conn->query($sql8)==TRUE){
        echo json_encode(['code'=>400, 'msg'=>'success']);
        $conn->close(); 
        exit;
    }  
    else{
        echo json_encode(['code'=>200, 'msg'=>$job_function]);
        $conn->close(); 
        exit;
    }

?>