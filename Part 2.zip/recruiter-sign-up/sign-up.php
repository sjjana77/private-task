<?php
session_start();
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$dob=$_POST['dob'];
$email=$_POST['email'];
$gender=$_POST['gender'];
$password=$_POST['password'];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql8 = "SELECT * FROM vj_recruiter where recruiter_email='$email'";
$result8 = $conn->query($sql8);
if ($result8->num_rows > 0) {
    echo json_encode(['code'=>201, 'msg'=>'User Already Exist']);
    exit;
    }
if(empty($firstname)){
    echo json_encode(['code'=>201, 'msg'=>'Firstname Required']);
    exit;
}
if(empty($lastname)){
    echo json_encode(['code'=>201, 'msg'=>'Lastname Required']);
    exit;
}
if(empty($dob)){
    echo json_encode(['code'=>201, 'msg'=>'Date Of Birth Required']);
    exit;
}
if(empty($email)){
    echo json_encode(['code'=>201, 'msg'=>'Email Required']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['code'=>201, 'msg'=>'Invalid email format']);
    exit;
  }
if(empty($gender)){
    echo json_encode(['code'=>201, 'msg'=>'Gender Required']);
    exit;
}
if(empty($password)){
    echo json_encode(['code'=>201, 'msg'=>'Password Required']);
    exit;
}
if(strlen($password)<=7){
    echo json_encode(['code'=>201, 'msg'=>'Password length should be more than 7']);
    exit;
}



$sql8 = "INSERT INTO vj_recruiter(recruiter_fname,recruiter_lname,recruiter_password,recruiter_dob,recruiter_gender,recruiter_email) VALUES('$firstname','$lastname','$password','$dob','$gender','$email')";
if ($conn->query($sql8)==TRUE){
    $_SESSION['recruiter_fname']=$firstname;
    $_SESSION['recruiter_lname']=$lastname;
    $_SESSION['recruiter_dob']=$dob;
    $_SESSION['recruiter_email']=$email;
    $sql="SELECT * from vj_recruiter";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    $id=$row['recruiter_id'];
    }
    }
    $_SESSION['recruiter_id']=$id;
    echo json_encode(['code'=>200, 'msg'=>'success']);
    $conn->close(); 
    exit;
} 