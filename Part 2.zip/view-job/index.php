<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$job_iddd=$_SESSION['job_id'];
$cc_id=$_SESSION['candidate_id'];
$uname=$_SESSION["candidate_fname"]." ".$_SESSION['candidate_lname'];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
$sql="SELECT * from vj_jobs where job_id='$job_iddd'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $company=$row['job_company'];
      $title=$row['job_title'];
      $location=$row['job_location'];
      $position=$row['job_position'];
      $start=$row['job_start_date'];
      $end=$row['job_end_date'];
      $applied=$row['job_applied'];
      $experience_start=$row['job_experience_start'];
      $experience_end=$row['job_experience_end'];
      $industry=$row['job_industry'];
      $function=$row['job_function'];
      $type=$row['job_type'];
      $description=$row['job_description'];
      $qualification=$row['job_qualification'];
      $skill=$row['job_skillsets'];
      $about_company=$row['job_about_company'];
      $salary_start=$row['job_salary_start'];
      $salary_end=$row['job_salary_end'];
    }
  }
  $skillsets=[];
  $a=0;
  $aa=0;
  $tmp='';
  for($x=0;$x<strlen($skill);$x++){
    if($x==strlen($skill)-1){
      $tmp= substr($skill,$a);
      array_push($skillsets,$tmp);
      $a=$x+1;      
    }
    if($skill[$x]==','){
      if($aa!=0){
        $aa=$x-$a;
      }
      else{
        $aa=$x;
      }
     $tmp= substr($skill,$a,$aa);
     array_push($skillsets,$tmp);
     $aa=1;
     $a=$x+1;
     
    }
  } 
$name=[];
$datee=[];
$cid=[];
$app_id=[];
$apply=0;
$sql2="SELECT * from vj_applications where application_job_id='$job_iddd'";
$result2 = $conn->query($sql2);
if ($result2->num_rows > 0) {
    while($row2 = $result2->fetch_assoc()) {
      array_push($name,$row2['application_user_name']);
      array_push($datee,$row2['application_time']);
      array_push($cid,$row2['application_user_id']);
      array_push($app_id,$row2['application_id']);
    }
  }
  if (in_array($_SESSION['candidate_id'], $cid))
  {
  $apply=1;
  }

  $conn->close(); 
?>
<!DOCTYPE html>
<!-- saved from url=(0090)https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta property="og:url" content="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455">
<meta property="og:type" content="website">
<meta property="og:title" content="Talent Development Manager at HCL, Bangalore, India ">
<meta property="og:description" content="HCL Software is a division of HCL Technologies (HCL) that operates its primary software business. It develops, markets, sells, and supports over 20 product fami">
<meta property="og:image" content="https://quantumhunts.com/user/assets/images/header/job_openning_300px.png">
<meta property="fb:app_id" content="525323715034631"> 


        <title>VJA Job - <?php echo $title; ?> at <?php echo $location ?> </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="* Understand and appreciate software product engineering, technologies &amp; methodologies at a conceptu " name="description">
        <meta content="QUANTUMHUNTS" name="author">
<?php
if(isset($_SESSION['recruiter_id']) && $_SESSION['recruiter_id']!=''){
  include($root."/header_employer.php");

}
else{
  include($root."/jobs/header.php");
}
?>
<!--
<p>&nbsp;</p>        
    -->    
        
        


        <!-- Start Content-->
        <div class="container-fluid">

            <!-- Begin page -->
            <div class="wrapper">

                <!-- ========== Left Sidebar Start ========== -->


                <!-- Left Sidebar End -->
                
                
                
                
                
                
                
       
       
                                
                                                      
                                                      
                                                      
              
                
                
                
                
                
 <div class="content-page">
                    <div class="content">

                        <div class="row">
                            

                            <div class="col-xl-8 col-lg-8 mt-0">
           
                            






                            <div class="package">
                           <div class="card border mt-0 ribbon-box1 shadow1 mb-2 topnav-navbar-dark1" style="background1:#1b262c;">
                               <div class="jobpostheader" style="position: relative; z-index: 0; background-image: none;">
                                    <div class="card-body cta-box p-2 pl-3 pt-1">
                                    <div class="mt-0 mb-0">&nbsp;</div>
                                            
                                                         <h5 class="mb-0 font-weight-bold mb-0 text-left text-uppercase text-primary purpletitle">Recent Job</h5>                                                        
                                                         
                               
                                        <!--
                                                                    
                                        <a href="https://quantumhunts.com/employer/edit/jobs/talent-development-manager-hcl-bangalore-india-20210108215455" class="d-block btn btn-sm btn-secondary "><i class="uil uil-edit"></i> Edit this job</a><BR/>
                                        <a href="" class="d-block btn btn-sm btn-primary-two font-weight-bold"><i class="uil uil-edit"></i>Submit Video Job</a>
                                                                                -->
                               
                                          
                                        <div class="row">
                                            <div class="col-8 pt-0">
                                              
                                                <h3 class="mt-0 job-main-title font-weight-normal text-dark mb-0 pb-0 style=" line-height:24px!important;"=""><?php echo $title; ?></h3>
                                                <p class="pt-0 mt-0 font-17 font-weight-normal">
                                                <span class="text-dark small font-weight-semi-bold"><?php echo $company; ?></span><br>
                                                <span class="text-dark small"><?php echo $location ?> </span><br>
                                                
                                                
                                                

                                                                                            
                                                </p>
                                                
                                                
                                                
                                                
                                      <?php
                                      if(isset($_SESSION['recruiter_id']) && $_SESSION['recruiter_id']!=''){
                                        ?>
                                        
                                        <a href="#" class="btn btn-sm btn-primary mt-1 mr-2"> Edit job</a>
                                        <?php
                                      }
                                      ?>                              
                                                                                        



                                                   
                                            </div> <!-- end col-->
                                            <div class="col-4">
                                            <span class="float-right m-0 mr-0 pt-0 mt-0 float-middle">
                                               
                                            <!--<img src="https://quantumhunts.com/assets/img/jobhunt.png" style="height: 72px;" alt="" class="rounded-circle1 img-thumbnail1">-->
                                            </span>
                                            </div>    

                                        </div> <!-- end row -->

                                    <div class="mt-1 mb-2">&nbsp;</div> <!--mewly added -->
                                    <span class="offer">qh</span>
                                    </div> <!-- end card-body/ profile-user-box-->
                                    <div class="backstretch" style="left: 0px; top: 0px; overflow: hidden; margin: 0px; padding: 0px; height: 235.938px; width: 798.359px; z-index: -999998; position: absolute;"><div class="backstretch-item" style="position: absolute; margin: 0px; padding: 0px; border: none; width: 100%; height: 100%; z-index: -999999;"><img alt="" src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/images(1)" style="position: absolute; margin: 0px; padding: 0px; border: none; width: 1402.81px; height: 235.938px; max-width: none; inset: 0px auto auto -302.223px;"></div></div></div>
                                </div>   
                </div>                
                                
















<div class="row mb-0 pb-0 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                            <div class="col-12">
                                <div class="card widget-inline border shadow1 mt-0 mb-2 ">
                                    <div class="card-body p-0">
                                        <div class="row no-gutters">
                                            <div class="col-4 col-xs-4 col-sm-3 col-md-3 col-xl-3">
                                                <div class="card shadow-none m-0">
                                                    <div class="card-body text-center">
                                                        <i class="text-muted" style="font-size: 24px;">&#8450;</i>
                                                        <h5><span></span></h5>
                                                        <p class="text-dark font-15 mb-0"><?php echo $position.' '; ?>  Positions</p>
                                                    </div>
                                                </div>
                                            </div>
                
                                            <div class="col-4 col-xs-4 col-sm-3 col-md-3 col-xl-3">
                                                <div class="card shadow-none m-0 border-left">
                                                    <div class="card-body text-center">
                                                        <i class="far text-muted" style="font-size: 24px;">&#xf073;</i>
                                                        <h5><span></span></h5>
                                                        <p class="text-dark font-15 mb-0"><?php echo $start; ?></p>
                                                    </div>
                                                </div>
                                            </div>
                
                                            <div class="col-4 col-xs-4 col-sm-3 col-md-3 col-xl-3">
                                                <div class="card shadow-none m-0 border-left">
                                                    <div class="card-body text-center">
                                                    <i class="fa fa-bullhorn" style="font-size: 24px;"></i>
                                                        <h5><span></span></h5>
                                                        <p class="text-dark font-15 mb-0"><?php echo $applied.' '; ?> Applies</p>
                                                    </div>
                                                </div>
                                            </div>
                
                                            <div class="d-none d-sm-block col-sm-3 col-md-3 col-xl-3">
                                                <div class="card shadow-none m-0 border-left">
                                                    <div class="card-body text-center">
                                                    <i class="far text-muted" style="font-size: 24px;">&#xf073;</i>
                                                        <h5><span></span></h5>
                                                        <p class="text-dark font-15 mb-0"><?php echo $end.' '; ?> </p>                                                    </div>
                                                </div>
                                            </div>
                
                                        </div> <!-- end row -->
                                    </div>
                                </div> <!-- end card-box-->
                            </div> <!-- end col-->
                        </div>




           
                           <div class="card border shadow1 ribbon-box mb-2 mt-0 wow fadeInUp" style="background: white; visibility: visible; animation-name: fadeInUp;">

                                    <div class="card-body1">
                                       

                                        <div class="row">
                                            <div class="col-md-12 pt-2">
                                                
        
                                                
                                                <div class="pl-3">
                                                <h5 class="text-left text-dark pb-0 mb-0"><?php echo $title; ?></h5>
                                                
                                                <p class="font-17 font-weight-normal">
                                                <span class="text-dark"><?php echo $company; ?></span><br>       
                                                <span class="text-dark"><?php echo $location; ?>a</span> <br>   
                                                <span class="text-dark"><?php echo $company; ?></span><br>
                                                <span class="text-dark">Posted On <?php echo $start; ?></span> <br> <br>
                                                <?php
                                      if($apply==1){
                                        ?>
                                                                                                <span class="badge badge-outline-secondary badge-pill">Applied</span> 
                                                                                                
                                               <?php
                                      }
                                               ?>
                                                                                              </p>
                                                </div>
                                                   
                                            </div>
                                            
                                            
                                            <div class="col-md-4"> 
                                            <!--<canvas class="my-1" id="bar-chart" width="800" height="450">
                                            </canvas> -->
                                                

                                            </div> <!-- end col-->
                                             
                                        </div> <!-- end row -->

                                    </div> <!-- end card-body/ profile-user-box-->
                                </div>                     
                                
                                
                                
                            
              
              
              
              
              
                   
              
              
              
              
  
                            <!--Section -->
        
        
                                   <div class="card border shadow1 ribbon-box mb-2 mt-0 pl-3 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                                    <div class="card-body1">
                                        <div class="row">
                                            <div class="col-6 pt-2">
                                                <h5 class="text-left text-dark pb-0 mb-0">Job Experience</h5>
                                                <p class="font-17 font-weight-normal"><span class="text-dark"><?php echo $experience_start.'-'.$experience_end.' '; ?> years </span><br>
                                                </p>
                                                
                                                <h5 class="text-left text-dark pb-0 mb-0">Industry</h5>
                                                <p class="font-17 font-weight-normal"><span class="text-dark"><?php echo $industry; ?></span><br>
                                                </p>                                                


                                                <h5 class="text-left text-dark pb-0 mb-0">Function</h5>
                                                <p class="font-17 font-weight-normal"><span class="text-dark"><?php echo $function; ?></span><br>
                                                </p>                                                


                                                <h5 class="text-left text-dark pb-0 mb-0">Start Date</h5>
                                                <p class="font-17 font-weight-normal"><span class="text-dark"><?php echo $start; ?></span><br>
                                                </p>                                                
                                                
                                                                                             


                                                   
                                            </div>
                                            
                                            <div class="col-6 pt-2"> 
                                                <h5 class="text-left text-dark pb-0 mb-0">Apply Before</h5>
                                                <p class="font-17 font-weight-normal"><span class="text-dark"><?php echo $end; ?></span><br>
                                                </p>                                                                                                


                                                <h5 class="text-left text-dark pb-0 mb-0">Location</h5>
                                                <p class="font-17 font-weight-normal"><span class="text-dark"><?php echo $location; ?></span><br>
                                                </p>                           
                                                
                                                <h5 class="text-left text-dark pb-0 mb-0">Job Type</h5>
                                                <p class="font-17 font-weight-normal"><span class="text-dark"><?php echo $type; ?></span><br>
                                                </p>                                                
                                                


                                            </div>
                                        </div>
                                    </div>
                                </div>                     
                                                            
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
                                
                              
                                
                                
                                
                                
                                
                                
                                
                                <div class="card border shadow1 mb-2 mt-0 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"> <!--card-->
                                    <div class="card-body">
                                      
                                            
                                            
                                        <!-- Steps Information -->
                                        <div class="tab-content">

                                            <!-- Billing Content-->
                                            <div class="tab-pane show active" id="billing-information">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        
                                                        
                                                        

                                                        
                                                        <h5 class="mt-1 text-dark job-title">Job Description</h5>

                                                        <div class="text-dark mb-2" id="desc"><?php echo $description; ?>
</div>
                                                        
<script>
  function applyy(a){
    var cname="<?php echo $company; ?>";
    var jname="<?php echo $title; ?>";
    var uname="<?php echo $uname; ?>";
    var aaa=a;
    var bb="<?php echo $job_iddd; ?>";
    $.ajax({
      type:"POST",
  url:"http://localhost/jobs/apply.php",
  dataType:"json",
  data:{a:aaa,b:bb,cname:cname,jname:jname,uname:uname},
  success:function(data){
  if(data.code=='200'){
    $(".appclose").css("display","none");
    document.getElementById("appliedd").innerHTML=data.msg+"<br>";
  }

}
});
   
  }
</script>
  
  <!--This works but we are going with commonmark.js -->
<script src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/marked.min.js.download"></script>

  
  
  <!--
  <script src="https://unpkg.com/showdown/dist/showdown.min.js"></script>
  
  <script>
  var converter = new showdown.Converter(),
    text      = '* Understand and appreciate software product engineering, technologies & methodologies at a conceptual level<br />
* Empathy & good disposition towards people, their skills requirements and growth<br />
* Strong coordination and project management skills, to plan and run talent development programs<br />
* Work well with product engineering and HR to create plans for talent development at different levels, initially in Bangalore and targeted at product engineering teams<br />
* Design, enhance and roll out new, innovative & effective talent development programs, as per requirement<br />
* Track positive impact of such programs using metrics<br />
* Communicate well, verbally and in writing<br />
* Sufficiently driven to make things happen, ensuring quality of programs and overcoming challenges along the way<br />
* Strongly desirable to have demonstrated talent development at a software product engineering MNC in the past',
    html      = converter.makeHtml(text);
  </script>

  -->
  
  <!--
  <script src="https://quantumhunts.com/user/assets/js/commonmark/commonmark.js"></script>
  
    <script>
    var reader = new commonmark.Parser();
var writer = new commonmark.HtmlRenderer();
var parsed = reader.parse("* Understand and appreciate software product engineering, technologies & methodologies at a conceptual level<br />
* Empathy & good disposition towards people, their skills requirements and growth<br />
* Strong coordination and project management skills, to plan and run talent development programs<br />
* Work well with product engineering and HR to create plans for talent development at different levels, initially in Bangalore and targeted at product engineering teams<br />
* Design, enhance and roll out new, innovative & effective talent development programs, as per requirement<br />
* Track positive impact of such programs using metrics<br />
* Communicate well, verbally and in writing<br />
* Sufficiently driven to make things happen, ensuring quality of programs and overcoming challenges along the way<br />
* Strongly desirable to have demonstrated talent development at a software product engineering MNC in the past"); // parsed is a 'Node' tree
// transform parsed if you like...
var result = writer.render(parsed); // result is a String
document.getElementById('desc').innerHTML=result;

    </script>
  -->
  
  
  
                                                        <!--
                                                        <script>
                                                        var simplemde = new SimpleMDE({ element: document.getElementById("desc") });
                                                        </script>

                                                        <script>
                                                        var simplemde = new SimpleMDE();
                                                        simplemde.options.previewRender("This is *example* Markdown");
                                                        </script>
                                                        -->

                                                        
                                                        
                                                        <h5 class="mt-3 text-dark job-title">Education &amp; Job Qualification</h5>
                                                        <p class="text-dark mb-2" id="qualification"><p><?php echo $qualification; ?></p>
</p>
                                                        
                                                        
  <script>
  </script>                                                        

                                                        <h5 class="mt-3 text-dark job-title">Skillsets</h5>
                                                        <p class="text-dark mb-2"> 
                                                          <?php  for($x=0;$x<count($skillsets);$x++){
                                                          ?>
                                                     <span class="text-dark mr-1 mb-1 btn-sm btn bg-secondary-two btn-rounded font-weight-bold">
                                                        <?php echo $skillsets[$x] ?>  </span>
                                                        <?php  }
                                                        ?>
                                                                                                                 </p>                                        

                                                        
                                                        
                                                        
                                                        


                                                        <h5 class="mt-3 text-dark job-title">About Company</h5>
                                                        <p class="text-dark mb-2">
                                                        <?php
                                                        echo $about_company;
                                                        ?>  

                                                        </p>
                                                        
                                                                                                                <h5 class="mt-3 text-dark job-title">Typical Salary for this type of Job</h5>
                                                        <p class="text-dark mb-2"><?php echo $salary_start; ?> to <?php echo $salary_end; ?> INR</p>
                                                                                                              

                                                        <hr>


                                                         <form>

                                                        <input type="”hidden”" id="jobid293" value="293" style="display:none;">
                                                        <input type="”hidden”" id="userid" value="2928" style="display:none;">
                                                        <input type="”hidden”" id="cvid" value="3541" style="display:none;">  
                                                        <?php
                                      if($apply==1){
                                        ?>
                                                       <div class="card-body p-0">
                                                            You have applied for this job. <br>
                                      </div>
                                                            <?php
                                      }
                                      else{
                                                            ?>
                                                            <a id="<?php echo $cc_id; ?>" type="button" onclick="applyy(this.id)" class="appclose btn btn-sm btn-primary" style="color:white;">Apply </span></a>                                     

                                                            <?php } ?>
                                                            <span id="appliedd"></span>
                                                                <!--<button type="button"  id="" class="btn btn-dark" disabled>Applied <i class="mdi mdi-arrow-right ml-2"></i></button> -->   	                                                           
                                                          <a type="button" onclick="back()" class="btn btn-sm btn-primary"><span style="color:white;">Back </span></a>                                     






                                            
                                                        </form>
                                                        
                                                        <p>&nbsp;</p>
                                                        














<!-- Signup modal-->

<div id="apply-modal" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true" data-target="#scrollable-modal">
    <div class="modal-dialog modal-lg bg-primary-lighten modal-dialog-scrollable">
        <div class="modal-content">
<div class="modal-header modal-colored-header bg-primary1">
                <h5 class="modal-title text-dark font-weight-bold text-uppercase blogmini font-14" id="dark-header-modalLabel">
                                            <span class="mr-2"><img src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/square1_qh.png" alt="" height="28"></span> 
                    Jobs - Talent Development Manager, HCL</h5>
                <button type="button" class="text-dark close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body card-body1">

                <form class="pl-3 pr-3" id="callbackform" action="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455#">

                <!--
                <div class="row">
                <div class="col-12 col-lg-3 align-top">  </div>                  
                <div class="col-12 col-lg-6 align-top">
                <img class="img-fluid mx-n2 my-n2 mb-3" src="https://quantumhunts.com/user/assets/images/apply_for_job.png">
                </div>
                <div class="col-12 col-lg-3 align-top">  </div>                                  
                </div>
                -->


                <div class="row">
                <div class="col-12 col-lg-6 align-top">

                    

                <h5 class="text-primary text-uppercase blogmini">Self-Assessment</h5> 
                <p>Please do a honest self-assessment on the below skillset required for this job. This helps recruiters weigh in your candidature.</p>
      
                <table class="table table-zero table-responsive table-borderless">    
                    
                                   
                  <script src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/jquery.star-rating-svg.js.download"></script>          
                <tbody><tr>
                <td><span class="text-dark">Communication</span></td>
                <td> <span class="my-rating1"><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-833{fill:url(#833_SVGID_1_);}.svg-hovered-833{fill:url(#833_SVGID_2_);}.svg-active-833{fill:url(#833_SVGID_3_);}</style><lineargradient id="833_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="833_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="833_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-833" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-833{fill:url(#833_SVGID_1_);}.svg-hovered-833{fill:url(#833_SVGID_2_);}.svg-active-833{fill:url(#833_SVGID_3_);}</style><lineargradient id="833_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="833_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="833_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-833" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-833{fill:url(#833_SVGID_1_);}.svg-hovered-833{fill:url(#833_SVGID_2_);}.svg-active-833{fill:url(#833_SVGID_3_);}</style><lineargradient id="833_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="833_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="833_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-833" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-833{fill:url(#833_SVGID_1_);}.svg-hovered-833{fill:url(#833_SVGID_2_);}.svg-active-833{fill:url(#833_SVGID_3_);}</style><lineargradient id="833_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="833_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="833_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-833" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-833{fill:url(#833_SVGID_1_);}.svg-hovered-833{fill:url(#833_SVGID_2_);}.svg-active-833{fill:url(#833_SVGID_3_);}</style><lineargradient id="833_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="833_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="833_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-833" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-833" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div></span> <span class="live-rating1"></span></td>                
                </tr>    


<script>
$(".my-rating1").starRating({
    initialRating: 0,
     starSize: 18,
    disableAfterRate: false,
    onHover: function(currentIndex, currentRating, $el){
      $('.live-rating1').text(currentIndex);
    },
    onLeave: function(currentIndex, currentRating, $el){
      $('.live-rating1').text(currentRating);
    }
  });

</script>


                                    
                  <script src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/jquery.star-rating-svg.js.download"></script>          
                <tr>
                <td><span class="text-dark">Interpersonal Skills</span></td>
                <td> <span class="my-rating2"><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-266{fill:url(#266_SVGID_1_);}.svg-hovered-266{fill:url(#266_SVGID_2_);}.svg-active-266{fill:url(#266_SVGID_3_);}</style><lineargradient id="266_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="266_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="266_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-266" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-266{fill:url(#266_SVGID_1_);}.svg-hovered-266{fill:url(#266_SVGID_2_);}.svg-active-266{fill:url(#266_SVGID_3_);}</style><lineargradient id="266_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="266_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="266_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-266" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-266{fill:url(#266_SVGID_1_);}.svg-hovered-266{fill:url(#266_SVGID_2_);}.svg-active-266{fill:url(#266_SVGID_3_);}</style><lineargradient id="266_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="266_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="266_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-266" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-266{fill:url(#266_SVGID_1_);}.svg-hovered-266{fill:url(#266_SVGID_2_);}.svg-active-266{fill:url(#266_SVGID_3_);}</style><lineargradient id="266_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="266_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="266_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-266" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-266{fill:url(#266_SVGID_1_);}.svg-hovered-266{fill:url(#266_SVGID_2_);}.svg-active-266{fill:url(#266_SVGID_3_);}</style><lineargradient id="266_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="266_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="266_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-266" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-266" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div></span> <span class="live-rating2"></span></td>                
                </tr>    


<script>
$(".my-rating2").starRating({
    initialRating: 0,
     starSize: 18,
    disableAfterRate: false,
    onHover: function(currentIndex, currentRating, $el){
      $('.live-rating2').text(currentIndex);
    },
    onLeave: function(currentIndex, currentRating, $el){
      $('.live-rating2').text(currentRating);
    }
  });

</script>


                                    
                  <script src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/jquery.star-rating-svg.js.download"></script>          
                <tr>
                <td><span class="text-dark">Critical thinking</span></td>
                <td> <span class="my-rating3"><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-309{fill:url(#309_SVGID_1_);}.svg-hovered-309{fill:url(#309_SVGID_2_);}.svg-active-309{fill:url(#309_SVGID_3_);}</style><lineargradient id="309_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="309_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="309_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-309" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-309{fill:url(#309_SVGID_1_);}.svg-hovered-309{fill:url(#309_SVGID_2_);}.svg-active-309{fill:url(#309_SVGID_3_);}</style><lineargradient id="309_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="309_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="309_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-309" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-309{fill:url(#309_SVGID_1_);}.svg-hovered-309{fill:url(#309_SVGID_2_);}.svg-active-309{fill:url(#309_SVGID_3_);}</style><lineargradient id="309_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="309_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="309_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-309" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-309{fill:url(#309_SVGID_1_);}.svg-hovered-309{fill:url(#309_SVGID_2_);}.svg-active-309{fill:url(#309_SVGID_3_);}</style><lineargradient id="309_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="309_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="309_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-309" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div><div class="jq-star" style="width:18px;  height:18px;"><svg version="1.0" class="jq-star-svg" shape-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="305px" height="305px" viewBox="60 -62 309 309" style="enable-background:new 64 -59 305 305; stroke-width:4px;" xml:space="preserve"><style type="text/css">.svg-empty-309{fill:url(#309_SVGID_1_);}.svg-hovered-309{fill:url(#309_SVGID_2_);}.svg-active-309{fill:url(#309_SVGID_3_);}</style><lineargradient id="309_SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:lightgray"></stop><stop offset="1" style="stop-color:lightgray"></stop> </lineargradient><lineargradient id="309_SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:orange"></stop><stop offset="1" style="stop-color:orange"></stop> </lineargradient><lineargradient id="309_SVGID_3_" gradientUnits="userSpaceOnUse" x1="0" y1="-50" x2="0" y2="250"><stop offset="0" style="stop-color:#FEF7CD"></stop><stop offset="1" style="stop-color:#FF9511"></stop> </lineargradient><polygon data-side="center" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 212.9,181.1 213.9,181 306.5,241 " style="fill: transparent; stroke: black;"></polygon><polygon data-side="left" class="svg-empty-309" points="281.1,129.8 364,55.7 255.5,46.8 214,-59 172.5,46.8 64,55.4 146.8,129.7 121.1,241 213.9,181.1 213.9,181 306.5,241 " style="stroke-opacity: 0;"></polygon><polygon data-side="right" class="svg-empty-309" points="364,55.7 255.5,46.8 214,-59 213.9,181 306.5,241 281.1,129.8 " style="stroke-opacity: 0;"></polygon></svg></div></span> <span class="live-rating3"></span></td>                
                </tr>    


<script>
$(".my-rating3").starRating({
    initialRating: 0,
     starSize: 18,
    disableAfterRate: false,
    onHover: function(currentIndex, currentRating, $el){
      $('.live-rating3').text(currentIndex);
    },
    onLeave: function(currentIndex, currentRating, $el){
      $('.live-rating3').text(currentRating);
    }
  });

</script>


                               </tbody></table>
               
               
                <div class="form-group">
                <h5 class="text-primary text-uppercase blogmini">Cover Message</h5> 
                <p>Provide a relevent cover message for the recruiter to screen your candidature.</p>

                        <textarea class="form-control" id="applycomments" placeholder=""></textarea>
                </div>       
                
                
                
                <div class="form-group text-left">



                    <div class="apply-display-error  alert alert-danger" style="display: none">
                                                        
                    </div>
                    
                    <div class="apply-display-success  alert alert-primary">
                    You have successfully applied for this job.<br>Kindly wait for a call from recruitment expert.                    </div>


                        <button type="button" id="job293" class="btn btn-sm btn-primary">Apply <i class="mdi mdi-arrow-right ml-2"></i></button>    	                                                           
                        <button type="button" class="btn btn-sm btn-light" data-dismiss="modal">Close</button>
                </div>
                
                
                
                
                
                
                
                
                
                
                                                
                    <!--<img class="img-fluid" src="https://quantumhunts.com/user/assets/images/hero/quantumhunts-job-screening.gif">-->
                </div>
                <div class="col-12 col-lg-6">
                    
                <div class="card shadow1 border">
                    <div class="card-body">
                        <div class="col-2">
                            <i class="uil uil-exclamation-triangle"></i>
                        </div>
                        <div class="col-10">     
                        <h5 class="text-primary font-weight-bold text-uppercase blogmini">IMPORTANT</h5>
                        <p>This job requires a video resume to be created for your profile. If you have not created a video resume yet. Create it now.</p>
                        <a target="_blank" href="https://quantumhunts.com/user/manage/profile/?go=video" class="btn btn-xs btn-warning text-dark font-weight-bold mr-1">Create Video Resume</a>
                        <a href="https://quantumhunts.com/pro/sharmistha-chatterjee/">Example</a>
                        </div>
                    </div>
                </div>
                
                <div class="card shadow1 border">
                    <div class="card-body">
                        <div class="col-2">
                            
                        </div>
                        <div class="col-10">  
                        <h5 class="text-primary font-weight-bold text-uppercase blogmini">How to Prepare</h5>
                        <p>Apply for our 2 week Mentorship to prepare yourself before you apply for this job.</p>
                        <a target="_blank" href="https://quantumhunts.com/virtual-mentor/?ref=job" class="btn btn-xs btn-warning text-dark font-weight-bold">Upskill Before Applying</a>
                        </div>
                    </div>
                </div>                
                            </div>   
                
                
                </div>



                    
                    
                </form>
                


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->












  <!-- include Google hosted jQuery Library -->
<script src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/jquery.min.js(1).download"></script>



  <script type="text/javascript">
  $(document).ready(function() {


      $('#job293').click(function(e){
        e.preventDefault();

        
        var jobid= $("#jobid293").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments=$("#applycomments").val();
        var option="Apply";
        
        //var round1 = $(".live-rating1" ).first().text();
        var candidatecomments='';
        var newline ="<BR/>";
        var col=":";
             
        
        candidatecomments=candidatecomments+"Communication"+col+$(".live-rating1" ).first().text()+newline;

        candidatecomments=candidatecomments+"Interpersonal Skills"+col+$(".live-rating2" ).first().text()+newline;

        candidatecomments=candidatecomments+"Critical thinking"+col+$(".live-rating3" ).first().text()+newline;

        
        //alert(candidatecomments);
        
        //alert(round1);
        
        //alert("hello");
        //alert(cvid.len)
        //alert(jobid+userid+cvid+comments+option);
        
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/user/set/apply-job/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,candidatecomments:candidatecomments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job293").html('Applied');
                    $("#job293").removeClass('btn-primary');
                    $("#job293").addClass('btn-success');
                    $(".apply-display-error").html(" ");
                    $(".apply-display-error").hide();
                     $(".apply-display-success").show();
                    $(".apply-display-success").html(""+data.msg+"");
                    $(".apply-display-success").css("display","block");
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".apply-display-success").html(" ");
                    $(".apply-display-success").hide();
                    $(".apply-display-error").show();
                    $(".apply-display-error").html(""+data.msg+"");
                    $(".apply-display-error").css("display","block");
                    
                    
                }                 
            }
        });


      });
      
  });
      


  $(document).ready(function() {

      $('#savejob293').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid293").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="Save";
        
        //alert("hello");
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/user/set/apply-job/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#savejob293").html('Saved');
                    $("#savejob293").removeClass('btn-primary');
                    $("#savejob293").addClass('btn-success');
                    $(".apply-display-error").html(" ");
                    $(".apply-display-success").html(""+data.msg+"");
                    $(".apply-display-success").css("display","block");
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".apply-display-success").html(" ");
                    $(".apply-display-error").html(""+data.msg+"");
                    $(".apply-display-error").css("display","block");
                }                 
            }
        });


      });      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
  });
</script>
                                     







                                                        
                  
                                            

                                                        
                                                    </div>
                                                          
                                                </div> <!-- end row-->
                                            </div>
                                            <!-- End Billing Information Content-->



                                    </div> <!-- end tab -body-->                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
     
              
                                                         
                                            
                                  
    
    
    
    
    
    
    
    
    
    
    
    
                                       
                                    </div> <!-- end card body -->
</div>
                                
                               <!--
                                <div class="card border shadow1 mb-0 mt-0 wow fadeInUp"> 
                                    <div class="card-body">
                                        Section to show application Status
                                
                                    </div>
                                </div>    
                                -->




   
                             
                










  <!-- include Google hosted jQuery Library -->
<script src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/jquery.min.js(1).download"></script>




                                     









                                

                               
<?php
                                      if(isset($_SESSION['recruiter_id']) && $_SESSION['recruiter_id']!=''){
                                        ?>               
                           
                                

                                <div class="card border shadow1 mb-2 mt-0"> <!--card-->
                                    <div class="card-body">
                                        <h5 class="text-left mb-2 text-uppercase font-14 text-primary">Who Applied for this Job</h5>
                                        <!--2928talent-development-manager-hcl-bangalore-india-20210108215455-->
                                        <div class="card1">
    <div class="card-body1">
      <?php  for($x=0;$x<count($app_id);$x++)  { ?>
        <div class="inbox-widget">

            
            
            <div class="inbox-item mb-0 mt-0 pt-0 pb-0">
                <div class="jobcard card p-1 card-body border-bottom mb-0 mt-0">
                <div class="media">
                <div class="inbox-item-img">
                    
                    <a href="#" class="btn btn-sm btn-link text-info font-13"> <button class="btn mr-1 btn-xs btn-success">&nbsp;</button>  <!--<img src="https://www.pphfoundation.ca/wp-content/uploads/2018/05/default-avatar.png" class="rounded-circle" alt="">--> </a>
                </div>
                <div class="media-body pl-2">
                <p class="inbox-item-author text-dark mb-0">
                    <a class="text-dark font-13" href="#"><strong><?php echo $name[$x]; ?></strong></a>
                </p>
                <span class="block">Applied on <?php echo $datee[$x]; ?></span>
                <p class="inbox-item-text mt-0 text-dark"><span class="mr-3">APPLY</span><span></span></p>
                <p class="inbox-item-date">
              <a target="<?php echo $app_id[$x]; ?>" id="<?php echo $cid[$x]; ?>" onclick="view_application(this.id,this.target)" class="btn btn-xs btn-success font-13"> <i class="dripicons-document"></i>  </a>                    
                </p>
                </div>
                </div>
                </div>
            </div>
            
            
            
            
            
            
           
                
                        
            

            
            
            
            
           
                
                    </div>  </div>

<?php  }  ?>

</div></div></div>                                    
        <?php  } ?>                                                        
<script>
function view_application(cid,aid){
  var c_id=cid;
  var a_id=aid;
  $.ajax({
type:"POST",
url:"http://localhost/view-job/view_session.php",
dataType:"json",
data:{c_id:c_id,a_id:a_id},
success:function(data){
if(data.code=='200'){
  window.location.href = "http://localhost/application/";
//alert(data.msg);
}

}
});
}

</script>



                                

                            
                                
                          
                                
                                
                                
                                
                                
                                
                                
                                
                            </div> <!-- end col -->
                            <div class="col-xl-4 col-lg-4 mt-0">

 
 
 
<script type="text/javascript">
var no_of_interviews;
var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function dateFormat(d){
   var t = new Date(d);
 return t.getDate()+'-'+monthNames[t.getMonth()]+'-'+t.getFullYear();
}                             
  var today = Date("j-M-Y, H:i");
  var starting_date = dateFormat(today) +" "+ today.substring(16,25);
</script>
    

<!-- Signup modal-->

<div id="resume-record2" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-left">


                        <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold">Progress</h5> 
                        
                        <p class="text-left ">Your previous interview is in progress.
                        <br>
                        Please finish previous interview.
                        </p><div id="previous"></div>                         

                        <p></p>



                        <p class="text-center mt-3">
                        <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button>    	                                                           
                        </p>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->














<!-- Signup modal-->

<div id="resume-record" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-left">


                        <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold">Interview</h5> 
                        
                        <p class="text-left ">You can now attend tour interview publish to recruiters.</p>



<div id="testing"></div>
<script type="text/javascript">
            function textToAudio(msg) {
                
                var speech = new SpeechSynthesisUtterance();
            //  if(scc=="j"){
             //   scc="k";
              //  window.speechSynthesis.cancel();
            //  }
             // else{
                speech.lang = "en-US";
                
                speech.text = msg;
                speech.volume = 1;
                speech.rate = 1;
                speech.pitch = 1;
               // SpeechSynthesis.cancel();
                window.speechSynthesis.speak(speech);
//}            
}
		</script>
<script type="text/javascript">
 //checking
var question_set;

let userAgentString =  
              navigator.userAgent; 
        
          // Detect Chrome 
          let chromeAgent =  
              userAgentString.indexOf("Chrome") > -1; 
        
          // Detect Internet Explorer 
          let IExplorerAgent =  
              userAgentString.indexOf("MSIE") > -1 ||  
              userAgentString.indexOf("rv:") > -1; 
        
          // Detect Firefox 
          let firefoxAgent =  
              userAgentString.indexOf("Firefox") > -1; 
        
          // Detect Safari 
          let safariAgent =  
              userAgentString.indexOf("Safari") > -1; 
                
          // Discard Safari since it also matches Chrome 
          if ((chromeAgent) && (safariAgent))  
              safariAgent = false; 
                      if(safariAgent==true){
                      
                      }
                      else{
                    /*    
*/

$(document).ready(function(){
  $("#startButton").click(function(e){
    e.preventDefault();
    navigator.getMedia = ( navigator.getUserMedia || // use the proper vendor prefix
                       navigator.webkitGetUserMedia ||
                       navigator.mozGetUserMedia ||
                       navigator.msGetUserMedia);

navigator.getMedia({video: true}, function() {
    /*
    for(let h=1; h<=3; h++){
      alert(h);
      if(lastclick==h){
        
      }
      else{
        st = "startt"+h;
        document.getElementById(st).disabled = true;
      }

    }
    */
  var setno = set_no;

  var datte = starting_date;
  $.ajax({
          url: "https://quantumhunts.com/dev/video-message/2/response.php",
          type: "POST",
          dataType: "json",
          data: {setno:setno, setid:sett_id, today2:datte},
          success : function(data){
              if (data.code == "200")
              {
                lk = 1;
                var tym=0;
                var question;
                var lenn=data.msg.length;
                main();
                async function task(i) 
{ // 3
  await timer(i);
  console.log(`Task ${i} done!`);
}

function timer(ms) { return new Promise(res => setTimeout(res, ms)); }
   


async function main() 
{
  var questiondb = "";
  let tt=0;
  let last =lenn;
  let max_limit = total2/data.msg.length;
  max_limit=max_limit*60;
  let mlimit=0;
  //for(let jk=0;jk<lenn; jk++) 
  //{
    let jk=0;
    document.getElementById('questions').innerHTML="Questions: 1 out of "+last;
    document.getElementById('course-apply-success').innerHTML = data.msg[jk];
var question_time = new Array();
var question_question = data.msg;
var calculate_time = 0;
      if(data.set_audible=="1"){
       textToAudio(data.msg[jk]);
       }
    jk=1;
    
      for(let jj=total2*60;jj>=0; jj--) {
        mlimit+=1;
        calculate_time+=1;
        let  uio=1000; 
        if(mlimit!=0){
          if(mlimit>max_limit){
            document.getElementById('timealert').innerHTML="You are taken enough time for this question. Attend other questions by clicking next";
          }
        }    
        if(nxt==1){
          mlimit=0;
          document.getElementById('timealert').innerHTML="";
            nxt=0;
            window.speechSynthesis.cancel();
            if(jk==lenn-1){
              $("#next").hide();  
            }
              if(data.set_audible=="1"){
                  textToAudio(data.msg[jk]);
               }
              question_time.push(calculate_time); 
              document.getElementById('course-apply-success').innerHTML = data.msg[jk]; 
              let op=jk+1;
              let opp=lenn;
              document.getElementById('questions').innerHTML="Questions: "+op+" out of "+opp;
              jk+=1;
            
        }
        document.getElementById('course-apply-success2').innerHTML = Math.floor(jj)+" seconds left to answer";
        await task(uio);
  }
  
var gh = total2*60;
  $.ajax({
          url: "https://quantumhunts.com/dev/video-message/2/questiondb.php",
          type: "POST",
          dataType: "json",
          data: {question_question:question_question,question_time:question_time,id:sett_id,last:gh},
          success : function(data){
              if (data.code == "200")
              {
              }
          }
        });
  //}
  /*
  tt=1*60;
  for(let jj=tt;jj>=0; jj--) 
  {
    let uio=1000;
    document.getElementById('course-apply-success2').innerHTML = Math.floor(jj)+" seconds left to answer";
    await task(uio);
}
*/
/*   for(let i = 0; i < lenn; i++) 
  {
    
    
       question=data.msg[i];
       if(data.set_audible=="1"){
       textToAudio(question);
       }
       
         
       for(tt=(data.msg[i+1]); tt>=0; tt--){
         let uio=1000;
         if(nxt==1){
          nxt=0;
          tt=0;
        }
         document.getElementById('course-apply-success2').innerHTML = Math.floor(tt)+" seconds left to answer";
        
         await task(uio);
         
       }
  
       
  }*/ 

}

              }
          }
        });  
      }, function() {
        $("#startButton").show(); 
      document.getElementById('course-apply-success').innerHTML = "Permission for camera is denied!";
    });     
});
});
/*
        
            */
                      } 
  
  </script>

<script type="text/javascript">
var nxt;
function nextfunc(){
    nxt=1;
    } 
    

      function sendVideoToAPI2 (blob, visiparam) {
    //alert("Api");
  //  alert("jana1");
    let fd = new FormData();
    let vfile = new File([blob], 'recording');
   // alert("jana2");
    
    fd.append('data', vfile);
    console.log(fd); // test to see if appending form data would work, it didn't this is completely empty. 

   // alert("jana3");
    let vform = new FormData();

    vform.append("file",vfile);
    
  //  alert("jana4");
   
    vform.append("visibilityoption",visiparam);
    vform.append("interview_id",sett_id);
    vform.append("time",starting_date);
   // alert("jana5");
    
        $.ajax({
   contentType: false,
         cache: false,
            type: "POST",
            
            url: "https://quantumhunts.com/dev/video-message/2/upload.php",
            processData: false,            
            data:vform,            
            success : function(data)
            {
                var response = JSON.parse(data);
                $("#storeButton").hide();
                $("#displayButton").hide();
                $("#completeButton").show();
                $("#ins").hide();
                document.getElementById('msgleft').innerHTML = "";
                $("#border").css({"border-width": "35px"});
                $("#inss").show();
                $("#recordingcontainer").hide();
                    
            }
        });
      }    
</script>

  <button id="startButton" onclick="recording()" class="btn btn-primary btn-sm mr-1"><i class="mdi mdi-circle text-danger mr-1 font-11"></i> 
Begin Interview</button>
  <div id="progress" style="display: none;">Your interview is in progress</div>
  <div id="inss" style="display:none;">
<center> <br>
<img src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/Interview-guide.jpg" style="height:150px;width:200px;" class="text-center align-middle align-center"> <br><br>
   1. Your interview is saved properly <br>
   2. Thank you for taking this interview <br>
   3. Status of this interview will update in applied jobs page <br>
  
  </center>
  </div>
  <div id="ins">

  <div class="row" id="ins">
  <div class="col-6">
  
  <div class="card">
   <div class="card-body border">
   
   Instructions to be followed <br>
   1.	Desktop with webcam and audio connectivity<br>
2.	Google Chrome Web Browser<br>
3.	Stable Wifi Connectivity (minimum 1GB of mobile/wifi data)<br>
   4. Start the interview <br>
   5. Grant permission for camera <br>
   6. Time left is for each question <br>
    </div>
   </div>
   </div>
   <div class="col-6">
   <div class="card">
   <div class="card-body border">
   <div id="interviewid"></div>
   <div id="interviewcompany"></div>
   <div id="interviewsubject"></div>
   <div id="interviewjob"></div>
   <div id="interviewend"></div>
   <br> <br> <br>
    </div>
   </div>

   </div>
  </div>
  </div>

  <button id="stopButton" class=" btn btn-primary-two text-dark font-weight-bold btn-sm" style="display:none"><i class="mdi mdi-square text-danger mr-1 font-11"></i>  Stop</button>

  <button id="storeButton" class=" btn btn-primary btn-sm mr-1" style="display:none"><i class="mdi mdi-check-circle text-light mr-1 font-11"></i>  Upload</button>
  <div id="displayButton" style="display:none"><br>
<img src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/Interview-guide.jpg" style="height:150px;width:200px;" class="text-center align-middle align-center"> <br><br> 
  <p class="text-center align-middle align-center">
  <span class="lead bg-primary text-white">One step to complete your interview <br>
  wait for few seconds</span> <br>
    <img src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/ab79a231234507.564a1d23814ef.gif" style="height:24px;width:24px;" class="text-center align-middle align-center">
    </p>
  </div>
  <div id="completeButton" style="display:none"><center> 
  
  <span class="lead bg-primary text-white" id="complete"> 
  Your interview is successfully completed!</span> <br>
  <a href="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455#" data-toggle="modal" data-target="#help-modal">Help and Support</a></center>
  </div>
  <div id="completeButton2" style="display:none"><center>
  <br>
<img src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/Interview-guide.jpg" style="height:150px;width:200px;" class="text-center align-middle align-center"> <br><br>
   <span class="lead bg-primary text-white" id="complete2">
  You already completed this interview!</span></center>
  </div>
<div class="row mt-3">
<div class="col-12 border" id="previewcontainer">
<div id="questions">Questions </div>
<div id="timealert"></div>
<div class="row">  <div class="col">
</div>
<div class="text-right col">  <button id="next" onclick="nextfunc()" class="btn btn-primary">Next</button></div> </div>
<!-- tj-->
<section>
<!-- tj-->
<div class="row lead no-gutters">

<div class="card col-8 col-xs-12 col-sm-6 col-md-6 col-lg-8 mb-0 coursecard bg-primary" style="color: white;">

<div id="course-apply-success" class="lead pl-1">

Hi Test Employer&nbsp;Test Employer, brace up for your interview</div>
</div>
<div class="card col-4 col-xs-12 col-sm-6 col-md-6 col-lg-4 mb-0 coursecard bg-warning">
<div id="course-apply-success2" class="lead pl-1">Time left</div>
</div>
</div>
</section>
  <!-- tj-->
  <video class="video-js video-tech" id="preview" autoplay="" muted="" style="width:100%;height:400px;" preload="true" fluid="true" width="640" height="400"></video>

  <button id="stopb" class="btn btn-primary">Stop</button>
  <!-- tj-->
  <script type="text/javascript">
//var scc;



</script>
<script>

    </script>
<!-- tj-->
</div>
</div>
<div class="row" id="wait">
<div class="col-12 mt-3 mb-3" id="recordingwait" style="display:none">
    <div class="row">
    <div class="col-2"></div>
    <div class="align-middle align-center col-8 align-center text-center">
       <p class="mt-2">Please wait for your video to be rendered. It usually takes a while, but we will make it awesome for you.</p>
    </div>
    <div class="col-2"></div>    
    </div>
    <p class="text-center align-middle align-center">
    <img src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/ab79a231234507.564a1d23814ef.gif" style="height:24px;width:24px;" class="text-center align-middle align-center">
    </p>
</div>    
<div class="col-12 mt-3 mb-3" id="recordingcontainer" style="display:none">

  <video id="my-video" class="d-none video-js vjs-tech vjs-theme-city vjs-big-play-centered bg-light" style="width:100%;height:400px;" controls="" preload="true" fluid="true" height="400"></video>
 
 <a id="downloadButton" class="button" style="display:none;">Download </a>
 
</div>
</div>
<div class="bottom">
  <pre id="log"></pre>
</div>

<script>
 
let preview = document.getElementById("preview");
let recording = document.getElementById("my-video");
//let my-video=document.getElementById("recording");
let startButton = document.getElementById("startButton");
let stopButton = document.getElementById("stopButton");
let downloadButton = document.getElementById("downloadButton");
let logElement = document.getElementById("log");
let recordingTimeMS =30000;
var chunks;
function log(msg) 
{
    //alert("1");
  //logElement.innerHTML += msg + "\n";
}
function wait(delayInMS) 
{
    //alert("2");    
  return new Promise(resolve => setTimeout(resolve, delayInMS));

}
function startRecording(stream, lengthInMS) {

    //alert("3");
  let recorder = new MediaRecorder(stream);
  let data = [];
  recorder.ondataavailable = function(e) {
			log('mediaRecorder.ondataavailable, e.data.size='+e.data.size);
			if (e.data && e.data.size > 0) {
				chunks.push(e.data);
			}
		};

  recorder.ondataavailable = event => data.push(event.data);
  recorder.start();
  
  log(recorder.state + " for " + (lengthInMS/1000) + " seconds...");
 
  let stopped = new Promise((resolve, reject) => {
    recorder.onstop = resolve;
    recorder.onerror = event => reject(event.name);
        //alert("4");
  });

let recorded = wait(lengthInMS).then(
    () => recorder.state == "recording" && recorder.stop() && $("#stopButton").hide() && alert("5")
);
 
  return Promise.all([
    stopped,
    recorded
  ])
  .then(() => data);
      //alert("6");
}
function stop(stream) 
{
        //alert("7");
 stream.getTracks().forEach(track => track.stop());
 $("#stopButton").hide();  
 $("#startButton").show();    
 $("#previewcontainer").hide();     
 $("#recordingwait").show();    
    
}
//checking
checkBrowser2();
function checkBrowser2() { 
          
          // Get the user-agent string 
          let userAgentString =  
              navigator.userAgent; 
        
          // Detect Chrome 
          let chromeAgent =  
              userAgentString.indexOf("Chrome") > -1; 
        
          // Detect Internet Explorer 
          let IExplorerAgent =  
              userAgentString.indexOf("MSIE") > -1 ||  
              userAgentString.indexOf("rv:") > -1; 
        
          // Detect Firefox 
          let firefoxAgent =  
              userAgentString.indexOf("Firefox") > -1; 
        
          // Detect Safari 
          let safariAgent =  
              userAgentString.indexOf("Safari") > -1; 
                
          // Discard Safari since it also matches Chrome 
          if ((chromeAgent) && (safariAgent))  
              safariAgent = false; 
        
  
                      if(safariAgent==true){
                      
                      }
                      else{
startButton.addEventListener("click", function() 
{
        //alert("8");
 $("#startButton").hide(); 
 $("#stopButton").hide();
 $("#previewcontainer").show();     
 $("#recordingcontainer").hide();  
 $("#storeButton").hide();
 $("#displayButton").hide();

  
 
  navigator.mediaDevices.getUserMedia({
    video: true,
    audio: true
  }).then(stream => {
    preview.srcObject = stream;
    downloadButton.href = stream;
    preview.captureStream = preview.captureStream || preview.mozCaptureStream;
    return new Promise(resolve => preview.onplaying = resolve);
  }).then(() => startRecording(preview.captureStream(), total))
  .then (recordedChunks => {
    let recordedBlob = new Blob(recordedChunks, { type: "video/webm" });
    recording.src = URL.createObjectURL(recordedBlob);
//    my-video.src = URL.createObjectURL(recordedBlob);    
    downloadButton.href = recording.src;
    downloadButton.download = "RecordedVideo.webm";

 $("#previewcontainer").hide();         
 $("#startButton").hide(); 
 $("#stopButton").hide();
 $("#storeButton").hide();
 $("#displayButton").show();
 $("#ins").hide();
 document.getElementById('msgleft').innerHTML = "";
 $("#border").css({"border-width": "35px"});
 $("#recordingwait").hide();     
 $("#recordingcontainer").show(); 

        var visitag = $("#visibletag").val();
        //alert(visitag); 
        //alert("j0");
        //alert(question_question);
       /*    */
      sendVideoToAPI2(recordedBlob,visitag); 
     // alert("j1");

    //alert("9");    
    log("Successfully recorded " + recordedBlob.size + " bytes of " +
        recordedBlob.type + " media.");
  })
  .catch(log);
}, false);stopButton.addEventListener("click", function() {
  stop(preview.srcObject);
  var visitag = $("#visibletag").val();
        //alert(visitag); 
      sendVideoToAPI2(recordedBlob,visitag); 
}, false);   
}   
}
</script>
                        <p class="text-center mt-3">
                        <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button>    	                                                           
                        </p>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->














<div id="meet" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-left">


                        <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold">Interview Details</h5> 
                        
                        <p class="text-left ">You can now attend tour interview publish to recruiters.</p>
                        <div class="card">
   <div class="card-body border">
   <div id="interviewid_meet"></div>
   <div id="interviewcompanym"></div>
   <div id="interviewjobm"></div>
   <div id="type"></div>
   <div id="locationm"></div>
   <div id="interviewendm"></div>

    </div>
   </div>


                        <p class="text-center mt-3">
                        <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button>    	                                                           
                        </p>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

   
<div id="fetch_interview">

<script type="text/javascript"> 
var interview_id = new Array();
     
var full_id = new Array();
            full_id.push('243');
            full_id.push('244');
            full_id.push('246');
            full_id.push('247');
            full_id.push('248');
            full_id.push('249');
            full_id.push('250');
            full_id.push('251');
            full_id.push('252');
            full_id.push('253');
            full_id.push('254');
            full_id.push('255');
            full_id.push('257');
            full_id.push('259');
            full_id.push('261');
            full_id.push('262');
        
var lk =0;
var total=0;
var sett_id = '';
var set_no = '';


//let nm=interview_idd.length;


//for(let k=0;k<nm;k++){

  //document.write('<div class="card border cta-box"><div class="card-body"> <button type="button" id='+interview_idd[k]+' class="btn btn-primary interview"><i class="uil uil-tv-retro"></i>'+' Interview '+interview_idd[k]+'</button></div></div>');
 
 //var btn3 = document.createElement("button");
 // btn3.innerHTML = "interview "+interview_idd[k];
 // $("#inter").append(btn3);
   // $(".interview:first").addClass("btn-primary");
  // $(".interview:first").addClass("btn");
 /* 
 var btn = document.createElement("BUTTON");
  btn.id = interview_id[k];
  btn.innerHTML = "Interview "+interview_id[k];
  document.body.appendChild(btn);
  document.write('</div></div>');
  document.getElementById(interview_id[k]).className = "interview"; */
//}

</script>
<div class="card border cta-box"><div class="card-body">
<h5 class="m-0 font-weight-bold cta-box-title1 text-left text-dark mb-2 text-uppercase blogmini font-12">My interviews</h5>
<!-- test -->
<div class="inbox-widget">
<!--<table class="table-bordered table-striped table-sm table-responsive mb-0" style="font-size:2.0rem;"> -->
<!--</table> -->
</div>
</div></div>
<script type="text/javascript">
var total2;
var total;
$(document).ready(function(){
  $(".interview").click(function(){
    sett_id = this.id;
    clicked_id2 = this.id;
    var id_of_interview = interview_id.includes(sett_id);
    if(id_of_interview==true)
    {
    $.ajax({
          url: "https://quantumhunts.com/dev/video-message/2/check.php",
          type: "POST",
          dataType: "json",
          data: {interview_id2:clicked_id2,fullid:full_id},
          success : function(data){
          
              if (data.code == "400")
              {
               
                if(clicked_id2==data.idd){
                  $("#border").css({"border-width": "0px"});
                  $("#resume-record").modal();
                }
                else{
                  $("#border").css({"border-width": "35px"});
                  $("#resume-record2").modal();
                }
              }
              if (data.code == "200")
              {
               if (data.error=="3")
               {
                  if(clicked_id2==data.fid){
                    $("#ins").hide();
                    $("#border").css({"border-width": "35px"});
                    document.getElementById('msgleft').innerHTML = "";
                    $("#completeButton").hide();
                    $("#inss").hide();
                    $("#completeButton2").show();
                    $("#displayButton").hide();
                    $("#startButton").hide();
                    $("#resume-record").modal();
                  }
               }
               else{
               document.getElementById('interviewid').innerHTML = "Interview id: "+clicked_id2;
               document.getElementById('interviewcompany').innerHTML = "Company: "+data.company_title;
               document.getElementById('interviewjob').innerHTML = "Job: "+data.job_title;
               document.getElementById('interviewsubject').innerHTML = "Subject: "+data.subject;
               document.getElementById('interviewend').innerHTML = "Complete Before: "+data.end;
                set_no = data.set;
                total = 0;
                total = data.total*60000;
                total2=data.total;
                if(lk==1){
                  $("#completeButton2").hide();
                  $("#ins").show();
                  $("#border").css({"border-width": "0px"});
                  document.getElementById('msgleft').innerHTML = "You can now attend our interview publish to recruiters.";
                  $("#resume-record").modal();
                $("#completeButton").hide();
                $("#wait").hide();
                $("#preview").show();
                $("#startButton").show();
                $("#recordingwait").show();
                $("#next").show();   
                
                }
                else{
                  document.getElementById('msgleft').innerHTML = "You can now attend our interview publish to recruiters.";
                  $("#border").css({"border-width": "0px"});
                  $("#resume-record").modal();
                }
              }
              }
          }
        }); 
    }
    else{
      $.ajax({
          url: "https://quantumhunts.com/dev/video-message/2/meet_check.php",
          type: "POST",
          dataType: "json",
          data: {interview_id2:clicked_id2},
          success : function(data){
          
              if (data.code == "200")
              {
                document.getElementById('interviewid_meet').innerHTML = "Interview id: "+clicked_id2;
               document.getElementById('interviewcompanym').innerHTML = "Company: "+data.company;
               document.getElementById('interviewjobm').innerHTML = "Job: "+data.job;
               document.getElementById('interviewendm').innerHTML = "Complete Before: "+data.end;
               document.getElementById('type').innerHTML = "Type: "+data.type;
               document.getElementById('locationm').innerHTML = "";
               if(data.type=="Face to Face"){
                document.getElementById('locationm').innerHTML = "Address: "+data.location;
               }
                $("#meet").modal();
              }
            }
        });        
    }
  });
});
</script>
<!-- Signup modal-->

<div id="no_interview" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-left">


                        <h5 class="mb-1 text-primary text-left text-uppercase purpletitle font-weight-bold"> You have been scheduled for 0 interview to attend</h5> 


                        <p class="text-center mt-3">
                        <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button>    	                                                           
                        </p>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

 <!-- Modal content -->
 <div id="ReferModal22" class="modal" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">
      <div class="modal" tabindex="-1" role="dialog" style="padding-right: 16px; display: block;overflow-y: scroll;" aria-modal="true">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
          <div class="modal-content border-5">
            <div class="modal-body" style="overflow-y: auto;"><div class="card-body">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
              <div class="rounded mb-1 pt-0 mt-0">
		<center> <h5 class="d-block  mt-0 mb-3 text-primary text-uppercase  blogmini">📢 Interview Invite
                </h5></center>
		<ul class="nav nav-tabs tab-grad mt-3">
						
						<li class="nav-item "> <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" data-toggle="tab" href="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455#profile11">Interviews  </a> </li>

						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" target="_blank" href="https://quantumhunts.com/user/view/jobs/"> Applied Jobs</a> </li>						
					</ul>
	

<div class="tab-content">
  <!--
    <div class="tab-pane show" id="referrals">
	<br>
        <p>yYou can now invite your friends through mail so that they join world's 1st video centric job platform. You would get rewarded when your friends create their account with us.</p>
                <div class="media-body">
                 
                 
            </div>
    </div>
-->        
 <div class="tab-pane active" id="profile11">
        <p class="mt-3">Interview details </p>
        <div class="row">
        <div class="col-12 col-xs-12 col-sm-12 col-md-4">
<div class="card tilebox-one shadow">
    <div class="card-body">
           <i class="uil uil-users-alt float-right"></i>
            <h6 class="text-uppercase mt-0 blogmini text-primary">attend</h6>
            <h2 class="my-2" id="active-users-count">0</h2>
             <p class="mb-0 text-muted">
             <span class="text-nowrap">Interview</span>  
                </p>
   </div> <!-- end card-body-->
</div></div>
<div class="col-12 col-xs-12 col-sm-12 col-md-4">
<div class="card tilebox-one shadow">
                                    <div class="card-body">
                                        <i class="uil uil-users-alt float-right"></i>
                                        <h6 class="text-uppercase mt-0 blogmini text-primary">completed </h6>
                                        <h2 class="my-2" id="active-users-count">2</h2>
                                        <p class="mb-0 text-muted">
                                            <span class="text-nowrap">interviews</span>  
                                        </p>
                                    </div> 
</div>
</div>
</div>
</div>       
</div>
<!-- tab content -->
</div>
    </div>
        </div>
      </div>
    </div>
    </div>
 <!-- modal content -->

<!-- Signup modal-->











</div></div>
 <script>
$(document).ready(function()
{ 
$("#fetch_interview").load("https://quantumhunts.com/dev/video-message/2/fetch_interview.php");    
});

</script>



          
    
 
<a class="" onclick="back()">
<div class="card border cta-box">
<div class="card-body">
<div class="float-center text-center">
</div>
<h4 class="text-uppercase font-13 text-dark blogmini">Dashboard</h4>
<p class="text-dark mb-1">Manage your jobs and applicants by visiting the job dashboard.</p>

<h4 onclick="back()" class="text-dark btn btn-warning btn-sm btn-rounded font-weight-bold" data-toggle="popover" data-trigger="hover" title="" data-original-title=""> <i class="uil uil-arrow-left"></i> Back</h4>
</div>
</div>
</a>




<div class="card border cta-box">
                                    <div class="card-body">
                                        
                                    <div class="float-center text-center"><img class="img-fluid" src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/source.gif" style="width:50%;height:50%;"></div>
                                    <h4 class="text-dark">Jobs</h4>

                                    <p class="mb-3">Explore relevent opportunities using Jobs at <span class="text-dark text-uppercase font-13 font-weight-bold">VJX</span>. Get the latest jobs and industry news.</p>

                                    <div class="float-center text-center">
                                    
            <a class="btn btn-outline-primary btn-sm btn-wide transition-3d-hover mb-2 mb-sm-0 mr-2" href="http://localhost/jobs">Jobs</a>                                    
                        
                                    </div>

                                    </div>
</div>    

 

 

                                <div class="card border cta-box overflow-hidden">
                                    <div class="card-body ribbon-box">
                                        <!--<span class="badge badge-primary">Top Jobs</span>-->
                                        <h5 class="font-weight-bold mb-3 text-left text-uppercase text-primary purpletitle">Top Jobs</h5>
                                        <!-- <div class="ribbon-two ribbon-two-primary"><span>Top Jobs</span></div>-->

                                    <!--
<div class="text-center cta-box1">
<img src="https://quantumhunts.com/user/assets/images/hero/mail_qh.png" height="64">
</div>

<h3 class="m-0 mb-3 font-weight-bold cta-box-title text-left">Popular Jobs</h3>
-->




<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/anti-money-laundering-lead-sensiple-india-pvt-ltd-chennai">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/anti-money-laundering-lead-sensiple-india-pvt-ltd-chennai">  
                                                     
                                                        <strong class="text-dark hoverzoom">Anti Money Laundering Lead</strong><br>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span>,
                                                       <span class="text-muted">Chennai, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/anti-money-laundering-lead-sensiple-india-pvt-ltd-chennai">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Anti Money Laundering Lead</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/anti-money-laundering-lead-chennai--india/1">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Anti Money Laundering Lead</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/anti-money-laundering-lead-chennai--india/1">Anti Money Laundering Lead</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Sensiple India Pvt Ltd                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Chennai, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job1').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid1").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job1").html('Saved');
                    $("#job1").removeClass('btn-primary');
                    $("#job1").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 2 Software company <BR/>
                                        Anti Money Laundering Lead <BR/>
                                        Chennai, India <BR/>
                                        Permanent  <BR/>
                                        Finance  <BR/>
                                          <BR/>
                                        We are a New Jersey corporation, established in 1999. Our footprints around the globe help us to ensure that we consistently maintain our delivery standards. We deliver IT products and services in the areas of BFSI, Customer Experience, Digital & Enterprise Transformation, Infrastructure and Independent Testing from ideation to execution, giving our clients an edge to outperform the competition. We do also provide Consulting and Staffing services in these areas. We are an ISO and CMMI 3 certification. <BR/>
                                        B.E/B.Tech <BR/>
                                        5,00,000 <BR/>
                                        7,00,000 <BR/>
                                        INR <BR/>
                                        AML, Finance, Business Analyst <BR/>
                                        5 <BR/>
                                        26/02/2020 <BR/>
                                        26/03/2020 <BR/>
                                        26/02/2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/senior-business-automation-associate-soroco-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/senior-business-automation-associate-soroco-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Senior Business Automation Associate</strong><br>
                                                       <span class="text-muted">Soroco</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/senior-business-automation-associate-soroco-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Senior Business Automation Associate</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/senior-business-automation-associate-bangalore--india/2">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Senior Business Automation Associate</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/senior-business-automation-associate-bangalore--india/2">Senior Business Automation Associate</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Soroco                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job2').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid2").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job2").html('Saved');
                    $("#job2").removeClass('btn-primary');
                    $("#job2").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Leading Artificial Intelligence Startup <BR/>
                                        Senior Business Automation Associate <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        DeepTech  <BR/>
                                          <BR/>
                                        We are a US-based Leading Software company providing AI based solutions to their clients. Their goal is to make work place smarter and provides support to top clients across various industries such as Retail/E-commerce, Banking, Financial, Healthcare and Airlines.
 <BR/>
                                        B.E/B.Tech <BR/>
                                        10,00,000 <BR/>
                                        12,00,000 <BR/>
                                        INR <BR/>
                                        Artificial Intelligence, Machine Learning <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/full-stack-developer-infosys-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/full-stack-developer-infosys-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Full Stack Developer</strong><br>
                                                       <span class="text-muted">Infosys</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/full-stack-developer-infosys-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">Infosys</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/full-stack-developer-bangalore--india/3">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">Infosys</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/full-stack-developer-bangalore--india/3">Full Stack Developer</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Infosys                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job3').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid3").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job3").html('Saved');
                    $("#job3").removeClass('btn-primary');
                    $("#job3").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Full Stack Developer <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        Leading provider of next generation consulting, technology and outsourcing solutions. Ranks as one among the top 100 most innovative companies in Forbes.
 <BR/>
                                        B.E <BR/>
                                        5,00,000 <BR/>
                                        8,00,000 <BR/>
                                        INR <BR/>
                                        Java , Full stack <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/associate-consultant-fresher-tcs-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/associate-consultant-fresher-tcs-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Associate Consultant- Fresher</strong><br>
                                                       <span class="text-muted">TCS</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/associate-consultant-fresher-tcs-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Associate Consultant- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/associate-consultant--fresher-bangalore--india/6">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Associate Consultant- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/associate-consultant--fresher-bangalore--india/6">Associate Consultant- Fresher</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        TCS                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job6').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid6").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job6").html('Saved');
                    $("#job6").removeClass('btn-primary');
                    $("#job6").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Associate Consultant- Fresher <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        (Nasdaq-100 listed) is one of the world’s leading professional services companies, transforming clients’ business, operating and technology models for the digital era.  

 <BR/>
                                        B.E/B.Tech <BR/>
                                        4,00,000 <BR/>
                                        6,00,000 <BR/>
                                        INR <BR/>
                                        Fresher <BR/>
                                        20 <BR/>
                                        26-02-2020 <BR/>
                                        21-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/data-scientist-lead-soroco-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/data-scientist-lead-soroco-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Data Scientist Lead</strong><br>
                                                       <span class="text-muted">Soroco</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/data-scientist-lead-soroco-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Data Scientist Lead</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/data-scientist-lead-bangalore--india/7">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Data Scientist Lead</Strong><BR/>
                                                       <span class="text-muted">Soroco</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/data-scientist-lead-bangalore--india/7">Data Scientist Lead</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Soroco                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job7').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid7").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job7").html('Saved');
                    $("#job7").removeClass('btn-primary');
                    $("#job7").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Leading Artificial Intelligence Startup <BR/>
                                        Data Scientist Lead <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        DeepTech  <BR/>
                                          <BR/>
                                        We are a US-based Leading Software company providing AI based solutions to their clients. Their goal is to make work place smarter and provides support to top clients across various industries such as Retail/E-commerce, Banking, Financial, Healthcare and Airlines.
 <BR/>
                                        B.E/B.tech/M.tech <BR/>
                                        6,00,000 <BR/>
                                        10,00.000 <BR/>
                                        INR <BR/>
                                        Artificial Intelligence, Machine Learning, Data Science <BR/>
                                        5 <BR/>
                                        21/02/2020 <BR/>
                                        21/03/2020 <BR/>
                                        21/02/2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/software-test-analyst-fresher-tcs-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/software-test-analyst-fresher-tcs-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Software Test Analyst- Fresher</strong><br>
                                                       <span class="text-muted">TCS</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/software-test-analyst-fresher-tcs-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Software Test Analyst- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/software-test-analyst--fresher-bangalore--india/9">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Software Test Analyst- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/software-test-analyst--fresher-bangalore--india/9">Software Test Analyst- Fresher</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        TCS                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job9').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid9").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job9").html('Saved');
                    $("#job9").removeClass('btn-primary');
                    $("#job9").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Software Test Analyst- Fresher <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        (Nasdaq-100 listed) is one of the world’s leading professional services companies, transforming clients’ business, operating and technology models for the digital era.  

 <BR/>
                                        B.E/B.Tech <BR/>
                                        4,00,000 <BR/>
                                        6,00,000 <BR/>
                                        INR <BR/>
                                        Fresher <BR/>
                                        20 <BR/>
                                        26-02-2020 <BR/>
                                        21-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/chartered-accountant-corporate-consultant-sensiple-chennai">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/chartered-accountant-corporate-consultant-sensiple-chennai">  
                                                     
                                                        <strong class="text-dark hoverzoom">Chartered Accountant Corporate Consultant</strong><br>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span>,
                                                       <span class="text-muted">Chennai, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/chartered-accountant-corporate-consultant-sensiple-chennai">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Chartered Accountant Corporate Consultant</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/chartered-accountant-corporate-consultant-chennai--india/12">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Chartered Accountant Corporate Consultant</Strong><BR/>
                                                       <span class="text-muted">Sensiple India Pvt Ltd</span><BR/>
                                                       <span class="text-muted">Chennai, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/chartered-accountant-corporate-consultant-chennai--india/12">Chartered Accountant Corporate Consultant</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Sensiple India Pvt Ltd                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Chennai, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job12').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid12").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job12").html('Saved');
                    $("#job12").removeClass('btn-primary');
                    $("#job12").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Leading Tier 2 Software company <BR/>
                                        Chartered Accountant Corporate Consultant <BR/>
                                        Chennai, India <BR/>
                                        Permanent  <BR/>
                                        Finance  <BR/>
                                          <BR/>
                                        ISO and CMMI 3 certified IT Software company. <BR/>
                                        Completion of CA Finals <BR/>
                                        7,00,000 <BR/>
                                        10,00,000 <BR/>
                                        INR <BR/>
                                        CA, Finance,  <BR/>
                                         <BR/>
                                        26/02/2020 <BR/>
                                        26/03/2020 <BR/>
                                        26/02/2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/hr-fresher-tcs-bangalore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/hr-fresher-tcs-bangalore">  
                                                     
                                                        <strong class="text-dark hoverzoom">HR- Fresher</strong><br>
                                                       <span class="text-muted">TCS</span>,
                                                       <span class="text-muted">Bangalore, India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/hr-fresher-tcs-bangalore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">HR- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/hr--fresher-bangalore--india/10">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">HR- Fresher</Strong><BR/>
                                                       <span class="text-muted">TCS</span><BR/>
                                                       <span class="text-muted">Bangalore, India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/hr--fresher-bangalore--india/10">HR- Fresher</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        TCS                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Bangalore, India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job10').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid10").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job10").html('Saved');
                    $("#job10").removeClass('btn-primary');
                    $("#job10").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        HR- Fresher <BR/>
                                        Bangalore, India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        (Nasdaq-100 listed) is one of the world’s leading professional services companies, transforming clients’ business, operating and technology models for the digital era.  

 <BR/>
                                        B.E/B.Tech/B.sc and MBA HR_2020 Graduates <BR/>
                                        4,00,000 <BR/>
                                        6,00,000 <BR/>
                                        INR <BR/>
                                        Fresher <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        21-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/full-stack-developer-hcl-ncr">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/full-stack-developer-hcl-ncr">  
                                                     
                                                        <strong class="text-dark hoverzoom">Full Stack Developer</strong><br>
                                                       <span class="text-muted">HCL</span>,
                                                       <span class="text-muted">NCR,India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/full-stack-developer-hcl-ncr">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">HCL</span><BR/>
                                                       <span class="text-muted">NCR,India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/full-stack-developer-ncr-india/13">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Full Stack Developer</Strong><BR/>
                                                       <span class="text-muted">HCL</span><BR/>
                                                       <span class="text-muted">NCR,India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/full-stack-developer-ncr-india/13">Full Stack Developer</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        HCL                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        NCR,India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job13').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid13").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job13").html('Saved');
                    $("#job13").removeClass('btn-primary');
                    $("#job13").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Tier 1 Software company <BR/>
                                        Full Stack Developer <BR/>
                                        NCR,India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        Leading provider of next generation consulting, technology and outsourcing solutions. Ranks as one among the top 100 most innovative companies in Forbes.
 <BR/>
                                        B.E <BR/>
                                        5,00,000 <BR/>
                                        8,00,000 <BR/>
                                        INR <BR/>
                                        Java , Full stack <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->






<div class="media mt-2 mb-2">
    <a href="https://quantumhunts.com/job/golang-developer-engineer-babu-indore">     
                                           <i class="mr-2 h4 mdi mdi-circle text-dark mr-1 font-11"></i></a>
                                            <div class="media-body  text-dark">
                                                <a class="text-dark" href="https://quantumhunts.com/job/golang-developer-engineer-babu-indore">  
                                                     
                                                        <strong class="text-dark hoverzoom">Golang Developer</strong><br>
                                                       <span class="text-muted">Engineer Babu</span>,
                                                       <span class="text-muted">Indore,India</span><br>
                                                </a>
                                            </div>
    
</div>




<!--

                                            <div class="col-sm-12 m-0 border-bottom  ribbon-box p-2 pt-0 " style="padding-top:0px;">
                                                <div class="media">
                                  <a target="_blank" href="https://quantumhunts.com/job/golang-developer-engineer-babu-indore">   
                                                    <div class=" media-body grid-container text-dark ribbon-box">
                                                      
                                                        <Strong class="text-dark">Golang Developer</Strong><BR/>
                                                       <span class="text-muted">Engineer Babu</span><BR/>
                                                       <span class="text-muted">Indore,India</span><BR/><BR/>
                                                     
                                            </div>
                                    </a>
                                    </div>
                                            </div>

-->




                                
                            <!--    
                              <div class="border1 shadow1 col-lg-6 col-md-5 col-xs-12 col-sm-12 p-3 jobcard">
                                  <a href="https://quantumhunts.com/jobs/view/golang-developer-indore-india/14">
                                                    <div class="grid-container text-dark ribbon-box">
                                                        <span class="badge badge-outline-secondary badge-pill float-right">Premium</span>
                                                        <Strong class="text-dark">Golang Developer</Strong><BR/>
                                                       <span class="text-muted">Engineer Babu</span><BR/>
                                                       <span class="text-muted">Indore,India</span><BR/><BR/>
                                                       <i class="dripicons dripicons-preview"></i>
                                                       
                                     
                                                       
                                                    </div>
                                                     </a> 
                                                </div>
                                              
                                           
                            -->
     


<!--     

   <div class="">
   <div class="row p-1">     

                              <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
                                                    <div class="grid-container">
                                                        <i class="dripicons-briefcase"></i> &nbsp;
                                                        
                                                       <a class="" style="color:black;" href="https://quantumhunts.com/jobs/view/golang-developer-indore-india/14">Golang Developer</a>
                                                    </div>
                                                </div>
                                 <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6">
                                                    <div class="grid-container">
                                                        Engineer Babu                                                    </div>
                                                </div>                
                                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                                                    <div class="grid-container float-left">
                                                        Indore,India                                                        <i class="uil uil-angle-right-b"></i>
                                                    </div>
                                                </div>
                                                
     </div>                                           
     </div>     

-->



                                              
                                                    
          
  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#job14').click(function(e){
        e.preventDefault();

        var jobid= $("#jobid14").val();
        var userid= $("#userid").val(); 
        var cvid= $("#cvid").val();
        var comments="default";
        var option="save";
        
        //alert(email+firstname+lastname+title+countrycode+mobile+password);
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/jobs/home/apply/",
            dataType: "json",
            data: {jobid:jobid,userid:userid,cvid:cvid,comments:comments,option:option},            
            success : function(data){
                //alert(data.code);
                if (data.code == "201")
                {
                    //alert("Success: " +data.msg);
                    $("#job14").html('Saved');
                    $("#job14").removeClass('btn-primary');
                    $("#job14").addClass('btn-info');
                    
                } 
                else
                {
                    //alert("User already verfified but going through login again? why? Just send him to login page: " +data.msg);
                    $(".display-error").html(""+data.msg+"");
                    $(".display-error").css("display","block");
                    
                }                 
            }
        });


      });
  });
</script>
                                                    
                                                    
                                                    
                                                  
                                                  <!--
                                        Vibrant and Enthusiastic Startup <BR/>
                                        Golang Developer <BR/>
                                        Indore,India <BR/>
                                        Permanent  <BR/>
                                        IT  <BR/>
                                          <BR/>
                                        Leading provider of next generation technology and software solutions from Indore to worldwide.
 <BR/>
                                        B.E <BR/>
                                        5,00,000 <BR/>
                                        9,00,000 <BR/>
                                        INR <BR/>
                                        Java , Full stack <BR/>
                                        5 <BR/>
                                        26-02-2020 <BR/>
                                        26-03-2020 <BR/>
                                        26-02-2020 <BR/>
                                        Active <BR/>
                                        -->



                                    </div>
                                    <!-- end card-body -->
                                </div>  


                            </div>
                            
                        </div>
                        <!-- end row-->
                        
                    </div> <!-- End Content -->

                  
                </div>               
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                 
                

            </div> <!-- end wrapper-->
        </div>
        <!-- END Container -->
        
        




<!-- Signup modal-->

<div id="video-jd-modal" class="modal  fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-body card-body text-center">


                        <h5 class="mb-1 text-primary text-center text-uppercase purpletitle font-weight-bold">Upload Job Description Video</h5> 
                        
                        <p class="text-center mx-3">Give a brief discription to the candidate about the job requirement in a professional video. Once you upload the job will go for approval however the candidates can still apply during this period. Also, the upload might take sometime, so wait for it to complete.</p>


<div id="jdprogressbar"></div>



<div id="jdvideopreview">
<div data-setup="{}" errordisplay="false" fluid="true" preload="true" class="video-js vjs-tech vjs-theme-city vjs-big-play-centered bg-light vjs-paused my-video-dimensions vjs-fluid vjs-workinghover vjs-v7 vjs-user-active vjs-error vjs-controls-disabled" id="my-video" tabindex="-1" role="region" lang="en" aria-label="Video Player"><video id="my-video_html5_api" class="vjs-tech" preload="true" fluid="true" errordisplay="false" data-setup="{}" tabindex="-1" role="application">
    <source src="" type="video/mp4">
  </video><div class="vjs-poster vjs-hidden" aria-disabled="false"></div><div class="vjs-text-track-display" aria-live="off" aria-atomic="true"></div><div class="vjs-loading-spinner" dir="ltr"><span class="vjs-control-text">Video Player is loading.</span></div><button class="vjs-big-play-button" type="button" title="Play Video" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Play Video</span></button><div class="vjs-control-bar" dir="ltr"><button class="vjs-play-control vjs-control vjs-button" type="button" title="Play" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Play</span></button><div class="vjs-volume-panel vjs-control vjs-volume-panel-horizontal"><button class="vjs-mute-control vjs-control vjs-button" type="button" title="Mute" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Mute</span></button><div class="vjs-volume-control vjs-control vjs-volume-horizontal"><div tabindex="0" class="vjs-volume-bar vjs-slider-bar vjs-slider vjs-slider-horizontal" role="slider" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" aria-label="Volume Level" aria-live="polite"><div class="vjs-volume-level"><span class="vjs-control-text"></span></div></div></div></div><div class="vjs-current-time vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Current Time&nbsp;</span><span class="vjs-current-time-display" aria-live="off" role="presentation">0:00</span></div><div class="vjs-time-control vjs-time-divider" aria-hidden="true"><div><span>/</span></div></div><div class="vjs-duration vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Duration&nbsp;</span><span class="vjs-duration-display" aria-live="off" role="presentation">0:00</span></div><div class="vjs-progress-control vjs-control"><div tabindex="0" class="vjs-progress-holder vjs-slider vjs-slider-horizontal" role="slider" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" aria-label="Progress Bar"><div class="vjs-load-progress"><span class="vjs-control-text"><span>Loaded</span>: <span class="vjs-control-text-loaded-percentage">0%</span></span></div><div class="vjs-mouse-display"><div class="vjs-time-tooltip" aria-hidden="true"></div></div><div class="vjs-play-progress vjs-slider-bar" aria-hidden="true"><div class="vjs-time-tooltip" aria-hidden="true"></div></div></div></div><div class="vjs-live-control vjs-control vjs-hidden"><div class="vjs-live-display" aria-live="off"><span class="vjs-control-text">Stream Type&nbsp;</span>LIVE</div></div><button class="vjs-seek-to-live-control vjs-control" type="button" title="Seek to live, currently behind live" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Seek to live, currently behind live</span><span class="vjs-seek-to-live-text" aria-hidden="true">LIVE</span></button><div class="vjs-remaining-time vjs-time-control vjs-control"><span class="vjs-control-text" role="presentation">Remaining Time&nbsp;</span><span aria-hidden="true">-</span><span class="vjs-remaining-time-display" aria-live="off" role="presentation">0:00</span></div><div class="vjs-custom-control-spacer vjs-spacer ">&nbsp;</div><div class="vjs-playback-rate vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><div class="vjs-playback-rate-value">1x</div><button class="vjs-playback-rate vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Playback Rate" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Playback Rate</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"></ul></div></div><div class="vjs-chapters-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-chapters-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Chapters" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Chapters</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-title">Chapters</li></ul></div></div><div class="vjs-descriptions-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-descriptions-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Descriptions" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Descriptions</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-item vjs-selected" role="menuitemradio" aria-disabled="false" tabindex="-1" aria-checked="true"><span class="vjs-menu-item-text">descriptions off</span><span class="vjs-control-text" aria-live="polite">, selected</span></li></ul></div></div><div class="vjs-subs-caps-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-subs-caps-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Captions" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Captions</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"><li class="vjs-menu-item vjs-selected" role="menuitemradio" aria-disabled="false" tabindex="-1" aria-checked="true"><span class="vjs-menu-item-text">captions and subtitles off</span><span class="vjs-control-text" aria-live="polite">, selected</span></li></ul></div></div><div class="vjs-audio-button vjs-menu-button vjs-menu-button-popup vjs-control vjs-button vjs-hidden"><button class="vjs-audio-button vjs-menu-button vjs-menu-button-popup vjs-button" type="button" aria-disabled="false" title="Audio Track" aria-haspopup="true" aria-expanded="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Audio Track</span></button><div class="vjs-menu"><ul class="vjs-menu-content" role="menu"></ul></div></div><button class="vjs-picture-in-picture-control vjs-control vjs-button vjs-disabled" type="button" title="Picture-in-Picture" aria-disabled="true" disabled="disabled"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Picture-in-Picture</span></button><button class="vjs-fullscreen-control vjs-control vjs-button" type="button" title="Fullscreen" aria-disabled="false"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Fullscreen</span></button></div><div class="vjs-error-display vjs-modal-dialog" aria-describedby="my-video_component_680_description" aria-hidden="false" aria-label="Modal Window" role="dialog"><p class="vjs-modal-dialog-description vjs-control-text" id="my-video_component_680_description">This is a modal window.</p><div class="vjs-modal-dialog-content" role="document">No compatible source was found for this media.</div></div><div class="vjs-modal-dialog vjs-hidden  vjs-text-track-settings" aria-describedby="my-video_component_684_description" aria-hidden="true" aria-label="Caption Settings Dialog" role="dialog"><p class="vjs-modal-dialog-description vjs-control-text" id="my-video_component_684_description">Beginning of dialog window. Escape will cancel and close the window.</p><div class="vjs-modal-dialog-content" role="document"><div class="vjs-track-settings-colors"><fieldset class="vjs-fg-color vjs-track-setting"><legend id="captions-text-legend-my-video_component_684">Text</legend><label id="captions-foreground-color-my-video_component_684" class="vjs-label">Color</label><select aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-color-my-video_component_684"><option id="captions-foreground-color-my-video_component_684-White" value="#FFF" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-color-my-video_component_684 captions-foreground-color-my-video_component_684-White">White</option><option id="captions-foreground-color-my-video_component_684-Black" value="#000" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-color-my-video_component_684 captions-foreground-color-my-video_component_684-Black">Black</option><option id="captions-foreground-color-my-video_component_684-Red" value="#F00" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-color-my-video_component_684 captions-foreground-color-my-video_component_684-Red">Red</option><option id="captions-foreground-color-my-video_component_684-Green" value="#0F0" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-color-my-video_component_684 captions-foreground-color-my-video_component_684-Green">Green</option><option id="captions-foreground-color-my-video_component_684-Blue" value="#00F" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-color-my-video_component_684 captions-foreground-color-my-video_component_684-Blue">Blue</option><option id="captions-foreground-color-my-video_component_684-Yellow" value="#FF0" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-color-my-video_component_684 captions-foreground-color-my-video_component_684-Yellow">Yellow</option><option id="captions-foreground-color-my-video_component_684-Magenta" value="#F0F" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-color-my-video_component_684 captions-foreground-color-my-video_component_684-Magenta">Magenta</option><option id="captions-foreground-color-my-video_component_684-Cyan" value="#0FF" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-color-my-video_component_684 captions-foreground-color-my-video_component_684-Cyan">Cyan</option></select><span class="vjs-text-opacity vjs-opacity"><label id="captions-foreground-opacity-my-video_component_684" class="vjs-label">Transparency</label><select aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-opacity-my-video_component_684"><option id="captions-foreground-opacity-my-video_component_684-Opaque" value="1" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-opacity-my-video_component_684 captions-foreground-opacity-my-video_component_684-Opaque">Opaque</option><option id="captions-foreground-opacity-my-video_component_684-SemiTransparent" value="0.5" aria-labelledby="captions-text-legend-my-video_component_684 captions-foreground-opacity-my-video_component_684 captions-foreground-opacity-my-video_component_684-SemiTransparent">Semi-Transparent</option></select></span></fieldset><fieldset class="vjs-bg-color vjs-track-setting"><legend id="captions-background-my-video_component_684">Background</legend><label id="captions-background-color-my-video_component_684" class="vjs-label">Color</label><select aria-labelledby="captions-background-my-video_component_684 captions-background-color-my-video_component_684"><option id="captions-background-color-my-video_component_684-Black" value="#000" aria-labelledby="captions-background-my-video_component_684 captions-background-color-my-video_component_684 captions-background-color-my-video_component_684-Black">Black</option><option id="captions-background-color-my-video_component_684-White" value="#FFF" aria-labelledby="captions-background-my-video_component_684 captions-background-color-my-video_component_684 captions-background-color-my-video_component_684-White">White</option><option id="captions-background-color-my-video_component_684-Red" value="#F00" aria-labelledby="captions-background-my-video_component_684 captions-background-color-my-video_component_684 captions-background-color-my-video_component_684-Red">Red</option><option id="captions-background-color-my-video_component_684-Green" value="#0F0" aria-labelledby="captions-background-my-video_component_684 captions-background-color-my-video_component_684 captions-background-color-my-video_component_684-Green">Green</option><option id="captions-background-color-my-video_component_684-Blue" value="#00F" aria-labelledby="captions-background-my-video_component_684 captions-background-color-my-video_component_684 captions-background-color-my-video_component_684-Blue">Blue</option><option id="captions-background-color-my-video_component_684-Yellow" value="#FF0" aria-labelledby="captions-background-my-video_component_684 captions-background-color-my-video_component_684 captions-background-color-my-video_component_684-Yellow">Yellow</option><option id="captions-background-color-my-video_component_684-Magenta" value="#F0F" aria-labelledby="captions-background-my-video_component_684 captions-background-color-my-video_component_684 captions-background-color-my-video_component_684-Magenta">Magenta</option><option id="captions-background-color-my-video_component_684-Cyan" value="#0FF" aria-labelledby="captions-background-my-video_component_684 captions-background-color-my-video_component_684 captions-background-color-my-video_component_684-Cyan">Cyan</option></select><span class="vjs-bg-opacity vjs-opacity"><label id="captions-background-opacity-my-video_component_684" class="vjs-label">Transparency</label><select aria-labelledby="captions-background-my-video_component_684 captions-background-opacity-my-video_component_684"><option id="captions-background-opacity-my-video_component_684-Opaque" value="1" aria-labelledby="captions-background-my-video_component_684 captions-background-opacity-my-video_component_684 captions-background-opacity-my-video_component_684-Opaque">Opaque</option><option id="captions-background-opacity-my-video_component_684-SemiTransparent" value="0.5" aria-labelledby="captions-background-my-video_component_684 captions-background-opacity-my-video_component_684 captions-background-opacity-my-video_component_684-SemiTransparent">Semi-Transparent</option><option id="captions-background-opacity-my-video_component_684-Transparent" value="0" aria-labelledby="captions-background-my-video_component_684 captions-background-opacity-my-video_component_684 captions-background-opacity-my-video_component_684-Transparent">Transparent</option></select></span></fieldset><fieldset class="vjs-window-color vjs-track-setting"><legend id="captions-window-my-video_component_684">Window</legend><label id="captions-window-color-my-video_component_684" class="vjs-label">Color</label><select aria-labelledby="captions-window-my-video_component_684 captions-window-color-my-video_component_684"><option id="captions-window-color-my-video_component_684-Black" value="#000" aria-labelledby="captions-window-my-video_component_684 captions-window-color-my-video_component_684 captions-window-color-my-video_component_684-Black">Black</option><option id="captions-window-color-my-video_component_684-White" value="#FFF" aria-labelledby="captions-window-my-video_component_684 captions-window-color-my-video_component_684 captions-window-color-my-video_component_684-White">White</option><option id="captions-window-color-my-video_component_684-Red" value="#F00" aria-labelledby="captions-window-my-video_component_684 captions-window-color-my-video_component_684 captions-window-color-my-video_component_684-Red">Red</option><option id="captions-window-color-my-video_component_684-Green" value="#0F0" aria-labelledby="captions-window-my-video_component_684 captions-window-color-my-video_component_684 captions-window-color-my-video_component_684-Green">Green</option><option id="captions-window-color-my-video_component_684-Blue" value="#00F" aria-labelledby="captions-window-my-video_component_684 captions-window-color-my-video_component_684 captions-window-color-my-video_component_684-Blue">Blue</option><option id="captions-window-color-my-video_component_684-Yellow" value="#FF0" aria-labelledby="captions-window-my-video_component_684 captions-window-color-my-video_component_684 captions-window-color-my-video_component_684-Yellow">Yellow</option><option id="captions-window-color-my-video_component_684-Magenta" value="#F0F" aria-labelledby="captions-window-my-video_component_684 captions-window-color-my-video_component_684 captions-window-color-my-video_component_684-Magenta">Magenta</option><option id="captions-window-color-my-video_component_684-Cyan" value="#0FF" aria-labelledby="captions-window-my-video_component_684 captions-window-color-my-video_component_684 captions-window-color-my-video_component_684-Cyan">Cyan</option></select><span class="vjs-window-opacity vjs-opacity"><label id="captions-window-opacity-my-video_component_684" class="vjs-label">Transparency</label><select aria-labelledby="captions-window-my-video_component_684 captions-window-opacity-my-video_component_684"><option id="captions-window-opacity-my-video_component_684-Transparent" value="0" aria-labelledby="captions-window-my-video_component_684 captions-window-opacity-my-video_component_684 captions-window-opacity-my-video_component_684-Transparent">Transparent</option><option id="captions-window-opacity-my-video_component_684-SemiTransparent" value="0.5" aria-labelledby="captions-window-my-video_component_684 captions-window-opacity-my-video_component_684 captions-window-opacity-my-video_component_684-SemiTransparent">Semi-Transparent</option><option id="captions-window-opacity-my-video_component_684-Opaque" value="1" aria-labelledby="captions-window-my-video_component_684 captions-window-opacity-my-video_component_684 captions-window-opacity-my-video_component_684-Opaque">Opaque</option></select></span></fieldset></div><div class="vjs-track-settings-font"><fieldset class="vjs-font-percent vjs-track-setting"><legend id="captions-font-size-my-video_component_684" class="">Font Size</legend><select aria-labelledby="captions-font-size-my-video_component_684"><option id="captions-font-size-my-video_component_684-50" value="0.50" aria-labelledby="captions-font-size-my-video_component_684 captions-font-size-my-video_component_684-50">50%</option><option id="captions-font-size-my-video_component_684-75" value="0.75" aria-labelledby="captions-font-size-my-video_component_684 captions-font-size-my-video_component_684-75">75%</option><option id="captions-font-size-my-video_component_684-100" value="1.00" aria-labelledby="captions-font-size-my-video_component_684 captions-font-size-my-video_component_684-100">100%</option><option id="captions-font-size-my-video_component_684-125" value="1.25" aria-labelledby="captions-font-size-my-video_component_684 captions-font-size-my-video_component_684-125">125%</option><option id="captions-font-size-my-video_component_684-150" value="1.50" aria-labelledby="captions-font-size-my-video_component_684 captions-font-size-my-video_component_684-150">150%</option><option id="captions-font-size-my-video_component_684-175" value="1.75" aria-labelledby="captions-font-size-my-video_component_684 captions-font-size-my-video_component_684-175">175%</option><option id="captions-font-size-my-video_component_684-200" value="2.00" aria-labelledby="captions-font-size-my-video_component_684 captions-font-size-my-video_component_684-200">200%</option><option id="captions-font-size-my-video_component_684-300" value="3.00" aria-labelledby="captions-font-size-my-video_component_684 captions-font-size-my-video_component_684-300">300%</option><option id="captions-font-size-my-video_component_684-400" value="4.00" aria-labelledby="captions-font-size-my-video_component_684 captions-font-size-my-video_component_684-400">400%</option></select></fieldset><fieldset class="vjs-edge-style vjs-track-setting"><legend id="my-video_component_684" class="">Text Edge Style</legend><select aria-labelledby="my-video_component_684"><option id="my-video_component_684-None" value="none" aria-labelledby="my-video_component_684 my-video_component_684-None">None</option><option id="my-video_component_684-Raised" value="raised" aria-labelledby="my-video_component_684 my-video_component_684-Raised">Raised</option><option id="my-video_component_684-Depressed" value="depressed" aria-labelledby="my-video_component_684 my-video_component_684-Depressed">Depressed</option><option id="my-video_component_684-Uniform" value="uniform" aria-labelledby="my-video_component_684 my-video_component_684-Uniform">Uniform</option><option id="my-video_component_684-Dropshadow" value="dropshadow" aria-labelledby="my-video_component_684 my-video_component_684-Dropshadow">Dropshadow</option></select></fieldset><fieldset class="vjs-font-family vjs-track-setting"><legend id="captions-font-family-my-video_component_684" class="">Font Family</legend><select aria-labelledby="captions-font-family-my-video_component_684"><option id="captions-font-family-my-video_component_684-ProportionalSansSerif" value="proportionalSansSerif" aria-labelledby="captions-font-family-my-video_component_684 captions-font-family-my-video_component_684-ProportionalSansSerif">Proportional Sans-Serif</option><option id="captions-font-family-my-video_component_684-MonospaceSansSerif" value="monospaceSansSerif" aria-labelledby="captions-font-family-my-video_component_684 captions-font-family-my-video_component_684-MonospaceSansSerif">Monospace Sans-Serif</option><option id="captions-font-family-my-video_component_684-ProportionalSerif" value="proportionalSerif" aria-labelledby="captions-font-family-my-video_component_684 captions-font-family-my-video_component_684-ProportionalSerif">Proportional Serif</option><option id="captions-font-family-my-video_component_684-MonospaceSerif" value="monospaceSerif" aria-labelledby="captions-font-family-my-video_component_684 captions-font-family-my-video_component_684-MonospaceSerif">Monospace Serif</option><option id="captions-font-family-my-video_component_684-Casual" value="casual" aria-labelledby="captions-font-family-my-video_component_684 captions-font-family-my-video_component_684-Casual">Casual</option><option id="captions-font-family-my-video_component_684-Script" value="script" aria-labelledby="captions-font-family-my-video_component_684 captions-font-family-my-video_component_684-Script">Script</option><option id="captions-font-family-my-video_component_684-SmallCaps" value="small-caps" aria-labelledby="captions-font-family-my-video_component_684 captions-font-family-my-video_component_684-SmallCaps">Small Caps</option></select></fieldset></div><div class="vjs-track-settings-controls"><button type="button" class="vjs-default-button" title="restore all settings to the default values">Reset<span class="vjs-control-text"> restore all settings to the default values</span></button><button type="button" class="vjs-done-button">Done</button></div></div><button class="vjs-close-button vjs-control vjs-button" type="button" aria-disabled="false" title="Close Modal Dialog"><span aria-hidden="true" class="vjs-icon-placeholder"></span><span class="vjs-control-text" aria-live="polite">Close Modal Dialog</span></button><p class="vjs-control-text">End of dialog window.</p></div></div>

</div>
<div id="videoerr"></div>





<div class="upload-btnv-wrapper mt-2 float-left">
  <button class="btnv btn">Upload a file</button>
  <input type="file" name="myfile" id="videofile" value="myvideo">
</div>

  <div class="form-group formforvideo" id="privacydiv">
 
 <br><br>
  <button type="button" class="btn btn-primary mr-auto" id="videosave">Save</button>
 <button type="button" class="btn btn-primary mr-auto" id="cancelvideo">Back</button>
  <button type="button" class="btn btn-primary mr-auto" data-dismiss="modal" aria-label="Close" id="quitvideo">Cancel Upload</button>
  </div>


<br><br>

  
  <div class="text-left"><br>
  <p class="text-left">
      
<!--  <a target="_blank" href="https://quantumhunts.com/bytes/quantumhunts/tips-for-creating-a-quantumhunts-video-resume">How to create a video JD</a><BR/>-->
  <a href="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455" data-toggle="modal" data-target="#help-modal">Report an issue</a>
  </p>
  
  <span class="small mr-2">Size: 60MB</span>  <br>
  <span class="small mr-2">File: .mov, .mp4</span> <br>
 <span class="small mr-2">Duration: Max 120 seconds</span>  <br>
 <span class="small mr-2">Mode: Landscape</span> 
 </div>
<style>
.formforvideo
{
    display:none;
}

</style>






                    <div class="form-group text-left">
                                <div class="display-callback-error  alert alert-danger" style="display: none">
                                </div>

                    </div>
                    
                    

                <div class="form-group">  
                                <div class="display-callback-success  alert alert-info" style="display: none">
                                   
                                </div>
                </div>






                        <p class="text-center mt-3">
                        <button class="btn btn-sm btn-outline-primary  mr-2 mt-3" data-dismiss="modal">Close</button>    	                                                           
                        </p>


            </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
























<style>
    .upload-btnv-wrapper {
  position: relative;
  overflow: hidden;
  display: inline-block;
}

.btnv {
  //border: 2px solid gray;
  color: white;
  background-image: linear-gradient( 0.2deg, #536de6 4.8%, rgba(51,102,255,1) 85.5% );;
  padding: 6px 20px;
  //border-radius: 8px;
  font-size: 14px;
  font-weight: bold;
}

.upload-btnv-wrapper input[type=file] {
  font-size: 100px;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
}

</style>




    
  <!-- include Google hosted jQuery Library -->
<script src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/jquery.min.js(1).download"></script>


<script type="text/javascript">

$("#videofile").change(function(){
    
    $(".formforvideo").show();
    $(".upload-btnv-wrapper").hide();

         //submit the form here
         //alert("Lets start video upload");
 });
 
 
 $("#cancelvideo").click(function()
 {
     $(".formforvideo").hide();
     $(".upload-btnv-wrapper").show();
 });
 
 

    $(window).on('load',function(){
        setTimeout(function() {
    $('#video-modal').modal('show');}, 5000)
//        $('#video-modal').modal('show');
    });
</script>



<script>
    $(document).ready(function (e) {
 $("#videosave").on('click',(function(e) {
  e.preventDefault();

  //var visibility_choice=$("input[name=visibilitychoice]:checked", "#vform").val();
  //alert(visibility_choice);
  
//var radio=$('input[type="radio"]:checked').val();
var videojobid=293;

            var file = $('#videofile')[0].files[0];
            form = new FormData();
            form.append('media', file);
            form.append('text', videojobid);

  $.ajax({
   url: "https://quantumhunts.com/user/set/upload-jd-video/",
   type: "POST",
   data:  form,
   contentType: false,
         cache: false,
   processData:false,
   //dataType: 'json',
   beforeSend : function()
   {
    //$("#preview").fadeOut();
    $("#privacydiv").fadeOut();
    $("#jdvideopreview").fadeOut();
    $("#jdprogressbar").html("<img src='https://media0.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif?cid=ecf05e47b4154a06962e932aefbf7a670cb428bafb532ce0&rid=giphy.gif' />");
    $("#videoerr").fadeOut();
   
   },
   success: function(vata)
      {
        //alert(vata.code);
        //alert(vata.msg);
    if(vata=='invalid file')
    {
        //alert("1");
     // invalid file format.
     //$("#preview").html(data.msg).fadeIn();
     //$("#preview").html(vata).fadeIn();
     $("#jdprogressbar").fadeOut();
     $("#videoerr").html("Invalid File !").fadeIn();
    }
    else
    {
     //alert("2");
     // view uploaded file.
     $("#privacydiv").fadeOut();
     $("#jdprogressbar").fadeOut();
     $("#jdvideopreview").html(vata).fadeIn();
     $("#vform")[0].reset(); 
    }
      },
     error: function(e) 
      {
          $("#jdprogressbar").fadeOut();
    $("#videoerr").html(e).fadeIn();
      }          
    });
    
    
    
 }));
});
</script>




        

        
        
        

<!-- Signup modal-->

<div id="help-modal" class="modal fade" tabindex="1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="background-image1: radial-gradient( circle farthest-corner at 18.7% 37.8%,  rgba(250,250,250,1) 0%, rgba(225,234,238,1) 90% );">

            <div class="modal-body">
                <div class="text-center mt-2 mb-0">
                    
                    <span class="text-success">
                        <span><img src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/square1_qh.png" alt="" height="32" width="32"></span>
                    </span>
                </div>
                
                <div class="card-body text-center">

                    <strong class="text-center text-primary blogmini">QUANTUMHUNTS</strong>
                    <span class="d-block text-center mb-2"> Help &amp; Support</span>

                <div class="row auto-mx float-center text-center"> 
                <div class="col-2">
                </div>
                <div class="col-8">
                <p class="text-center mb-2">Use the below form to reach us for any request or enquires. Average response time less than 24 hours.</p>
                </div>
                <div class="col-2">
                </div>
                </div>

                </div>

                <form class="pl-3 pr-3" id="callbackform" action="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455#">
                    
                    
                    
<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input class="form-control form-control-sm" type="name" id="name" required="" placeholder="" value="Test Employer Test Employer">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="company">Company</label>
                        <input class="form-control form-control-sm" type="text" id="companyname" required="" placeholder="">
                    </div>
</div> <!-- end col -->
</div>                    


<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input class="form-control form-control-sm" type="phone" required="" id="phone" value="India +91 ">
                    </div>

</div>
<div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">E-Mail</label>
                        <input class="form-control form-control-sm" type="email" required="" id="email" placeholder="" value="tanishsun@hotmail.com">
                    </div>
</div> <!-- end col -->
</div>                    
                    
                    



<div class="row">
<div class="col-md-6">
                    <div class="form-group">
                        <label for="reason">Subject</label>
                        <select class="form-control form-control-sm" id="reason">
                        <option value="Mentorship">Career development</option>  
                        <option value="Courses">Courses</option>              
                        <option value="Business">Business Enquiry</option>
                        <option value="QH-RECRUITER">Premium Plans</option>                 
                        <option value="Help">Help</option>                
                        <option value="AccountIssues">My QH account</option>                        
                        <option value="Issues">Issues &amp; Complaints</option>                                                
                        </select>                        
                    </div>                    

</div>
</div>          





<div class="row">
<div class="col-md-12">
                    <div class="form-group">
                        <label for="comments">Comments</label>
                        <textarea class="form-control" id="comments" placeholder=""></textarea>
                    </div>                    
</div> <!-- end col -->
</div>          





                    


    
                    <div class="form-group text-left">
                                <div class="display-callback-error  alert alert-danger" style="display: none">
                                </div>

                        <button class="btn btn-primary" type="submit" id="callbacksubmit">Submit </button>
                        <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                    </div>
                    
                    
                    <small>By clicking "Submit" I agree to be contacted at the number provided with more information or offers about <span class="text-uppercase text-primary">QuantumHunts</span>. I understand these calls or texts may use computer-assisted dialing or pre-recorded messages.</small>

                </form>
                
                <div class="form-group">  
                                <div class="display-callback-success  alert alert-info" style="display: none">
                                   
                                </div>
                </div>


            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->









  <!-- include Google hosted jQuery Library -->
<script src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/jquery.min.js(1).download"></script>

  
  <script type="text/javascript">
  $(document).ready(function() {


      $('#callbacksubmit').click(function(e){
        e.preventDefault();

    var usertype = $('input[name=customRadio1]:checked').val();
        //alert(usertype);

        var pageurl="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455";
        var email = $("#email").val();
        var phone = $("#phone").val();        
        var name = $("#name").val();
        var company = $("#companyname").val();
        var reason =$('#reason option:selected').val();
        var comments = $("#comments").val(); 
        //var comments = "";
        
        //alert(email+name+phone+reason+comments+company);
        
        $.ajax({
            type: "POST",
            url: "https://quantumhunts.com/user/set/callbacks/",
            dataType: "json",
            data: {name:name,email:email,phone:phone,company:company,reason:reason,comments:comments,pageurl:pageurl},            
            success : function(data){
                if (data.code == "200")
                {
                    $(".display-callback-success").show(); 
                    $(".display-callback-error").hide(); 
                    $("#callbackform").hide();
                    $(".display-callback-success").html(""+data.msg+"");
                    $(".display-callback-success").css("display","block");
                } 
                else {
                    //alert("Success: " +data.msg);
                    $(".display-callback-error").html(""+data.msg+"");
                    $(".display-callback-error").css("display","block");
                }
            }
        });


      });
  });
</script>







    <div id="ReferModal" class="modal " tabindex="-1" role="dialog">
      <div class="modal" tabindex="-1" role="dialog" style="padding-right: 16px; display: block;overflow-y: scroll;" aria-modal="true">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
          <div class="modal-content border-5">
            <div class="modal-body" style="overflow-y: auto;"><div class="card-body">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×
                </span>
              </button>
              <div class="rounded mb-1 pt-0 mt-0">
		<center> <h5 class="d-block  mt-0 mb-3 text-primary text-uppercase  blogmini">📢 Invite Your Friends
                </h5></center>
		<ul class="nav nav-tabs tab-grad mt-3">
						
						<li class="nav-item "> <a class="nav-link btn-primary btn btn-sm text-light font-weight-bold mr-2" data-toggle="tab" href="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455#profile1">Invite via Mail  </a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455#home1"> Share via link</a> </li>
						<li class="nav-item"> <a class="nav-link btn btn-sm btn-primary-two text-dark font-weight-bold mr-2" data-toggle="tab" href="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455#referrals"> My Rewards</a> </li>						
					</ul>
	

<div class="tab-content">
    <div class="tab-pane show active" id="profile1">
	<br>
        <p>You can now invite your friends through mail so that they join world's 1st video centric job platform. You would get rewarded when your friends create their account with us.</p>
                <div class="media-body">
                  <!--<strong class="d-block  mt-2 text-primary text-uppercase purpletitle">Invite via Mail
                  </strong> -->
                 
                <div class="row">
                  
                  <div class="col-lg-12 col-12">
                      
                      <div class="row">
                      <div class="col-6">
                      
                    <span class="media-body mt-2">
                      <div class="form-group">
                        <label for="inputName">Name
                        </label>
                        <input type="text" class="form-control form-control-sm" id="inputName" required="" placeholder="Enter your Friend&#39;s name..">
                      </div> 
                      <div id="div1">
                      </div> 
                      <div class="alert alert-primary" id="invitenamemsg" style="display:none;">Please Enter Your Friend's Name
                      </div>
                      <div class="form-group">
                        <label for="inputEmail">Email
                        </label>
                        <input type="email" class="form-control form-control-sm" id="inputEmail" required="" placeholder="Enter your Friend&#39;s mail..">
                      </div> 
                      <div id="div2">
                      </div> 
                      <div class="alert alert-primary" id="inviteemailmsg" style="display:none;">Please Enter Your Email Id
                      </div>
                      <div class="alert alert-primary" id="invitevalidemailmsg" style="display:none;">Please Enter a Valid Email Id
                      </div>
                      <button class="btn btn-primary btn-sm" id="submit">Submit 
                      </button>
                    </span>
                    
                    </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-12">
                            <div class="alert text-primary" id="invitesuccessmsg" style="display:none;">Success. Your friend will receive an email very soon.</div>
                			<div class="alert text-danger " id="invitefailuremsg" style="display:none;">Please try again. </div><p></p><br>
                            <div class="alert text-danger " id="inviteloginmsg" style="display:none;">Please login To invite your friends.
                      </div>
                        </div>
                    </div>                
                    
                    
                </div>
<div class="col-3 col-lg-4">
                  </div>
                <div class="col-3">
                </div>
                <div class="col-12">
                </div>
                </div>
            </div>
    </div>
     <div class="tab-pane" id="home1"><br>
        <p>Share this link with your friends so that they join World's 1st video resume platform. You would get rewarded when your friends create their video resume with us.</p>
	                <div class="row mt-3 mx-0">

                  <div class="col-12 col-md-5  my-auto mx-auto">
                        <div class="input-group input-group-merge">
                      <input class="form-control" type="text" value="https://quantumhunts.com/?ref=tanish-sun-20210108120453" id="copybox">
                    <div class="input-group-append">
                      <button class="btn btn-primary-two btn-sm font-weight-bold text-dark" onclick="copyfunction()">Copy my link
                      </button>
                        </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-2 text-center my-auto mx-auto">
                    <p style="text-center font-size:20;">or
                    </p>
                  </div>
                  <div class="col-12 col-md-5  my-auto mx-auto">
                    <ul class="share-buttons">
                      
                      
                      <a class="mr-1" href="https://www.facebook.com/sharer/sharer.php?u=https://quantumhunts.com/?ref=tanish-sun-20210108120453;" title="Share on Facebook" target="_blank" onclick="window.open(&#39;https://www.facebook.com/sharer/sharer.php?u=&#39; + https://quantumhunts.com/signup/?ref=tanish-sun-20210108120453  Create a Professional Login+ &#39;&amp;quote=Apply for this opportunity&#39; ); return false;">
                        <img alt="Share on Facebook" src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/facebook.png">
                      </a>            
                      
                      
                      <a class="mr-1" href="https://twitter.com/intent/tweet?text=https://quantumhunts.com/?ref=tanish-sun-20210108120453%20Create%20a%20Professional%20Login" title="Click to share this post on Twitter" "="" target="_blank" onclick="window.open(&#39;https://twitter.com/intent/tweet?text=&#39; + https://quantumhunts.com/job/tanish-sun-20210108120453 + &#39;:%20&#39;  + Apply for this opportunity); return false;">
                      <img alt="Tweet" src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/twitter.png">
                      </a>

                    <a class="mr-1" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://quantumhunts.com/?ref=tanish-sun-20210108120453;title=&amp;summary=&amp;source=" target="_blank" title="Share on LinkedIn">
			<img alt="Share on LinkedIn" src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/linkedin.png">
                      </a> 
                    </ul>
                </div>
              </div>
    
 	<div class="mt-1 mb-1">
              <br>  <br>
              </div>
              
              <div class="row mt-2 mx-0">

                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row ">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-link text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 1 
                        </h5>    
                        <p class="text-secondary font-13 mb-0 mt-0 pb-0 pt-0 px-0">Share Link with your friends   
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
              
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mb-4 mt-n3">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-user-group text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 2
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">Ask your friends to create video resume  
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="col-12 col-md-4">
                  <div class="card border shadow card-body mx-n1 mt-n3 ">
                    <div class="row">
                      <div class="col-2">
                        <div class="align-center">
                          <i class="dripicons-trophy text-primary"></i>
                          
                        </div>
                      </div>
                      <div class="col-10 p-0 pl-1"> 
                        <h5 class="lead font-weight-bold text-dark mb-0 pb-0 mt-0  text-uppercase font-14 purpletitle">Step 3 
                        </h5>    
                        <p class="text-secondary font-13  mb-0 mt-0 pb-0 pt-0 px-0">We will reward your account 
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div></div>
              
              
    <div class="tab-pane" id="referrals">
        <p class="mt-3">Here is the stats of the valid users who have signed up based on your referral. Better your own numbers by speaking about our platform to your friends and acquaintance. share your referral link today.</p>
        <div class="row">
        <div class="col-4 col-xs-12 col-sm-12 col-md-4">



<div class="card tilebox-one shadow">
                                    <div class="card-body">
                                        <i class="uil uil-users-alt float-right"></i>
                                        <h6 class="text-uppercase mt-0 blogmini text-primary">Verified Users</h6>
                                        <h2 class="my-2" id="active-users-count">0</h2>
                                        <p class="mb-0 text-muted">
                                            <span class="text-nowrap">Since signup</span>  
                                        </p>
                                    </div> <!-- end card-body-->
                                </div>



        </div>
        </div>

    </div>
              
</div>



</div>
    </div>
        </div>
      </div>
    </div>
    </div>
  <br>
  <br>
  <br>
  <br>
  <br>
  </div>
<script src="./QUANTUMHUNTS Job - Talent Development Manager at Bangalore, India_files/jquery.min.js(1).download">
</script>
<script>
  function copyfunction() {
    var copyText = document.getElementById("copybox");
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
  }
  $(document).ready(function(){
    $('#submit').click(function(){
      var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
      var name = $('#inputName').val();
      var email = $('#inputEmail').val();
      if(name.trim()=='')
      {
        //document.getElementById("div1").innerHTML="Enter a value";
        //document.getElementById("div1").style.color="Red";
        $('#inputName').focus();
      }
      else if(email.trim() == '' ){
        //document.getElementById("div2").innerHTML="Enter the correct email address";
        //document.getElementById("div2").style.color="Red";
        $('#inputEmail').focus();
      }
      else if(email.trim() != '' && !reg.test(email)){
        //$("#invitevalidemailmsg").css("display","block");
        $('#inputEmail').focus();
      }
      else{
        
        $.ajax({
          type:"POST",
          url:"https://quantumhunts.com/invite/send/",
          dataType: "json",
          data:{
            name:name,email:email},
          success:function(data){
            if(data.status == 'ok'){
               $("#invitesuccessmsg").css("display","block");
		$("#inviteloginmsg").hide();
		$("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitesuccessmsg").hide();
              }, 4000);              
            }
            else{ if(data.status=='error'){
             $("#inviteloginmsg").css("display","block");
	     $("#invitesuccessmsg").hide();
	     $("#invitefailuremsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitevalidemailmsg").hide();
              }, 4000);                            
              }
		else{
              $("#invitefailuremsg").css("display","block");
		$("#invitesuccessmsg").hide();
	     $("#inviteloginmsg").hide();
              $("#div1").hide();
              $("#div2").hide();
              $("#invitevalidemailmsg").hide();
              setTimeout(function(){
               $("#invitefailuremsg").hide();
              }, 4000);                            
            }
	 }
          }
        }
              );
      }
    }
                      );
  }
                   );
</script>


<?php
  include($root."/jobs/footer.php");
?>