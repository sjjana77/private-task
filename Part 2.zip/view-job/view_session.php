<?php
session_start();
$a=$_POST['a_id'];
$b=$_POST['c_id'];
$_SESSION['a_id']=$a;
$_SESSION['c_id']=$b;
echo json_encode(['code'=>200, 'msg'=>$a]);
exit;
?>