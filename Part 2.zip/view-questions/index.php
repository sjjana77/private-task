<?php
session_start();
$root=$_SERVER["DOCUMENT_ROOT"];
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
?>
<!DOCTYPE html>
<!-- saved from url=(0090)https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455 -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta property="og:url" content="https://quantumhunts.com/job/talent-development-manager-hcl-bangalore-india-20210108215455">
<meta property="og:type" content="website">
<meta property="og:title" content="Talent Development Manager at HCL, Bangalore, India ">
<meta property="og:description" content="HCL Software is a division of HCL Technologies (HCL) that operates its primary software business. It develops, markets, sells, and supports over 20 product fami">
<meta property="og:image" content="https://quantumhunts.com/user/assets/images/header/job_openning_300px.png">
<meta property="fb:app_id" content="525323715034631"> 


        <title>VJA | View Questions</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="* Understand and appreciate software product engineering, technologies &amp; methodologies at a conceptu " name="description">
        <meta content="QUANTUMHUNTS" name="author">
<?php
  include($root."/header_employer.php");
?>
        <!-- Start Content-->
       
       
       
       
        <div class="container-fluid">

            <!-- Begin page -->
            <div class="wrapper">

                <!-- ========== Left Sidebar Start ========== -->
<div class=""></div>

                <!-- Left Sidebar End -->
                       
                
                
                
 <div class="content-page">
                    <div class="content">

                        <div class="row">
                            

                           



                        


<div class="col-xl-12 col-lg-12">
    
    
         



        <div class="row">  
        

<div class="col-lg-8">
<div class="row">
<div class="col-12">


<br><br><br>
        <div class="card border shadow1 card-body">
            <div class="row"><div class="col">
        <h5 class="mb-0 font-weight-bold mb-1 text-left text-uppercase text-primary blogmini">Questions</h5></div>
        <div class="col">   <button type="button" id="new-Set" class="btn btn-primary">Add New Question</button>
        &nbsp;&nbsp;&nbsp;&nbsp; <a href="http://localhost/view-sets/" type="button" class="btn btn-primary"><span style="color:white;"> Back</span></a>

    </div></div>
        <br>
        <table class="table-bordered table-striped table-sm table-responsive mb-0" style="font-size:1rem;">
<thead class="thead-dark table-dark">
<tr style="font-size:1rem;">
<td><strong>S.No</strong></td>            
    <td><strong>Question</strong></td>             
    <td><strong>Time(In mintues)</strong></td>    
    <td><strong>Edit</strong></td>  
    <td><strong>Delete</strong></td>     
    </tr>

  </thead>    
  <tbody>
    <?php
        $s=0;
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$s_id=$_SESSION["set_id"];
$r_id=$_SESSION["recruiter_id"];
$sql = "SELECT * FROM vj_questions where question_added_by='$r_id' and question_status!='1' and question_set_id='$s_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
    $s+=1;
echo "<tr><td>" . $s. "</td><td>" . $row['question_question']. "</td><td>" . $row['question_time'] . "</td><td><a class='edit' id='".$row['question_id']."' onclick='edit(this.id)'><i class='fa fa-edit' style='cursor:pointer;color:black;font-size:1.1rem;'></i></a><td><a class='delete' id='".$row['question_id']."'><i class='fas fa-trash' style='cursor:pointer;color:red;'></i></a></td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
  </tbody>
</table>



        </div></div></div></div></div></div></div></div>
        </div></div></div>

<?php
  include($root."/jobs/footer.php");
?>
<script>
    $("#new-Set").click(function(){
        location.href="http://localhost/add-questions/";
    });
    function edit(a){
        var aa=a;
        $.ajax({
                type: "POST",
                url: "http://localhost/view-questions/question-session.php",
                dataType: "json", 
                data:{aa:aa},
                success : function(data){
                    //alert(data.code);
                    if (data.code == "400")
                    {
                        location.href="http://localhost/edit-questions/";
                    }
                }

            });
    }
    $(".delete").click(function(){
        var cc=this.id;
        $.ajax({
                type: "POST",
                url: "http://localhost/view-questions/question-delete.php",
                dataType: "json", 
                data:{aa:cc},
                success : function(data){
                    //alert(data.code);
                    if (data.code == "400")
                    {
                        location.href="http://localhost/view-questions/";
                    }
                }

            });
    });
</script>