<?php
session_start();
$flow="1";
$code=200;
$db_servername='localhost';
$db_username='root';
$db_password='';
$db_dbname='project';
$s_id=$_POST['aa'];
$conn = mysqli_connect($db_servername, $db_username, $db_password, $db_dbname);
$sql="UPDATE vj_question_set set set_status='1' where set_id='$s_id'";
if ($conn->query($sql)==TRUE){
    echo json_encode(['code'=>400, 'msg'=>'success']);
    $conn->close(); 
    exit;
}  
else{
    echo json_encode(['code'=>200, 'msg'=>'f']);
    $conn->close(); 
    exit;
}
?>