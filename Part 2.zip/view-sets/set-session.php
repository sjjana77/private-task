<?php
session_start();
$a=$_POST['aa'];
$_SESSION["set_id"]=$a;
echo json_encode(['code'=>400, 'msg'=>"f"]);
exit;
?>